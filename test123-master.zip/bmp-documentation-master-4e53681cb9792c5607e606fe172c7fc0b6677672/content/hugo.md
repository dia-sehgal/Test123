---
title: "Hugo"
date: 2018-05-24T09:51:24-07:00
draft: false
---

This website is developed using the static website generator Hugo and a number of 3rd party tools designed to work with Hugo that provide the overall look and feel (theme) as well as many of the rich content experiences.


# Hugo Overview

Hugo is a fast and modern static site generator written in Go, and designed to make website creation fun again.

Hugo is a general-purpose website framework. Technically speaking, Hugo is a static site generator. Unlike systems that dynamically build a page with each visitor request, Hugo builds pages when you create or update your content. Since websites are viewed far more often than they are edited, Hugo is designed to provide an optimal viewing experience for your website’s end users and an ideal writing experience for website authors.

Websites built with Hugo are extremely fast and secure. Hugo sites can be hosted anywhere, including GitLab, Pivotal Cloud Foundry and Apache Mesos and work well with CDNs. Hugo sites run without the need for a database or dependencies on expensive runtimes like Ruby, Python, or PHP.

Hugo is an ideal website creation tool with nearly instant build times, able to rebuild whenever a change is made.

## Learn more about Hugo


[Hugo Documentation](https://gohugo.io/documentation/)

[Hugo Video Tutorial Series](https://www.youtube.com/watch?v=qtIqKaDlqXo&list=PLLAZ4kZ9dFpOnyRlyS-liKL5ReHDcj4G3)

## DocDock - The Hugo theme used for this site

[DocDock Theme](https://themes.gohugo.io/theme/docdock/)

[Mermaid - Flow & Sequence Diagramming](https://mermaidjs.github.io/)

[Open API Specification (Swagger) With Hugo](https://www.tenfourty.com/hugo-oai-swagger-example/)

## Content creation using Markdown

All of the content for this site is written in Markdown. Check out the cheat sheet below to learn the basics of this easy to use markup language.

[Markdown Cheat Sheet](/markdown)