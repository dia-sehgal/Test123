---
title: "Sentry Alarming"
date: 2018-05-24T09:49:19-07:00
draft: false
---

Sentry is a lightweight, versatile, cross-platform application manager with out-of-the-box management capability. Very little configuration is required to get it up and running in a useful manner. Detailed functional specifications are contained in the [Sentry Documentation](http://emt.uswc.uswest.com/sentry/index.html).

Sentry for Java is the official Java SDK for the Sentry API. At its core it provides a raw client for sending events to Sentry, but it is highly recommended to include the library or framework integration listed below if at all possible. The sentry library provides a java.util.logging Handler that sends logged exceptions to Sentry.

Notifications in Sentry come in many flavors, but by default are aimed at Email. In this example, we are using _Splunk_ for integration to create the notifications. Please contact the [SPLUNK-IT Team](mailto:SPLUNK-IT@CenturyLink.com) for Splunk inquiries.  You can refer to the [Splunk Alert Manual](/Splunk-6.5.4-Alert.pdf) on how to setup the alerts.  Alerts are configured per-project and are based on the rules defined for that project.


### Atachements
{{%attachments title="Related files" pattern=".*(pdf|doc|xlsx)"/%}}


<br>
### Installation
Please contact the [Hyperion support team](mailto:Hyperion-Support@Centurylink.com) to direct you on how to setup your credentials to access the Nexus repository.

Using Maven:
{{< highlight java >}}

		<!-- CenturyLink Sentry Alarming -->
		<dependency>
			<groupId>sentry</groupId>
			<artifactId>sentryapi</artifactId>
			<version>1.12</version>
		</dependency>
		...
		<!-- Logging -->
		<dependency>
			<groupId>commons-logging</groupId>
			<artifactId>commons-logging</artifactId>
			<version>1.1.3</version>
		</dependency>
		<dependency>
			<groupId>log4j</groupId>
			<artifactId>log4j</artifactId>
			<version>1.2.17</version>
		</dependency>

{{< / highlight >}}

<br>
### Usage
Following is a sample Java base class that shows how to use the library that logs to standard out.

{{< highlight java >}}
package com.centurylink.hyperion.sentry;

import org.apache.log4j.Logger;
import sentry.event.Severity;

/**
 * A simple utility that issues Sentry alarms to a log file.
 * 
 * @author mhanes
 */
public class SentryAlarm {

	private static Logger logger = Logger.getLogger(SentryAlarm.class.getName());	

	/**
	 * Required no argument constructor.
	 */
	public SentryAlarm() {

	}

	/**
	 * Sends an alarm event to a Sentry console via sockets.
	 * 
	 * @param aSeverity
	 * @param anApplication The name of the application sending the event.
	 *        (Required: Between 2 - 40 characters inclusive)
	 * @param aSubSystem The name of the subsystem within the application 
	 *        that is sending or causing the event. (Optional: Maximum 200 characters)
	 * @param anIdentifier A number uniquely identifying this type of event 
	 *        for this application. (Required: Positive integer)
	 * @param anObject The name of the object about which the event is being raised.
	 *        (Optional: Maximum 300 characters)
	 * @param aMessage A textual description of the event. 
	 *        (Optional: Maximum 1000 characters)
	 * @param aClassInfo Event classification information. 
	 *        (Optional: Maximum 200 characters)
	 */
	public static void sendEvent(Severity aSeverity, String anApplication,
			String aSubSystem, int anIdentifier, String anObject,
			String aMessage, String aClassInfo) {
		
		if(aSeverity==Severity.CRITICAL || aSeverity==Severity.MAJOR) {
			logger.error("sentry.alarm.severity=" + aSeverity.value + 
			" sentry.alarm.application=" + anApplication + 
			" sentry.alarm.subsystem=" + aSubSystem + 
			" sentry.alarm.identifier=" + anIdentifier + 
			" sentry.alarm.object=" + anObject + 
			" sentry.alarm.message=" + aMessage + 
			" sentry.alarm.classinfo=" + aClassInfo);
		} else if (aSeverity==Severity.MINOR || aSeverity==Severity.WARNING) {
			logger.warn("sentry.alarm.severity=" + aSeverity.value + 
			" sentry.alarm.application=" + anApplication + 
			" sentry.alarm.subsystem=" + aSubSystem + 
			" sentry.alarm.identifier=" + anIdentifier + 
			" sentry.alarm.object=" + anObject + 
			" sentry.alarm.message=" + aMessage + 
			" sentry.alarm.classinfo=" + aClassInfo);
		} else {
			logger.info("sentry.alarm.severity=" + aSeverity.value + 
			" sentry.alarm.application=" + anApplication + 
			" sentry.alarm.subsystem=" + aSubSystem + 
			" sentry.alarm.identifier=" + anIdentifier + 
			" sentry.alarm.object=" + anObject + 
			" sentry.alarm.message=" + aMessage + 
			" sentry.alarm.classinfo=" + aClassInfo);
		}
	}

	/**
	 * Sends an Event of Serverity.CRITICAL to the Sentry server.
	 * 
	 * Indicates that a service affecting fault condition has occurred which prevents system 
	 * function, and an immediate corrective response is required.
	 */
	public static void eventCritical(String anApplication, String aSubSystem,
			int anIdentifier, String anObject, String aMessage,
			String aClassInfo) {

		sendEvent(Severity.CRITICAL, anApplication, aSubSystem, anIdentifier,
				anObject, aMessage, aClassInfo);
	}

	/**
	 * Sends an Event of Serverity.MAJOR to the Sentry server.
	 * 
	 * Indicates that a service affecting fault condition has occurred which inhibits system 
	 * functionality, and an urgent corrective response is required.
	 */
	public static void eventMajor(String anApplication, String aSubSystem,
			int anIdentifier, String anObject, String aMessage,
			String aClassInfo) {

		sendEvent(Severity.MAJOR, anApplication, aSubSystem, anIdentifier,
				anObject, aMessage, aClassInfo);
	}

	/**
	 * Sends an Event of Serverity.MINOR to the Sentry server.
	 * 
	 * Indicates that a non-service affecting fault condition has occurred, and that 
	 * corrective response should be taken to prevent a more serious fault condition.
	 */
	public static void eventMinor(String anApplication, String aSubSystem,
			int anIdentifier, String anObject, String aMessage,
			String aClassInfo) {

		sendEvent(Severity.MINOR, anApplication, aSubSystem, anIdentifier,
				anObject, aMessage, aClassInfo);
	}

	/**
	 * Sends an Event of Serverity.WARNING to the Sentry server.
	 * 
	 * Indicates that a non-service affecting, non-fault condition exists, and that 
	 * corrective response should be taken to prevent a fault condition.
	 */
	public static void eventWarning(String anApplication, String aSubSystem,
			int anIdentifier, String anObject, String aMessage,
			String aClassInfo) {

		sendEvent(Severity.WARNING, anApplication, aSubSystem, anIdentifier,
				anObject, aMessage, aClassInfo);
	}

	/**
	 * Sends an Event of Serverity.NORMAL to the Sentry server.
	 * 
	 * Indicates an informational event, not a problem of any sort. Strictly speaking,
	 * normal events are not alarms and should be used rarely.
	 */
	public static void eventNormal(String anApplication, String aSubSystem,
			int anIdentifier, String anObject, String aMessage,
			String aClassInfo) {

		sendEvent(Severity.NORMAL, anApplication, aSubSystem, anIdentifier,
				anObject, aMessage, aClassInfo);
	}

	/**
	 * Sends an Event of Serverity.UNKNOWN to the Sentry server.
	 * 
	 * Indicates that the severity level cannot be determined.
	 */
	public static void eventUnknown(String anApplication, String aSubSystem,
			int anIdentifier, String anObject, String aMessage,
			String aClassInfo) {

		sendEvent(Severity.UNKNOWN, anApplication, aSubSystem, anIdentifier,
				anObject, aMessage, aClassInfo);
	}

}

{{< / highlight >}}

<br>
### In Practice
Below is a sample client, but there are many ways to setup the client before calling the Java base class above:
{{< highlight java >}}
package com.centurylink.hyperion.event.exception;

import com.centurylink.hyperion.sentry.SentryAlarm;

import sentry.event.Severity;

public class Http500InternalServerError {

	public void alarmCritical() throws Exception {
		
		SentryAlarm.sendEvent(Severity.CRITICAL, "chatSvcs", "lpdarest", 4500, 
		"LiveEngageRouteBuilder", "Unexpected exception encountered", ""); 	
	}
}

{{< / highlight >}}
<br>