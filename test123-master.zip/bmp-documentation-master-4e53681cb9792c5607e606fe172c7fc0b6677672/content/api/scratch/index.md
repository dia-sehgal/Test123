+++
title= "Scratch"
date= 2018-06-05T12:46:29-07:00
description = "Scratch Pad For Experimentation"
draft= true
+++

## Petstore Swagger Spec
{{< oai-spec url="http://petstore.swagger.io/v2/swagger.json" >}}

## Blue Marble Swagger Spec



{{<mermaid align="left">}}
graph TD
    eShop -.-> |orderInit|BM[Blue Marble]
    BM-->|ValidateAddress|GOES
    BM-->|Qual for HSI|LoopQual
    BM-->|Availability & Pricing|Pricing
{{< /mermaid >}}


{{<mermaid>}}
sequenceDiagram
    participant Alice
    participant Bob
    Alice->>John: Hello John, how are you?
    loop Healthcheck
        John->John: Fight against hypochondria
    end
    Note right of John: Rational thoughts <br/>prevail...
    John-->Alice: Great!
    John->Bob: How about you?
    Bob-->John: Jolly good!
{{< /mermaid >}}


![agence](files/C.jpg?width=50%&classes=border,shadow)