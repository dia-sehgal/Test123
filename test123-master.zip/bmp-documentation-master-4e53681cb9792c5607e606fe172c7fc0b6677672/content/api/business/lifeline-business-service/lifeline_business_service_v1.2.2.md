LifeLine Config Business Service
================================
    Version: 1.2.2

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /saveLifeLineConfig](#Request)
- [Response /saveLifeLineConfig](#Response)

Overview
--------

> **LifeLine Config business service is used to retrieving Lifeline Config items for the customer from Ensemble through EDS service.**

![](LifelineDiagram1.png)

![](media/LifelineDiagram2.png)

**Request Syntax**

For each resource, the following items are documented.

| **Name**       | **Value**               |
|:---------------|:------------------------|
| HTTP Method    | POST                    |
| Base URI       | /saveLifeLineConfig/    |
| URI Syntax     |                         |
| Operation Name | /**saveLifeLineConfig** |

Required Parameters
-------------------

| **Parameter**  | **Description**                 |
|:---------------|:--------------------------------|
| lifeLineConfig | Lifeline Config Data from eSHOP |

Operation Details (Request/Response)
------------------------------------

    API: /saveLifeLineConfig

Request 
========
```sh
{
  "orderRefNumer": "ORN-20794929175692769",
  "lifelineInd": true,
  "llServiceType": "VOICE",
  "lifeLineProducts": [
    {
      "productDetails": {
        "ban": 300021686,
        "productType": "T",
        "csrId": 1061338
      },
      "LifeLineConfig": {
        "firstName": "Whitney",
        "lastName": "Johnson",
        "dateOfBirth": "2018-07-12T13:14:08.118Z",
        "ssnLastFour": 5689,
        "federalInd": true,
        "tribalInd": true,
        "stateInd": true,
        "linkUpInd": true,
        "linkupSvcDate": "10/31/2018",
        "qualProg": "BDS: Badger Care",
        "effectiveDate": "11/22/2017",
        "iehCertDate": "11/22/2017",
        "expirationDate": "12/31/9999",
        "anniversaryDate": "11/22/2017",
        "caseNumber": "1234-01",
        "acpInd": true,
        "ruralInd": false,
        "nladData": {
          "subscriberId": "LLID 3252413, NVID 3025266245, NVAP 3023241",
          "serviceDate": "11/22/2017"
        }
      },
      "LifeLineDiscounts": {
        "discounts": [
          {
            "llarcCreditInd": true,
            "discountCode": "MEDTAP",
            "recurringStateCreditDesc": "ARC Recurring Credit (LLARC)",
            "startDate": "2/20/2018",
            "endDate": "12/31/9999",
            "zone1Ind": true,
            "zone2Ind": true,
            "WireMaintanaceInd": true,
            "actionType": "ADD"
          }
        ]
      },
      "LifeLineAdjustments": {
        "adjustments": [
          {
            "adjustmentReason": "AJLIFE",
            "nonRecurringStateCreditDesc": "Lifeline Adjustment (AJLIFE)",
            "adjustmentAmount": 50,
            "actionType": "ADD"
          }
        ]
      }
    }
  ]
}
```

Error Response 
=========
```sh
{
  "errorResponse": {
    "reasonCode": "BM_DATABASE_ERROR",
    "message": "SUCCESS",
    "messageDetail": "Please retry after some time",
    "timestamp": "2018-07-12T13:14:08.272Z"
  }
}
```

| HTTP Status Code (BM) | BM Reason Code              | Message Text              |
|:----------------------|:----------------------------|:--------------------------|
| 401                   | AUTHENTICATION_FAILURE      | Authentication failed due to invalid authentication credential. |
| 403                   | BILLING_SERVICE_UNAVAILABLE | An internal Error occurred.                                     |
| 404                   | RESOURCE_NOT_FOUND          | URL Issue                                                       |
| 500                   | BM_LifeLine_Server_Error    | Server Error                                                    |
| 400                   | CONNECTION_FAILED           | Connection failed                                               |
| 404                   | SERVICE_UNAVAILABLE         | Service is not available.                                       |
| 502                   | BAD_GATEWAY                 |                                                                 |
| 400                   | BAD_REQUEST                 |                                                                 |

[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>