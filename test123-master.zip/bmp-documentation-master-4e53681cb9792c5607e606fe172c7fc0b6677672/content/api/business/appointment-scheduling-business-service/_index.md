---
title: "Appointment Scheduling"
date: 2018-05-24T09:51:24-07:00
draft: false
---


This service is used to retrieve available appointment slots for Tech dispatch when Tech installation is required for a service.  The service pulls are available slots from CTS system by calling EOS appointment inquiry service (southbound) based on address and products ordered by the customer and provides them to ordering channel for user selection


## Sections
* [Resources/Operations](#resources-operations)
* [Swagger Specification](#swagger-specification)
* [Authentication Details](#authentication-details)
* [MAL/Cloud Org](#mal-cloud-org)
* [Dependencies](#dependencies)
  - [MongoDB](#mongodb)
  - [PCF Services](#pcf-services)
  - [Processes Using](#processes-using)
  - [Downstream Services](#downstream-services)
* [Developer Installation](#developer-installation)
* [Setup](#setup)
* [CI/CD Pipeline Details](#ci-cd-pipeline-details)
* [Cloud Environment Details](#cloud-environment-details)
* [Splunk Dashboard](#splunk-dashboard)



## Resources/Operations  
  i) **appointment/retrieve** - This API brings multiple appointment slots to user.
  	   
 ii) **appointment/reserve** -  This API reserve the slot selected by the user.

 iii) **appointment/cancel** - This API helps to cancel the selected appointment slots.
 
 iv) **appointment/retrieveadditionalslots** - This API helps to cancel the selected appointment slots.

## Swagger Specification
{{< oai-spec url="https://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/files/api-docs.json" >}}


# Installation :
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
    - Visit [Oracle] website to get the Oracle JDBC driver â€“ ojdbc6.jar or ojdbc7.jar
    - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} 
      -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar
            
# SetUp : 
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/appointmentscheduling-business-service.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run    
```

# Dependent systems :
   EOS
   	prod: http://eosservice.uswc.uswest.com:8201/EOSWeb/MDWWebService?WSDL
    e2e: http://qtdenvmdt311.dev.qintra.com:8034/EOSWeb/MDWWebService?WSDL
    
   DataMapping Business Service
    dev3: https://bmp-datamapping-business-service-dev3.pcfmrnctl.dev.intranet/serviceDataMapping/getDataMappingByRFSID
    test2: https://bmp-datamapping-business-service-test2.pcfmrnctl.dev.intranet/serviceDataMapping/getDataMappingByRFSID
    test3: https://bmp-datamapping-business-service-test3.pcfmrnctl.dev.intranet/serviceDataMapping/getDataMappingByRFSID
    e2e: https://bmp-datamapping-business-service-ctle2e.pcfmrnctl.dev.intranet/serviceDataMapping/getDataMappingByRFSID
    prod: https://bmp-datamapping-business-service.pcfmrnctl.corp.intranet/serviceDataMapping/getDataMappingByRFSID
    
# CI/CD Pipeline Details :
* Name:	 bmp-appointmentscheduling-business-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000

* Sonarqube Project URL:	 TBD

* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 TBD  

# Cloud Environment Details
* Cloud Group Name:	 BMCO-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-appointmentscheduling-business-service-test3.pcfmrnctl.dev.intranet/

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/  

# Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards

# Swagger URL :
```sh
https://bmp-appointmentscheduling-business-service-test3.pcfmrnctl.dev.intranet/
```
# Sample Request for Post(Retrieve Available Appointment):
```sh
{
    "requestedDueDate" : {
        "startDateTime" : "2018-07-13T11:59:59.059Z",
        "endDateTime" : "2018-08-12T11:59:59.059Z"
    },
    "productOfferDetails" : [ 
        {
            "productOfferingId" : "12379",
            "offerCategory" : "INTERNET",
            "quantity" : 1,
            "action" : "ADD",
            "rc" : 55.0,
            "otc" : 0.0,
            "discountedRc" : 0.0,
            "discountedOtc" : 0.0,
            "productDetails" : [ 
                {
                    "productId" : "28194",
                    "productName" : "HSI Upto 40 Mbps/2 Mbps",
                    "productType" : "INTERNET",
                    "componentType" : "PRIMARY",
                    "productCategory" : "CORE",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "SRV",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "QW",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Derived DownSpeed",
                                    "attributeValue" : "0 - 40",
                                    "uom" : "Mbps"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Derived Upspeed",
                                    "attributeValue" : "0 - 2",
                                    "uom" : "Mbps"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "1",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "HSI",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "IsPrimary",
                                    "attributeValue" : "ADDON",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "prismSupported",
                                    "attributeValue" : "false"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "dhpSupported",
                                    "attributeValue" : "true"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "hpSupported",
                                    "attributeValue" : "true"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "prismSupported",
                                    "attributeValue" : "false"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "dhpSupported",
                                    "attributeValue" : "true"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "hpSupported",
                                    "attributeValue" : "true"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Technology",
                                    "attributeValue" : "VDSL2"
                                }, 
                                {
                                    "attributeName" : "Downspeed",
                                    "attributeValue" : "40128"
                                }, 
                                {
                                    "attributeName" : "Upspeed",
                                    "attributeValue" : "20128"
                                }, 
                                {
                                    "attributeName" : "Downspeed",
                                    "attributeValue" : "40128"
                                }, 
                                {
                                    "attributeName" : "Upspeed",
                                    "attributeValue" : "5120"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28172",
                    "productName" : "TECH INSTALL",
                    "productType" : "INTERNET",
                    "componentType" : "COMPONENT",
                    "productCategory" : "TECHINST",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Level",
                                    "attributeValue" : "Standard",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28217",
                    "productName" : "MODEM",
                    "productType" : "INTERNET",
                    "componentType" : "COMPONENT",
                    "productCategory" : "EQP",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Account Type",
                                    "attributeValue" : "Use Your Own",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28153",
                    "productName" : "CENTURYLINK @ EASE",
                    "productType" : "INTERNET",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Level",
                                    "attributeValue" : "Basic"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28238",
                    "productName" : "ISP",
                    "productType" : "INTERNET",
                    "componentType" : "COMPONENT",
                    "productCategory" : "CORE",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Vendor",
                                    "attributeValue" : "CenturyLink",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Number of Mailboxes",
                                    "attributeValue" : "2",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Number of Mailboxes",
                                    "attributeValue" : "10",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Number of Mailboxes",
                                    "attributeValue" : "11",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "No of MailBoxes",
                                    "attributeValue" : "11"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "No of MailBoxes",
                                    "attributeValue" : "10"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }
            ]
        }, 
        {
            "productOfferingId" : "12388",
            "offerCategory" : "VOICE-DHP",
            "quantity" : 1,
            "action" : "ADD",
            "rc" : 60.0,
            "otc" : 0.0,
            "discountedRc" : 60.0,
            "discountedOtc" : 0.0,
            "productDetails" : [ 
                {
                    "productId" : "28101",
                    "productName" : "Digital Home Phn Essential Pk",
                    "productType" : "VOICE-DHP",
                    "componentType" : "PRIMARY",
                    "productCategory" : "CORE",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Type",
                                    "attributeValue" : "DHP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "SRV",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28178",
                    "productName" : "SYS Dial Tone Management",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28087",
                    "productName" : "CUS VM Wtng Indicator",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28215",
                    "productName" : "SYS IncomingCommunication",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28068",
                    "productName" : "SYS Block International Calls",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28108",
                    "productName" : "SYS Communication Distro",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28157",
                    "productName" : "communicator.centurylink.com",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28175",
                    "productName" : "SYS CPE",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28063",
                    "productName" : "Digital Home Phone ATA",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "EQP",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ResourceType",
                                    "attributeValue" : "DHP ATA",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Shipping Method",
                                    "attributeValue" : "ADVANCED",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Shipping Method",
                                    "attributeValue" : "PREMIUM",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28193",
                    "productName" : "SYS Storage",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28062",
                    "productName" : "CUS Voicemail to your email",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28235",
                    "productName" : "SYS CallerID Name",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28122",
                    "productName" : "CUS Manage online contacts",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28066",
                    "productName" : "CUS View call history",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "25568",
                    "productName" : "CUS Block calls specific TNs",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28210",
                    "productName" : "SYS TelcoCommon",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28170",
                    "productName" : "CUS Findme-followme",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28197",
                    "productName" : "SYS IDPR",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28069",
                    "productName" : "SYS Notification",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28085",
                    "productName" : "SYS OutgoingCommunication",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28156",
                    "productName" : "CUS Caller ID block *67",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28088",
                    "productName" : "VoiceMail",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "VMAIL",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28064",
                    "productName" : "CUS Instant messaging",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "Enabled",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }, 
                {
                    "productId" : "28080",
                    "productName" : "Digital Home Phone Intl Call",
                    "productType" : "VOICE-DHP",
                    "componentType" : "COMPONENT",
                    "productCategory" : "VAS",
                    "productAttributes" : [ 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "allowMACD",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Max Quantity",
                                    "attributeValue" : "0",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Ensemble Product Type",
                                    "attributeValue" : "VP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Group",
                                    "attributeValue" : "CVOIP",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Sub Service Group",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Service Status",
                                    "attributeValue" : "No",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Product Sub-Type",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "Transport Medium",
                                    "attributeValue" : "Optical Fiber Network",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductActivationDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }, 
                        {
                            "compositeAttribute" : [ 
                                {
                                    "attributeName" : "ProductDisconnectDate",
                                    "attributeValue" : "",
                                    "uom" : "NA"
                                }
                            ]
                        }
                    ],
                    "action" : "ADD"
                }
            ]
        }
    ],
    "noOfComputers" : "1 device",
    "customerOrderType" : "NEWINSTALL",
    "address" : {
        "addressId" : "",
        "streetAddress" : "2366 PRIMO RD",
        "streetNrFirst" : "2366",
        "streetNrFirstSuffix" : "",
        "streetNrLast" : "",
        "streetNrLastSuffix" : "",
        "streetName" : "PRIMO RD",
        "streetType" : "",
        "locality" : "HIGHLANDS RANCH",
        "city" : "HIGHLANDS RANCH",
        "stateOrProvince" : "CO",
        "postCode" : "80129",
        "postCodeSuffix" : "",
        "sourceId" : "LTTNCOHL15RUK.8",
        "source" : "LFACS",
        "country" : "USA",
        "geoPoint" : [ 
            {
                "source" : "Trillium",
                "latitude" : 39.564487,
                "longitude" : -105.017309,
                "coordinateLevel" : "1",
                "accuracy" : "1"
            }
        ],
        "subAddress" : {
            "sourceId" : "",
            "source" : "",
            "geoSubAddressId" : "",
            "combinedDesignator" : "",
            "elements" : []
        },
        "npaNxxList" : [ 
            {
                "npa" : {
                    "code" : "720"
                },
                "nxx" : {
                    "code" : "516"
                }
            }, 
            {
                "npa" : {
                    "code" : "303"
                },
                "nxx" : {
                    "code" : "683"
                }
            }, 
            {
                "npa" : {
                    "code" : "303"
                },
                "nxx" : {
                    "code" : "346"
                }
            }, 
            {
                "npa" : {
                    "code" : "303"
                },
                "nxx" : {
                    "code" : "471"
                }
            }, 
            {
                "npa" : {
                    "code" : "720"
                },
                "nxx" : {
                    "code" : "344"
                }
            }, 
            {
                "npa" : {
                    "code" : "720"
                },
                "nxx" : {
                    "code" : "348"
                }
            }, 
            {
                "npa" : {
                    "code" : "303"
                },
                "nxx" : {
                    "code" : "470"
                }
            }, 
            {
                "npa" : {
                    "code" : "303"
                },
                "nxx" : {
                    "code" : "791"
                }
            }
        ],
        "geoAddressId" : "238668185",
        "locationAttributes" : {
            "isMdu" : true,
            "legacyProvider" : "QWEST COMMUNICATIONS",
            "rateCenter" : "DENVER",
            "wirecenter" : "LTTNCOHL",
            "npa" : "303",
            "nxx" : "791",
            "tta" : "791",
            "cala" : "DNV",
            "tarCode" : "CO1890"
        },
        "timeZone" : {
            "name" : "Mountain Standard Time",
            "ianaName" : "America/Denver",
            "isDaylightSavingsTime" : true,
            "offset" : "-6"
        }
    },
    "availableServices" : [ 
        {
            "accessType" : "VDSL2",
            "serviceCategory" : "DATA",
            "networkInfrastructureIndicatorCode" : "FTTN-ETH-V2",
            "qualificationColorName" : "GREEN",
            "offerCategory" : "INTERNET",
            "processInfo" : [ 
                {
                    "processInfoGroupName" : "RT_DISPATCH",
                    "processInfoAttribute" : [ 
                        {
                            "name" : "REQUIRED",
                            "value" : "true"
                        }
                    ]
                }
            ]
        }
    ],
    "appointmentType" : "TI-RTD",
    "orderRefNumber" : "ORN-7166740965432967"
}
```
# Sample Response :
```sh
{
  "availableAppointment": [
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-13T08:00:00.000Z",
        "endDateTime": "2018-07-13T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-13T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-13T09:00:00.000Z",
        "endDateTime": "2018-07-13T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-13T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-13T10:00:00.000Z",
        "endDateTime": "2018-07-13T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-13T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-13T11:00:00.000Z",
        "endDateTime": "2018-07-13T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-13T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-13T12:00:00.000Z",
        "endDateTime": "2018-07-13T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-13T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-13T13:00:00.000Z",
        "endDateTime": "2018-07-13T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-13T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-14T08:00:00.000Z",
        "endDateTime": "2018-07-14T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-14T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-14T09:00:00.000Z",
        "endDateTime": "2018-07-14T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-14T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-14T10:00:00.000Z",
        "endDateTime": "2018-07-14T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-14T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-14T11:00:00.000Z",
        "endDateTime": "2018-07-14T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-14T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-14T12:00:00.000Z",
        "endDateTime": "2018-07-14T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-14T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-14T13:00:00.000Z",
        "endDateTime": "2018-07-14T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-14T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-16T08:00:00.000Z",
        "endDateTime": "2018-07-16T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-16T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-16T09:00:00.000Z",
        "endDateTime": "2018-07-16T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-16T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-16T10:00:00.000Z",
        "endDateTime": "2018-07-16T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-16T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-16T11:00:00.000Z",
        "endDateTime": "2018-07-16T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-16T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-16T12:00:00.000Z",
        "endDateTime": "2018-07-16T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-16T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-16T13:00:00.000Z",
        "endDateTime": "2018-07-16T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-16T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-17T08:00:00.000Z",
        "endDateTime": "2018-07-17T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-17T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-17T09:00:00.000Z",
        "endDateTime": "2018-07-17T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-17T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-17T10:00:00.000Z",
        "endDateTime": "2018-07-17T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-17T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-17T11:00:00.000Z",
        "endDateTime": "2018-07-17T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-17T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-17T12:00:00.000Z",
        "endDateTime": "2018-07-17T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-17T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-17T13:00:00.000Z",
        "endDateTime": "2018-07-17T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-17T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T08:00:00.000Z",
        "endDateTime": "2018-07-18T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T09:00:00.000Z",
        "endDateTime": "2018-07-18T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T10:00:00.000Z",
        "endDateTime": "2018-07-18T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T11:00:00.000Z",
        "endDateTime": "2018-07-18T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T12:00:00.000Z",
        "endDateTime": "2018-07-18T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T13:00:00.000Z",
        "endDateTime": "2018-07-18T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T08:00:00.000Z",
        "endDateTime": "2018-07-19T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T08:00:00.000Z",
        "endDateTime": "2018-07-19T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T09:00:00.000Z",
        "endDateTime": "2018-07-19T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T10:00:00.000Z",
        "endDateTime": "2018-07-19T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T11:00:00.000Z",
        "endDateTime": "2018-07-19T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T12:00:00.000Z",
        "endDateTime": "2018-07-19T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T13:00:00.000Z",
        "endDateTime": "2018-07-19T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T08:00:00.000Z",
        "endDateTime": "2018-07-20T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T08:00:00.000Z",
        "endDateTime": "2018-07-20T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T09:00:00.000Z",
        "endDateTime": "2018-07-20T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T10:00:00.000Z",
        "endDateTime": "2018-07-20T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T11:00:00.000Z",
        "endDateTime": "2018-07-20T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T12:00:00.000Z",
        "endDateTime": "2018-07-20T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T13:00:00.000Z",
        "endDateTime": "2018-07-20T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-21T08:00:00.000Z",
        "endDateTime": "2018-07-21T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-21T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T08:00:00.000Z",
        "endDateTime": "2018-07-23T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T08:00:00.000Z",
        "endDateTime": "2018-07-23T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T09:00:00.000Z",
        "endDateTime": "2018-07-23T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T10:00:00.000Z",
        "endDateTime": "2018-07-23T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T11:00:00.000Z",
        "endDateTime": "2018-07-23T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T12:00:00.000Z",
        "endDateTime": "2018-07-23T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T13:00:00.000Z",
        "endDateTime": "2018-07-23T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T08:00:00.000Z",
        "endDateTime": "2018-07-24T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T08:00:00.000Z",
        "endDateTime": "2018-07-24T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T09:00:00.000Z",
        "endDateTime": "2018-07-24T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T10:00:00.000Z",
        "endDateTime": "2018-07-24T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T11:00:00.000Z",
        "endDateTime": "2018-07-24T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T12:00:00.000Z",
        "endDateTime": "2018-07-24T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T13:00:00.000Z",
        "endDateTime": "2018-07-24T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T08:00:00.000Z",
        "endDateTime": "2018-07-25T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T08:00:00.000Z",
        "endDateTime": "2018-07-25T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T09:00:00.000Z",
        "endDateTime": "2018-07-25T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T10:00:00.000Z",
        "endDateTime": "2018-07-25T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T11:00:00.000Z",
        "endDateTime": "2018-07-25T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T12:00:00.000Z",
        "endDateTime": "2018-07-25T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T13:00:00.000Z",
        "endDateTime": "2018-07-25T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T08:00:00.000Z",
        "endDateTime": "2018-07-26T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T08:00:00.000Z",
        "endDateTime": "2018-07-26T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T09:00:00.000Z",
        "endDateTime": "2018-07-26T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T10:00:00.000Z",
        "endDateTime": "2018-07-26T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T11:00:00.000Z",
        "endDateTime": "2018-07-26T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T12:00:00.000Z",
        "endDateTime": "2018-07-26T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T13:00:00.000Z",
        "endDateTime": "2018-07-26T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T08:00:00.000Z",
        "endDateTime": "2018-07-27T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T08:00:00.000Z",
        "endDateTime": "2018-07-27T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T09:00:00.000Z",
        "endDateTime": "2018-07-27T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T10:00:00.000Z",
        "endDateTime": "2018-07-27T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T11:00:00.000Z",
        "endDateTime": "2018-07-27T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T12:00:00.000Z",
        "endDateTime": "2018-07-27T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T13:00:00.000Z",
        "endDateTime": "2018-07-27T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-28T08:00:00.000Z",
        "endDateTime": "2018-07-28T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-28T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T08:00:00.000Z",
        "endDateTime": "2018-07-30T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T08:00:00.000Z",
        "endDateTime": "2018-07-30T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T09:00:00.000Z",
        "endDateTime": "2018-07-30T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T10:00:00.000Z",
        "endDateTime": "2018-07-30T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T11:00:00.000Z",
        "endDateTime": "2018-07-30T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T12:00:00.000Z",
        "endDateTime": "2018-07-30T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T13:00:00.000Z",
        "endDateTime": "2018-07-30T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T08:00:00.000Z",
        "endDateTime": "2018-07-31T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T08:00:00.000Z",
        "endDateTime": "2018-07-31T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T09:00:00.000Z",
        "endDateTime": "2018-07-31T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T10:00:00.000Z",
        "endDateTime": "2018-07-31T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T11:00:00.000Z",
        "endDateTime": "2018-07-31T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T12:00:00.000Z",
        "endDateTime": "2018-07-31T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T13:00:00.000Z",
        "endDateTime": "2018-07-31T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T08:00:00.000Z",
        "endDateTime": "2018-08-01T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T08:00:00.000Z",
        "endDateTime": "2018-08-01T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T09:00:00.000Z",
        "endDateTime": "2018-08-01T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T10:00:00.000Z",
        "endDateTime": "2018-08-01T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T11:00:00.000Z",
        "endDateTime": "2018-08-01T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T12:00:00.000Z",
        "endDateTime": "2018-08-01T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T13:00:00.000Z",
        "endDateTime": "2018-08-01T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T08:00:00.000Z",
        "endDateTime": "2018-08-02T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T08:00:00.000Z",
        "endDateTime": "2018-08-02T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T09:00:00.000Z",
        "endDateTime": "2018-08-02T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T10:00:00.000Z",
        "endDateTime": "2018-08-02T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T11:00:00.000Z",
        "endDateTime": "2018-08-02T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T12:00:00.000Z",
        "endDateTime": "2018-08-02T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T13:00:00.000Z",
        "endDateTime": "2018-08-02T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T08:00:00.000Z",
        "endDateTime": "2018-08-03T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T08:00:00.000Z",
        "endDateTime": "2018-08-03T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T09:00:00.000Z",
        "endDateTime": "2018-08-03T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T10:00:00.000Z",
        "endDateTime": "2018-08-03T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T11:00:00.000Z",
        "endDateTime": "2018-08-03T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T12:00:00.000Z",
        "endDateTime": "2018-08-03T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T13:00:00.000Z",
        "endDateTime": "2018-08-03T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-04T08:00:00.000Z",
        "endDateTime": "2018-08-04T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-04T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T08:00:00.000Z",
        "endDateTime": "2018-08-06T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T08:00:00.000Z",
        "endDateTime": "2018-08-06T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T09:00:00.000Z",
        "endDateTime": "2018-08-06T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T10:00:00.000Z",
        "endDateTime": "2018-08-06T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T11:00:00.000Z",
        "endDateTime": "2018-08-06T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T12:00:00.000Z",
        "endDateTime": "2018-08-06T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T13:00:00.000Z",
        "endDateTime": "2018-08-06T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T08:00:00.000Z",
        "endDateTime": "2018-08-07T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T08:00:00.000Z",
        "endDateTime": "2018-08-07T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T09:00:00.000Z",
        "endDateTime": "2018-08-07T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T10:00:00.000Z",
        "endDateTime": "2018-08-07T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T11:00:00.000Z",
        "endDateTime": "2018-08-07T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T12:00:00.000Z",
        "endDateTime": "2018-08-07T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T13:00:00.000Z",
        "endDateTime": "2018-08-07T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T08:00:00.000Z",
        "endDateTime": "2018-08-08T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T08:00:00.000Z",
        "endDateTime": "2018-08-08T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T09:00:00.000Z",
        "endDateTime": "2018-08-08T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T10:00:00.000Z",
        "endDateTime": "2018-08-08T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T11:00:00.000Z",
        "endDateTime": "2018-08-08T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T12:00:00.000Z",
        "endDateTime": "2018-08-08T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T13:00:00.000Z",
        "endDateTime": "2018-08-08T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T08:00:00.000Z",
        "endDateTime": "2018-08-09T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T08:00:00.000Z",
        "endDateTime": "2018-08-09T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T09:00:00.000Z",
        "endDateTime": "2018-08-09T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T10:00:00.000Z",
        "endDateTime": "2018-08-09T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T11:00:00.000Z",
        "endDateTime": "2018-08-09T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T12:00:00.000Z",
        "endDateTime": "2018-08-09T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T13:00:00.000Z",
        "endDateTime": "2018-08-09T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T19:45:00.000Z",
      "timeSlotSource": "EOS"
    }
  ]
}
```


# Sample Request for Post(Reserve Appointment):
```sh
{
  "availableAppointment": {
      "appointmentId": "TLRG247Q",
      "timeSlot": {
        "startDateTime": "2018-07-13T08:00:00.000Z",
        "endDateTime": "2018-07-13T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-13T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
  "orderRefNumber": "ORN-7166740965432967"
}
```

# Sample Response :
```sh
{
  "reservationId": "TLRG247Q01"
}
```


# Sample Request for Post(Get More Appointment Slots):
```sh
{
  "orderRefNumber": "ORN-7166740965432967",
  "startDateTime": "2018-07-18T08:00:00.000Z"
}
```

# Sample Response :
```sh
{
  "availableAppointment": [
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T08:00:00.000Z",
        "endDateTime": "2018-07-18T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T09:00:00.000Z",
        "endDateTime": "2018-07-18T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T10:00:00.000Z",
        "endDateTime": "2018-07-18T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T11:00:00.000Z",
        "endDateTime": "2018-07-18T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T12:00:00.000Z",
        "endDateTime": "2018-07-18T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-18T13:00:00.000Z",
        "endDateTime": "2018-07-18T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-18T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T08:00:00.000Z",
        "endDateTime": "2018-07-19T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T08:00:00.000Z",
        "endDateTime": "2018-07-19T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T09:00:00.000Z",
        "endDateTime": "2018-07-19T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T10:00:00.000Z",
        "endDateTime": "2018-07-19T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T11:00:00.000Z",
        "endDateTime": "2018-07-19T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T12:00:00.000Z",
        "endDateTime": "2018-07-19T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-19T13:00:00.000Z",
        "endDateTime": "2018-07-19T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-19T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T08:00:00.000Z",
        "endDateTime": "2018-07-20T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T08:00:00.000Z",
        "endDateTime": "2018-07-20T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T09:00:00.000Z",
        "endDateTime": "2018-07-20T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T10:00:00.000Z",
        "endDateTime": "2018-07-20T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T11:00:00.000Z",
        "endDateTime": "2018-07-20T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T12:00:00.000Z",
        "endDateTime": "2018-07-20T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-20T13:00:00.000Z",
        "endDateTime": "2018-07-20T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-20T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-21T08:00:00.000Z",
        "endDateTime": "2018-07-21T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-21T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T08:00:00.000Z",
        "endDateTime": "2018-07-23T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T08:00:00.000Z",
        "endDateTime": "2018-07-23T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T09:00:00.000Z",
        "endDateTime": "2018-07-23T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T10:00:00.000Z",
        "endDateTime": "2018-07-23T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T11:00:00.000Z",
        "endDateTime": "2018-07-23T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T12:00:00.000Z",
        "endDateTime": "2018-07-23T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-23T13:00:00.000Z",
        "endDateTime": "2018-07-23T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-23T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T08:00:00.000Z",
        "endDateTime": "2018-07-24T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T08:00:00.000Z",
        "endDateTime": "2018-07-24T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T09:00:00.000Z",
        "endDateTime": "2018-07-24T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T10:00:00.000Z",
        "endDateTime": "2018-07-24T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T11:00:00.000Z",
        "endDateTime": "2018-07-24T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T12:00:00.000Z",
        "endDateTime": "2018-07-24T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-24T13:00:00.000Z",
        "endDateTime": "2018-07-24T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-24T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T08:00:00.000Z",
        "endDateTime": "2018-07-25T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T08:00:00.000Z",
        "endDateTime": "2018-07-25T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T09:00:00.000Z",
        "endDateTime": "2018-07-25T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T10:00:00.000Z",
        "endDateTime": "2018-07-25T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T11:00:00.000Z",
        "endDateTime": "2018-07-25T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T12:00:00.000Z",
        "endDateTime": "2018-07-25T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-25T13:00:00.000Z",
        "endDateTime": "2018-07-25T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-25T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T08:00:00.000Z",
        "endDateTime": "2018-07-26T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T08:00:00.000Z",
        "endDateTime": "2018-07-26T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T09:00:00.000Z",
        "endDateTime": "2018-07-26T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T10:00:00.000Z",
        "endDateTime": "2018-07-26T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T11:00:00.000Z",
        "endDateTime": "2018-07-26T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T12:00:00.000Z",
        "endDateTime": "2018-07-26T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-26T13:00:00.000Z",
        "endDateTime": "2018-07-26T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-26T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T08:00:00.000Z",
        "endDateTime": "2018-07-27T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T08:00:00.000Z",
        "endDateTime": "2018-07-27T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T09:00:00.000Z",
        "endDateTime": "2018-07-27T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T10:00:00.000Z",
        "endDateTime": "2018-07-27T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T11:00:00.000Z",
        "endDateTime": "2018-07-27T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T12:00:00.000Z",
        "endDateTime": "2018-07-27T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-27T13:00:00.000Z",
        "endDateTime": "2018-07-27T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-27T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-28T08:00:00.000Z",
        "endDateTime": "2018-07-28T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-28T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T08:00:00.000Z",
        "endDateTime": "2018-07-30T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T08:00:00.000Z",
        "endDateTime": "2018-07-30T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T09:00:00.000Z",
        "endDateTime": "2018-07-30T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T10:00:00.000Z",
        "endDateTime": "2018-07-30T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T11:00:00.000Z",
        "endDateTime": "2018-07-30T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T12:00:00.000Z",
        "endDateTime": "2018-07-30T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-30T13:00:00.000Z",
        "endDateTime": "2018-07-30T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-30T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T08:00:00.000Z",
        "endDateTime": "2018-07-31T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T08:00:00.000Z",
        "endDateTime": "2018-07-31T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T09:00:00.000Z",
        "endDateTime": "2018-07-31T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T10:00:00.000Z",
        "endDateTime": "2018-07-31T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T11:00:00.000Z",
        "endDateTime": "2018-07-31T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T12:00:00.000Z",
        "endDateTime": "2018-07-31T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-07-31T13:00:00.000Z",
        "endDateTime": "2018-07-31T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-07-31T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T08:00:00.000Z",
        "endDateTime": "2018-08-01T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T08:00:00.000Z",
        "endDateTime": "2018-08-01T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T09:00:00.000Z",
        "endDateTime": "2018-08-01T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T10:00:00.000Z",
        "endDateTime": "2018-08-01T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T11:00:00.000Z",
        "endDateTime": "2018-08-01T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T12:00:00.000Z",
        "endDateTime": "2018-08-01T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-01T13:00:00.000Z",
        "endDateTime": "2018-08-01T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-01T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T08:00:00.000Z",
        "endDateTime": "2018-08-02T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T08:00:00.000Z",
        "endDateTime": "2018-08-02T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T09:00:00.000Z",
        "endDateTime": "2018-08-02T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T10:00:00.000Z",
        "endDateTime": "2018-08-02T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T11:00:00.000Z",
        "endDateTime": "2018-08-02T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T12:00:00.000Z",
        "endDateTime": "2018-08-02T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-02T13:00:00.000Z",
        "endDateTime": "2018-08-02T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-02T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T08:00:00.000Z",
        "endDateTime": "2018-08-03T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T08:00:00.000Z",
        "endDateTime": "2018-08-03T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T09:00:00.000Z",
        "endDateTime": "2018-08-03T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T10:00:00.000Z",
        "endDateTime": "2018-08-03T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T11:00:00.000Z",
        "endDateTime": "2018-08-03T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T12:00:00.000Z",
        "endDateTime": "2018-08-03T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-03T13:00:00.000Z",
        "endDateTime": "2018-08-03T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-03T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-04T08:00:00.000Z",
        "endDateTime": "2018-08-04T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-04T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T08:00:00.000Z",
        "endDateTime": "2018-08-06T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T08:00:00.000Z",
        "endDateTime": "2018-08-06T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T09:00:00.000Z",
        "endDateTime": "2018-08-06T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T10:00:00.000Z",
        "endDateTime": "2018-08-06T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T11:00:00.000Z",
        "endDateTime": "2018-08-06T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T12:00:00.000Z",
        "endDateTime": "2018-08-06T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-06T13:00:00.000Z",
        "endDateTime": "2018-08-06T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-06T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T08:00:00.000Z",
        "endDateTime": "2018-08-07T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T08:00:00.000Z",
        "endDateTime": "2018-08-07T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T09:00:00.000Z",
        "endDateTime": "2018-08-07T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T10:00:00.000Z",
        "endDateTime": "2018-08-07T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T11:00:00.000Z",
        "endDateTime": "2018-08-07T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T12:00:00.000Z",
        "endDateTime": "2018-08-07T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-07T13:00:00.000Z",
        "endDateTime": "2018-08-07T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-07T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T08:00:00.000Z",
        "endDateTime": "2018-08-08T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T08:00:00.000Z",
        "endDateTime": "2018-08-08T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T09:00:00.000Z",
        "endDateTime": "2018-08-08T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T10:00:00.000Z",
        "endDateTime": "2018-08-08T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T11:00:00.000Z",
        "endDateTime": "2018-08-08T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T12:00:00.000Z",
        "endDateTime": "2018-08-08T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-08T13:00:00.000Z",
        "endDateTime": "2018-08-08T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-08T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T08:00:00.000Z",
        "endDateTime": "2018-08-09T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T08:00:00.000Z",
        "endDateTime": "2018-08-09T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T09:00:00.000Z",
        "endDateTime": "2018-08-09T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T10:00:00.000Z",
        "endDateTime": "2018-08-09T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T11:00:00.000Z",
        "endDateTime": "2018-08-09T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T12:00:00.000Z",
        "endDateTime": "2018-08-09T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-09T13:00:00.000Z",
        "endDateTime": "2018-08-09T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-09T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-10T08:00:00.000Z",
        "endDateTime": "2018-08-10T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-10T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-10T08:00:00.000Z",
        "endDateTime": "2018-08-10T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-10T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-10T09:00:00.000Z",
        "endDateTime": "2018-08-10T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-10T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-10T10:00:00.000Z",
        "endDateTime": "2018-08-10T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-10T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-10T11:00:00.000Z",
        "endDateTime": "2018-08-10T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-10T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-10T12:00:00.000Z",
        "endDateTime": "2018-08-10T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-10T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-10T13:00:00.000Z",
        "endDateTime": "2018-08-10T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-10T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-11T08:00:00.000Z",
        "endDateTime": "2018-08-11T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-11T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-13T08:00:00.000Z",
        "endDateTime": "2018-08-13T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-13T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-13T08:00:00.000Z",
        "endDateTime": "2018-08-13T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-13T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-13T09:00:00.000Z",
        "endDateTime": "2018-08-13T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-13T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-13T10:00:00.000Z",
        "endDateTime": "2018-08-13T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-13T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-13T11:00:00.000Z",
        "endDateTime": "2018-08-13T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-13T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-13T12:00:00.000Z",
        "endDateTime": "2018-08-13T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-13T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-13T13:00:00.000Z",
        "endDateTime": "2018-08-13T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-13T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-14T08:00:00.000Z",
        "endDateTime": "2018-08-14T18:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-14T19:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-14T08:00:00.000Z",
        "endDateTime": "2018-08-14T12:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-14T14:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-14T09:00:00.000Z",
        "endDateTime": "2018-08-14T13:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-14T15:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-14T10:00:00.000Z",
        "endDateTime": "2018-08-14T14:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-14T16:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-14T11:00:00.000Z",
        "endDateTime": "2018-08-14T15:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-14T17:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-14T12:00:00.000Z",
        "endDateTime": "2018-08-14T16:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-14T18:45:00.000Z",
      "timeSlotSource": "EOS"
    },
    {
      "appointmentId": "S9JM247Q",
      "timeSlot": {
        "startDateTime": "2018-08-14T13:00:00.000Z",
        "endDateTime": "2018-08-14T17:00:00.000Z"
      },
      "timeSlotType": "TI-RTD",
      "commitmentDateTime": "2018-08-14T19:45:00.000Z",
      "timeSlotSource": "EOS"
    }
  ]
}
```


# Sample Request for Post(Cancel Appointment):
```sh
{
  "orderRefNumber": "ORN-7166740965432967",
  "reservationId": "TLRG247Q01"
}
```

# Sample Response :
```sh
{
  "appointmentInquiryResponseNumber": "TLRG247Q01",
  "responseMessage": "Appointment Cancelled"
}
```