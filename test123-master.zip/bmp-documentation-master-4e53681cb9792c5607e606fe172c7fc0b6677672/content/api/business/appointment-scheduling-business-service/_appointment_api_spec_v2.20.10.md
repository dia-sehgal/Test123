Appointment Business Service - Reserve
======================================
    Version: 2.20.10

[Request /appointment/retrieve](#Request)

[Response /appointment/retrieve](#Response)

    
Overview
--------

This service is used to reserve a selected appointment slot for Tech dispatch
when Tech installation is required for a service. The selected appointment slot
is send to CTS(southbound system) to allocate the slot for a particular service
request.

![](media/AppointmentDiagram.png)

### Request Syntax


For each resource, the following items are documented.

| Name           | Value         |
|:---------------|:--------------|
| HTTP Method    | post          |
| Base URI       | /appointment/ |
| URI Syntax     |               |
| Operation Name | /reserve      |

Operation Details (Request/Response)
------------------------------------

### Required Attributes

The following attributes present in the API request/responses for **/appointment/retrieve** service are mandatory.

This is the request JSON that is sent to EOS to reserve the selected appointment
date, which in turn sends the request to CTS.

Request
===========
    {
     "orderRefNumber": "string",
     "availableAppointment": {
     "id": "ARNV1241439962SQ112",
     "timeSlot": {
      "startDateTime": "2018-07-02T10:17:16.238Z",
      "endDateTime": "2018-07-02T10:17:16.238Z"
     },
      "commitmentDateTime": "2018-07-02T10:17:16.238Z",
      "timeSlotType": "SI-RTD",
      "timeSlotSource": "DGW"
     }
    }

Response
============

    {
     "reservationId": "113267"
    }

Error Response
==================
    {
     "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
      }
     ]
    }


| Name           | Value         |
|:---------------|:--------------|
| HTTP Method    | post          |
| Base URI       | /appointment/ |
| URI Syntax     |               |
| Operation Name | /retrieve     |

Operation Details (Request/Response)
------------------------------------

### Required Attributes

The following attributes present in the API request/responses for **/appointment/retrieve** service are mandatory.

**Description**

This is the request JSON that is sent to RetrieveAvailableRequest by consuming
client (EOS) to get all the available appointment slots.

Request
=============
    {
    "customerOrderType": "NEW INSTALL",
    "appointmentType": "string",
    "orderRefNumber": "string",
    "noOfComputers": "2",
    "availableServices": [
    {
      "offerCategory": "INTERNET",
      "serviceCategory": "DATA",
      "accessType": "ADSL2+",
      "networkInfrastructureIndicatorCode": "FTTN-ETH-A2P",
      "iptvPipeRateDownSpeed": "string",
      "iptvPipeRateUpSpeed": "string",
      "qualificationColorName": "string",
      "processInfo": [
        {
          "processInfoGroupName": "string",
          "processInfoAttribute": [
            {
              "name": "string",
              "value": "string"
            }
          ]
        }
      ]
     }
    ],
    "productOfferDetails": [
    {
      "productOfferingId": "string",
      "offerCategory": "DATA",
      "quantity": 0,
      "action": "ADD",
      "rc": 0,
      "otc": 0,
      "discountedRc": 0,
      "discountedOtc": 0,
      "productDetails": [
        {
          "productId": "string",
          "productName": "string",
          "productType": "HSI",
          "componentType": "Primary",
          "productCategory": "string",
          "action": "ADD",
          "productAttributes": [
            {
              "compositeAttributes": [
                {
                  "attributeName": "string",
                  "attributeValue": "string",
                  "uom": "string"
                }
              ]
            }
          ]
        }
      ]
     }
    ],
    "address": {
    "addressId": "CLSPCOMA1NT9V.1",
    "streetAddress": "918 N ROYER ST",
    "streetNrFirst": 918,
    "streetNrFirstSuffix": "string",
    "streetNrLast": "string",
    "streetNrLastSuffix": "string",
    "streetName": "ROYER",
    "streetNamePrefix": "E",
    "streetType": "ST",
    "locality": "COLORADO SPRINGS",
    "city": "COLORADO SPRINGS",
    "stateOrProvince": "CO",
    "postCode": 80903,
    "postCodeSuffix": "string",
    "sourceId": "string",
    "source": "LFACS",
    "geoAddressId": "string",
    "subAddress": {
      "sourceId": "CLSPCOMA1NT9V.1",
      "source": "Trillium",
      "geoSubAddressId": 1,
      "combinedDesignator": "BLDG SHOP",
      "elements": [
        {
          "designator": "APT",
          "value": 2
        }
      ]
    },
    "country": "USA",
    "geoPoint": [
      {
        "source": "Trillium",
        "latitude": 38.84703,
        "longitude": -104.814561,
        "coordinateLevel": 1,
        "accuracy": 1
      }
    ],
    "npaNxxList": [
      {
        "npa": {
          "code": "303"
        },
        "nxx": {
          "code": "291"
        }
      }
    ],
    "locationAttributes": {
      "isMdu": true,
      "legacyProvider": "string",
      "rateCenter": "string",
      "npa": 318,
      "nxx": 340,
      "wirecenter": "CLSPCOMA",
      "cala": "SCO",
      "tarCode": "NV0200",
      "tta": {}
    },
    "timeZone": {
      "name": "US Mountain Standard Time",
      "ianaName": "America/Denver",
      "isDaylightSavingsTime": false,
      "offset": -7
     }
    },
    "requestedDueDate": {
     "startDateTime": "2018-07-02T10:55:02.576Z",
     "endDateTime": "2018-07-02T10:55:02.576Z"
    },
      "tnInfo": {
      "tnType": "EXTPORTED"
     }
    }

Response
=============
    {
    "availableAppointment": [    
    {
      "id": "ARNV1241439962SQ112",
      "timeSlot": {
        "startDateTime": "2018-07-02T10:55:02.597Z",
        "endDateTime": "2018-07-02T10:55:02.597Z"
      },
      "commitmentDateTime": "2018-07-02T10:55:02.597Z",
      "timeSlotType": "SI-RTD",
      "timeSlotSource": "DGW"
      }  
     ]
    }      

Error Response
==================
    {
    "availableAppointment": [
      {
      "id": "ARNV1241439962SQ112",
      "timeSlot": {
        "startDateTime": "2018-07-02T10:55:02.597Z",
        "endDateTime": "2018-07-02T10:55:02.597Z"
      },
      "commitmentDateTime": "2018-07-02T10:55:02.597Z",
      "timeSlotType": "SI-RTD",
      "timeSlotSource": "DGW"
      }
     ]
    }   {
    "errorResponse": [
      {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
      }
     ]
    }


| HTTP Status Code (BM) | BM Reason Code                | Message Text   |
|:----------------------|:------------------------------|:---------------|
| 400                   | APPT_INQUIRY_VALIDATION_ERROR | Contains any xsd validation errors in request                                   |
| 400                   | INVALID_SERVICE_ADDRESS       | Service Address cannot be empty or null                                         |
| 400                   | INVALID_PRODUCT_QUANTITY      | Product Quantity should have integer value greater than 0                       |
| 400                   | INVALID_STATE_OR_PROVINCE     | State or Province cannot be null or empty                                       |
| 400                   | INVALID_MARKET_SEGMENT        | Market Segment should be 1 or 2                                                 |
| 400                   | INVALID_STREET_NAME           | Street name is required for facility check                                      |
| 400                   | INVALID_SITE_ID               | Site id is required for facility check                                          |
| 400                   | INVALID_REGION                | Region is required for SIBS call                                                |
| 400                   | INVALID_DESIRED_DUEDATE       | DesiredDueDate can not be earlier than EarliestDueDate                          |
| 400                   | INVALID_PORT_INDICATOR        | Port Indicator must be NO If NoSIBSCall is true                                 |
| 400                   |                               |                                                                                 |
| 401                   | AUTHENTICATION_FAILURE        | Authentication failed due to invalid authentication credential                  |
| 404                   | RESOURCE_NOT_FOUND            | No Appointments were found for the given criteria                               |
| 503                   | EOS_SERVER_UNAVAILABLE        | The server cannot handle the request for a service due to temporary maintenance |
| 502                   | FAC_CHECK_SERVER_ERROR        | Error calling Facility Check external system                                    |
| 502                   | SIBS_SERVER_ERROR             | Error calling SIBS external system                                              |
| 502                   | APPT_INQUIRY_SERVER_ERROR     | Error calling native Appt Inquiry external system                               |
| 502                   | UNKNOWN_SERVER_ERROR          | Unknown downstream error                                                        |
| 502                   | EOS_SERVER_UNAVAILABLE        | The server cannot handle the request for a service due to temporary maintenance |
| 502                   | FAC_CHECK_SERVER_ERROR        | Error calling Facility Check external system                                    |
| 502                   | SIBS_SERVER_ERROR             | Error calling SIBS external system                                              |
| 502                   | APPT_INQUIRY_SERVER_ERROR     | Error calling native Appt Inquiry external system                               |
| 502                   | UNKNOWN_SERVER_ERROR          | Unknown downstream error                                                        |
