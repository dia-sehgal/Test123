---
title: "Order Checkout"
date: 2018-06-24T09:51:24-07:00
draft: false
---


This service is a generic service to save order document at multiple stages in project.
Currently it deals with Service Availability, BRMS rules, reverse translation and order status update service.
	
This consists of 36 APIs -  
 
  1) **/bsi/customerOrder/createNew** - This API creates a new blank order document and generates unique Order Reference Number (ORN) using time stamp, 
		which is used by other calling services to get order related information.  
 
  2) **/bsi/customerOrder/addPartyAddress** - This API updates the validated address in the related order document and saved in DB against the ORN.  
 
  3) **/bsi/customerOrder/addAvailableServices** - After address is validated for that user by address validation service, we need to find available services for that address. Depending on data category selected by user, all available services will be displayed to user with following attributes like up speed, down speed etc.To get information regarding available services this API internally calls service availability BM service.
 
  4) **/bsi/customerOrder/{customerOrderReferenceNumber}** - This API accepts ORN and sends back the related order document.
 
  5) **/bsi/customerOrder/orderAdditionalInfo** - This API is to store additional info like order remarks captured on order summary page during ordering journey.
 
  6) **/bsi/customerOrder/saveOrderReference** - This API Updates the Order Reference in customer order related to ORN.
 
  7) **/bsi/customerOrder/saveBillEstimate** - This API saves bill related information.
 
  8) **/bsi/customerOrder/saveDHPAdditionalInfo** - This API Update a CustomerOrder object to add E911 address and additional DHP information.
 
  9) **/bsi/customerOrder/submitOrder** - This is the last step in completion of order. This API submits the complete order and generates customer Order Number (CON). Also it initializes contract start date.
 
  10) **/bsi/customerOrder/saveAccountInfo** - Thiws API persist customers Credit information based on the credit check on order document.
 
  11) **/bsi/customerOrder/updateBanInfo** - This API persist customers Ban(account number) on order document.
 
  12) **/bsi/customerOrder/updateCreditInfo** - This API update the Credit info on order document against ORN.
 
  13) **/bsi/customerOrder/updateNameInfo** - This API Update a CustomerOrder object to update customer name information.
 
  14) **/bsi/customerOrder/updatePersonalInfo** - This API Update a CustomerOrder object to update customer personal information.
 
  15) **/bsi/customerOrder/getInstallmentBillingInfo** - This API gives installment billing information for given ORN. To get all billing related information internally it calls BRMS rules service. It returns a list of installments which is sent back to camunda.
 
  16) **/bsi/customerOrder/saveAddlOrderAttributes** - This API Stores Additional Order Attributes on Order Document which is selected by user from the list provided.
 
  17) **/bsi/customerOrder/saveCreditInfo** - This API persist customer's Credit information on Order Document.
 
  18) **/bsi/customerOrder/saveDepositInfo** - This API persist customer's deposit information on Order Document.
 
  19) **/bsi/customerOrder/savePayment** - This API persist customer's Payment information on Order Document.
 
  20) **/bsi/customerOrder/saveConfigInfo** - Any configuration values for each service ordered will be stored in the order document using above API.
 
  21) **/bsi/customerOrder/saveReservedTN** - This API Update a CustomerOrder object to add reserved Telephone Number.
 
  22) **/bsi/customerOrder/getCart** - This API will return complete cart information for given ORN.
 
  23) **/bsi/customerOrder/getProductDetails** - This API will return complete Product details information for given ORN.
 
  24) **/bsi/customerOrder/saveCart** - This API saves all user selected cart against given ORN.
 
  25) **/bsi/customerOrder/updateCartItem** - This API updates cart by comparing old and new cart when user changes in item or item attribute in cart against ORN.
 
  26) **/bsi/customerOrder/updateCartItems** - This API updates cart by comparing old and new cart when user changes in item or item attribute in cart against ORN.
 
  27) **/bsi/customerOrder/updateProductAttirbutes** - This API updates product attributes and composite attributes by comparing with existing services available in Order Document against given ORN.
 
  28) **/bsi/customerOrder/getFeatureDescription** - This API returns all features for Product present in order for given ORN.
 
  30) **/bsi/customerOrder/replicateOrder** - This API replicates customer order with new ORN.Update some parameters to null such as order date, hold date, additional information, schedule information, charges etc. for MACD order only.Copies item information to existing list in order document object.
 
  31) **/bsi/customerOrder/getReturnEquipments** - This API calculates return date for the equipments added in order.Also saves Return equipment list in customer order document depending on Items and sub items added in order which it gets from BRMS rules service.
 
  32) **/bsi/customerOrder/addShippingAddress** - This API update order document with newly captured and validated address for shipping.
 
  33) **/bsi/customerOrder/saveAppointmentNotes** - This API persist customer appointment notes if any.
 
  34) **/bsi/customerOrder/saveAppointment** - This API persist customer selected appointment time slot on to the order document. Appointment time slot has startDateTime and endDateTime.
 
  35) **/bsi/customerOrder/saveDueDate** - This API persist customer service due date on to the order document.Due date can be customer requested due date or the system generated due date based on due date rules.
 
  36) **/bsi/customerOrder/saveSchedulingAssessment** - This API save all scheduling assessment related information like is shipping required or not or is appointment required or not.
  
# Installation :
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
    - Visit [Oracle] website to get the Oracle JDBC driver â€“ ojdbc6.jar or ojdbc7.jar
    - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} 
      -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar     
 
# SetUp : 
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/order-business-service-checkout.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run    
```

# Dependent systems :
   Service Availability Business Service
   	prod: https://bmp-service-availability-business-service.pcfmrnctl.dev.intranet/bsi/getAvailableServices
    e2e: https://bmp-service-availability-business-service-ctle2e.pcfmrnctl.dev.intranet/bsi/getAvailableServices
    
   Bill Quote Business Service
   	prod: https://bmp-billquote-business-service.pcfmrnctl.dev.intranet/bsi/reverseTranslation
    e2e: https://bmp-billquote-business-service-ctle2e.pcfmrnctl.dev.intranet/bsi/reverseTranslation
    
   Return Equipment Rule Service
   	prod: https://bmp-returnequipment-rule-service.pcfmrnctl.dev.intranet/bsi/ReturnEquipment/v1
    e2e: https://bmp-returnequipment-rule-service-ctle2e.pcfmrnctl.dev.intranet/bsi/ReturnEquipment/v1
    
   OTC Installments Rule Service
   	prod: https://bmp-otcinstallments-rule-service.pcfmrnctl.dev.intranet/bsi/OtcInstallments/v1
    e2e: https://bmp-otcinstallments-rule-service-ctle2e.pcfmrnctl.dev.intranet/bsi/OtcInstallments/v1
    
   Order Status Update Business Service
   	prod: https://bmp-order-status-update-business-service.pcfmrnctl.dev.intranet
    e2e: https://bmp-order-status-update-business-service-ctle2e.pcfmrnctl.dev.intranet
    
# CI/CD Pipeline Details :
* Name:	 bmp-order-business-service-checkout
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000

* Sonarqube Project URL:	 TBD

* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 https://ne1itcprhas62.ne1.savvis.net/BMP_DEV/order-business-service-checkout/blob/release/final/Jenkinsfile     

# Cloud Environment Details   
* Cloud Group Name:	 BMCO-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-order-business-service-checkout-test3.pcfmrnctl.dev.intranet

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/  

# Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards 

# Swagger URL :
```sh
https://bmp-order-business-service-checkout-test3.pcfmrnctl.dev.intranet
```