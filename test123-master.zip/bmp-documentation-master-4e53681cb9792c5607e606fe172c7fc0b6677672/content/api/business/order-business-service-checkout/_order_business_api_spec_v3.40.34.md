Order Business Service 
=======================
    Version: 3.40.34

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /saveCart](#Request)
- [Response /saveCart](#Response)

Overview
=========

> ~~Place an Order business service is used to validate the service address and postal address as per geography.~~

Request Syntax
--------------

For each resource, the following items are documented.

| Name           | Value     |
|:---------------|:----------|
| HTTP Method    | put       |
| Base URI       | /bsi      |
| URI Syntax     |           |
| Operation Name | /saveCart |

Operation Details (Request/Response)
------------------------------------

#### Request and Response Formats

    API: saveCart

Request
=======
```sh
{
  "orderReferenceNumber": "string",
  "customerOrderItems": [
    {
      "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
      "productOfferingId": "string",
      "offerName": "string",
      "offerType": "BUNDLE",
      "offerSubType": "REGULAR",
      "offerCategory": "INTERNET",
      "quantity": 0,
      "action": "ADD",
      "contractStartDate": "2018-07-03T06:04:10.354Z",
      "contractTerm": 24,
      "rc": 0,
      "otc": 0,
      "discountedRc": 0,
      "discountedOtc": 0,
      "customerOrderSubItems": [
        {
          "productId": "string",
          "productName": "string",
          "productType": "INTERNET",
          "componentType": "PRIMARY",
          "productCategory": "CORE",
          "quantity": 1,
          "action": "ADD",
          "provisioningAction": "PROVISIONnBILL",
          "productAttributes": [
            {
              "compositeAttribute": [
                {
                  "attributeName": "downSpeed",
                  "attributeValue": 40128,
                  "uom": "Kbps"
                }
              ],
              "isDefault": 0,
              "displayOrder": 1,
              "isPriceable": true,
              "prices": [
                {
                  "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                  "priceType": "SUBSCRIPTION",
                  "priceTypeDescription": "string",
                  "rc": 39.99,
                  "otc": 69.99,
                  "discountedRc": 29.99,
                  "discountedOtc": 49.99,
                  "frequency": "PERMONTH",
                  "currencyCode": "USD",
                  "provisioningAction": "PROVISIONnBILL"
                }
              ],
              "discounts": [
                {
                  "autoAttachInd": "Y",
                  "discountId": "VP510",
                  "discountDescription": "Discount Description VP510",
                  "discountRate": 50,
                  "discountMethod": "FLATAMOUNT",
                  "discountLevel": "P",
                  "discountDuration": 1,
                  "discountType": "P",
                  "discountCategory": "OTD",
                  "discountMaxAmount": 150,
                  "discountRule": "ANY",
                  "discountMinimumAmount": 50,
                  "discountIdSequence": 2
                }
              ]
            }
          ],
          "productAssociations": [
            {
              "productAssociationType": "COMPATIBLE",
              "productIds": [
                {
                  "productId": "string"
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```
Response 
========
```sh
{
  "orderReferenceNumber": "string",
  "customerOrderItems": [
    {
      "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
      "productOfferingId": "string",
      "offerName": "string",
      "offerType": "BUNDLE",
      "offerSubType": "REGULAR",
      "offerCategory": "INTERNET",
      "quantity": 0,
      "action": "ADD",
      "contractStartDate": "2018-07-03T11:09:45.674Z",
      "contractTerm": 24,
      "rc": 0,
      "otc": 0,
      "discountedRc": 0,
      "discountedOtc": 0,
      "customerOrderSubItems": [
        {
          "productId": "string",
          "productName": "string",
          "productType": "INTERNET",
          "componentType": "PRIMARY",
          "productCategory": "CORE",
          "quantity": 1,
          "action": "ADD",
          "provisioningAction": "PROVISIONnBILL",
          "productAttributes": [
            {
              "compositeAttribute": [
                {
                  "attributeName": "downSpeed",
                  "attributeValue": 40128,
                  "uom": "Kbps"
                }
              ],
              "isDefault": 0,
              "displayOrder": 1,
              "isPriceable": true,
              "prices": [
                {
                  "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                  "priceType": "SUBSCRIPTION",
                  "priceTypeDescription": "string",
                  "rc": 39.99,
                  "otc": 69.99,
                  "discountedRc": 29.99,
                  "discountedOtc": 49.99,
                  "frequency": "PERMONTH",
                  "currencyCode": "USD",
                  "provisioningAction": "PROVISIONnBILL"
                }
              ],
              "discounts": [
                {
                  "autoAttachInd": "Y",
                  "discountId": "VP510",
                  "discountDescription": "Discount Description VP510",
                  "discountRate": 50,
                  "discountMethod": "FLATAMOUNT",
                  "discountLevel": "P",
                  "discountDuration": 1,
                  "discountType": "P",
                  "discountCategory": "OTD",
                  "discountMaxAmount": 150,
                  "discountRule": "ANY",
                  "discountMinimumAmount": 50,
                  "discountIdSequence": 2
                }
              ]
            }
          ],
          "productAssociations": [
            {
              "productAssociationType": "COMPATIBLE",
              "productIds": [
                {
                  "productId": "string"
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```
Error Response 
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

| API           | /saveCart                              |
|:--------------|:---------------------------------------|
| Error Code    | 400                                    |
| Error Message | Save Cart failed; returns Error object |

Product Ordering API
--------------------

**Service Name: Order Business Service**

| Name           | Value                          |
|:---------------|:-------------------------------|
| HTTP Method    | post                           |
| Base URI       | /bsi/AddressBusinessService/v1 |
| URI Syntax     |                                |
| Operation Name | /submitOrder                   |

#### Request and Response Formats

    API: /submitOrder

Request
============
```sh
{
  "salesChannel": "ESHOP",
  "sfdcAccountId": "",
  "pointOfNoReturn": true,
  "customerOrderType": "NEWINSTALL",
  "customerType": "Individual",
  "customerSegment": "string",
  "processInstanceId": "string",
  "orderReferenceNumber": "string",
  "customerOrderStatus": "string",
  "supType": "string",
  "lastCustomerOrderNumber": "string",
  "lastORN": "string",
  "customerOrderNumber": "string",
  "businessInteractionId": "string",
  "reason": [
    {
      "code": "ASYMIS",
      "description": "Due Date Miskey",
      "waiverFlag": "No",
      "reasonType": "string",
      "reasonText": "string",
      "offerCategory": "string",
      "terminationFee": "string",
      "currencyCode": "string"
    }
  ],
  "partyRole": {
    "partyRoleId": "string",
    "partyRoleName": "string",
    "partyCsrId": "string"
  },
  "orderDate": "2018-07-04T06:29:55.792Z",
  "orderVersion": "1",
  "sourceSystem": "BLUEMARBLE",
  "holdDate": "2018-07-04T06:29:55.793Z",
  "holdExpirationDate": "2018-07-04T06:29:55.793Z",
  "cancelDate": "2018-07-04T06:29:55.793Z",
  "documentControl": {
    "docVersion": "string",
    "docLastModifiedDate": "string"
  }
}
{
  "id": "string",
  "orderReference": {
    "salesChannel": "ESHOP",
    "sfdcAccountId": "",
    "pointOfNoReturn": true,
    "customerOrderType": "NEWINSTALL",
    "customerType": "Individual",
    "customerSegment": "string",
    "processInstanceId": "string",
    "orderReferenceNumber": "string",
    "customerOrderStatus": "string",
    "supType": "string",
    "lastCustomerOrderNumber": "string",
    "lastORN": "string",
    "customerOrderNumber": "string",
    "businessInteractionId": "string",
    "reason": [
      {
        "code": "ASYMIS",
        "description": "Due Date Miskey",
        "waiverFlag": "No",
        "reasonType": "string",
        "reasonText": "string",
        "offerCategory": "string",
        "terminationFee": "string",
        "currencyCode": "string"
      }
    ],
    "partyRole": {
      "partyRoleId": "string",
      "partyRoleName": "string",
      "partyCsrId": "string"
    },
    "orderDate": "2018-07-04T06:31:28.008Z",
    "orderVersion": "1",
    "sourceSystem": "BLUEMARBLE",
    "holdDate": "2018-07-04T06:31:28.008Z",
    "holdExpirationDate": "2018-07-04T06:31:28.008Z",
    "cancelDate": "2018-07-04T06:31:28.008Z",
    "documentControl": {
      "docVersion": "string",
      "docLastModifiedDate": "string"
    }
  },
  "orderDocument": {
    "serviceAddress": {
      "addressId": 0,
      "streetAddress": "918 ROYER ST",
      "streetNrFirst": "918",
      "streetNrFirstSuffix": "string",
      "streetNrLast": "string",
      "streetNrLastSuffix": "string",
      "streetName": "ROYER",
      "streetNamePrefix": "E",
      "streetType": "ST",
      "locality": "COLORADO SPRINGS",
      "city": "COLORADO SPRINGS",
      "stateOrProvince": "CO",
      "postCode": "80903",
      "postCodeSuffix": 2385,
      "sourceId": "string",
      "source": "LFACS",
      "geoAddressId": "string",
      "subAddress": {
        "sourceId": "CLSPCOMA1NT9V.1",
        "source": "Trillium",
        "geoSubAddressId": "1",
        "combinedDesignator": "BLDG SHOP",
        "elements": [
          {
            "designator": "APT",
            "value": 2
          }
        ]
      },
      "country": "USA",
      "geoPoint": [
        {
          "source": "Trillium",
          "latitude": 38.84703,
          "longitude": -104.814561,
          "coordinateLevel": 1,
          "accuracy": 1
        }
      ],
      "npaNxxList": [
        {
          "npa": {
            "code": "303"
          },
          "nxx": {
            "code": "291"
          }
        }
      ],
      "locationAttributes": {
        "isMdu": true,
        "legacyProvider": "QWEST COMMUNICATIONS",
        "rateCenter": "COLORDOSPG",
        "npa": 318,
        "nxx": 340,
        "wirecenter": "CLSPCOMA",
        "cala": "SCO",
        "tarCode": "NV0200",
        "tta": 471
      },
      "timeZone": {
        "name": "US Mountain Standard Time",
        "ianaName": "America/Denver",
        "isDaylightSavingsTime": false,
        "offset": -7
      }
    },
    "existingServiceAddress": {
      "addressId": 0,
      "streetAddress": "918 ROYER ST",
      "streetNrFirst": "918",
      "streetNrFirstSuffix": "string",
      "streetNrLast": "string",
      "streetNrLastSuffix": "string",
      "streetName": "ROYER",
      "streetNamePrefix": "E",
      "streetType": "ST",
      "locality": "COLORADO SPRINGS",
      "city": "COLORADO SPRINGS",
      "stateOrProvince": "CO",
      "postCode": "80903",
      "postCodeSuffix": 2385,
      "sourceId": "string",
      "source": "LFACS",
      "geoAddressId": "string",
      "subAddress": {
        "sourceId": "CLSPCOMA1NT9V.1",
        "source": "Trillium",
        "geoSubAddressId": "1",
        "combinedDesignator": "BLDG SHOP",
        "elements": [
          {
            "designator": "APT",
            "value": 2
          }
        ]
      },
      "country": "USA",
      "geoPoint": [
        {
          "source": "Trillium",
          "latitude": 38.84703,
          "longitude": -104.814561,
          "coordinateLevel": 1,
          "accuracy": 1
        }
      ],
      "npaNxxList": [
        {
          "npa": {
            "code": "303"
          },
          "nxx": {
            "code": "291"
          }
        }
      ],
      "locationAttributes": {
        "isMdu": true,
        "legacyProvider": "QWEST COMMUNICATIONS",
        "rateCenter": "COLORDOSPG",
        "npa": 318,
        "nxx": 340,
        "wirecenter": "CLSPCOMA",
        "cala": "SCO",
        "tarCode": "NV0200",
        "tta": 471
      },
      "timeZone": {
        "name": "US Mountain Standard Time",
        "ianaName": "America/Denver",
        "isDaylightSavingsTime": false,
        "offset": -7
      }
    },
    "availableServices": [
      {
        "offerCategory": "INTERNET",
        "serviceCategory": "DATA",
        "accessType": "ADSL2+",
        "networkInfrastructureIndicatorCode": "FTTN-ETH-A2P",
        "iptvPipeRateDownSpeed": "string",
        "iptvPipeRateUpSpeed": "string",
        "qualificationColorName": "string",
        "processInfo": [
          {
            "processInfoGroupName": "string",
            "processInfoAttribute": [
              {
                "name": "string",
                "value": "string"
              }
            ]
          }
        ]
      }
    ],
    "dhpAdditionalInfo": {
      "e911Address": {
        "streetDirectionPrefix": "string",
        "streetAddress": "ROYER ST",
        "location": "string",
        "streetNrFirst": 918,
        "city": "COLORADO SPRINGS",
        "stateOrProvince": "string",
        "postCode": 80903,
        "postCodeSuffix": 2935
      },
      "dhpDisclaimerAcceptDateTime": "2018-07-04T06:31:28.011Z"
    },
    "customerOrderItems": [
      {
        "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
        "productOfferingId": "string",
        "offerName": "string",
        "offerType": "BUNDLE",
        "offerSubType": "REGULAR",
        "offerCategory": "INTERNET",
        "quantity": 0,
        "action": "ADD",
        "contractStartDate": "2018-07-04T06:31:28.011Z",
        "contractTerm": 24,
        "rc": 0,
        "otc": 0,
        "discountedRc": 0,
        "discountedOtc": 0,
        "customerOrderSubItems": [
          {
            "productId": "string",
            "productName": "string",
            "productType": "INTERNET",
            "componentType": "PRIMARY",
            "productCategory": "CORE",
            "quantity": 1,
            "action": "ADD",
            "provisioningAction": "PROVISIONnBILL",
            "productAttributes": [
              {
                "compositeAttribute": [
                  {
                    "attributeName": "downSpeed",
                    "attributeValue": 40128,
                    "uom": "Kbps"
                  }
                ],
                "isDefault": 0,
                "displayOrder": 1,
                "isPriceable": true,
                "prices": [
                  {
                    "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                    "priceType": "SUBSCRIPTION",
                    "priceTypeDescription": "string",
                    "rc": 39.99,
                    "otc": 69.99,
                    "discountedRc": 29.99,
                    "discountedOtc": 49.99,
                    "frequency": "PERMONTH",
                    "currencyCode": "USD",
                    "provisioningAction": "PROVISIONnBILL"
                  }
                ],
                "discounts": [
                  {
                    "autoAttachInd": "Y",
                    "discountId": "VP510",
                    "discountDescription": "Discount Description VP510",
                    "discountRate": 50,
                    "discountMethod": "FLATAMOUNT",
                    "discountLevel": "P",
                    "discountDuration": 1,
                    "discountType": "P",
                    "discountCategory": "OTD",
                    "discountMaxAmount": 150,
                    "discountRule": "ANY",
                    "discountMinimumAmount": 50,
                    "discountIdSequence": 2
                  }
                ]
              }
            ],
            "productAssociations": [
              {
                "productAssociationType": "COMPATIBLE",
                "productIds": [
                  {
                    "productId": "string"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "existingServices": [
      {
        "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
        "productOfferingId": "string",
        "offerName": "string",
        "offerType": "BUNDLE",
        "offerSubType": "REGULAR",
        "offerCategory": "INTERNET",
        "quantity": 0,
        "action": "ADD",
        "contractStartDate": "2018-07-04T06:31:28.011Z",
        "contractTerm": 24,
        "rc": 0,
        "otc": 0,
        "discountedRc": 0,
        "discountedOtc": 0,
        "customerOrderSubItems": [
          {
            "productId": "string",
            "productName": "string",
            "productType": "INTERNET",
            "componentType": "PRIMARY",
            "productCategory": "CORE",
            "quantity": 1,
            "action": "ADD",
            "provisioningAction": "PROVISIONnBILL",
            "productAttributes": [
              {
                "compositeAttribute": [
                  {
                    "attributeName": "downSpeed",
                    "attributeValue": 40128,
                    "uom": "Kbps"
                  }
                ],
                "isDefault": 0,
                "displayOrder": 1,
                "isPriceable": true,
                "prices": [
                  {
                    "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                    "priceType": "SUBSCRIPTION",
                    "priceTypeDescription": "string",
                    "rc": 39.99,
                    "otc": 69.99,
                    "discountedRc": 29.99,
                    "discountedOtc": 49.99,
                    "frequency": "PERMONTH",
                    "currencyCode": "USD",
                    "provisioningAction": "PROVISIONnBILL"
                  }
                ],
                "discounts": [
                  {
                    "autoAttachInd": "Y",
                    "discountId": "VP510",
                    "discountDescription": "Discount Description VP510",
                    "discountRate": 50,
                    "discountMethod": "FLATAMOUNT",
                    "discountLevel": "P",
                    "discountDuration": 1,
                    "discountType": "P",
                    "discountCategory": "OTD",
                    "discountMaxAmount": 150,
                    "discountRule": "ANY",
                    "discountMinimumAmount": 50,
                    "discountIdSequence": 2
                  }
                ]
              }
            ],
            "productAssociations": [
              {
                "productAssociationType": "COMPATIBLE",
                "productIds": [
                  {
                    "productId": "string"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "reservedTN": [
      {
        "productType": "string",
        "requestedTelephoneNumber": 3603768686,
        "workingTN": "Yes",
        "tnType": "PORTED"
      }
    ],
    "existingTN": [
      {
        "productType": "string",
        "requestedTelephoneNumber": 3603768686,
        "workingTN": "Yes",
        "tnType": "PORTED"
      }
    ],
    "productConfiguration": [
      {
        "productType": "INTERNET",
        "configItems": [
          {
            "productId": "string",
            "productName": "string",
            "configDetails": [
              {
                "isConfigRequired": true,
                "formName": "string",
                "formItems": [
                  {
                    "attributeName": "string",
                    "attributeType": "string",
                    "isMandatory": true,
                    "attributeValue": [
                      {
                        "value": "string",
                        "isDefault": true
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "existingProductConfiguration": [
      {
        "productType": "INTERNET",
        "configItems": [
          {
            "productId": "string",
            "productName": "string",
            "configDetails": [
              {
                "isConfigRequired": true,
                "formName": "string",
                "formItems": [
                  {
                    "attributeName": "string",
                    "attributeType": "string",
                    "isMandatory": true,
                    "attributeValue": [
                      {
                        "value": "string",
                        "isDefault": true
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "additionalInfo": {
      "chargeSummaryAck": true,
      "disableOrderNotification": true,
      "tpvRecordLocator": "string"
    },
    "schedule": {
      "dates": {
        "effectiveBillDate": "2018-07-04T06:31:28.011Z",
        "requestedDueDate": "2018-07-04T06:31:28.011Z",
        "calculatedDueDate": "2018-07-04T06:31:28.011Z",
        "finalDueDate": "2018-07-04T06:31:28.011Z",
        "overrideFlag": false,
        "isCRDAvailable": true
      },
      "appointmentInfo": {
        "appointmentId": "ARNV1241439962SQ109",
        "timeSlot": {
          "startDatetime": "2018-07-04T06:31:28.012Z",
          "endDatetime": "2018-07-04T06:31:28.012Z"
        },
        "commitmentDateTime": "2018-07-04T06:31:28.012Z",
        "reservationId": 384519,
        "timeSlotType": "AppointmentBookingStandard",
        "timeSlotSource": "DGW"
      },
      "apptNotes": {
        "animalsPresent": false,
        "electricFence": true,
        "lockedGate": true,
        "notes": [
          {
            "name": "Driving Directions",
            "value": "Take Left",
            "date": "2018-07-04T06:31:28.012Z",
            "author": "string"
          }
        ]
      },
      "shippingInfo": {
        "shipDueDate": "2018-07-04T06:31:28.012Z",
        "shippingName": "string",
        "shippingAddlInfo": "string",
        "isShipAddrSameAsServiceAddress": true,
        "shippingAddress": {
          "isValidated": true,
          "streetAddress": "918 N ROYER ST",
          "streetNrFirst": 918,
          "streetNrFirstSuffix": "string",
          "streetNamePrefix": "ROYER",
          "streetName": "ROYER",
          "streetType": "ST",
          "locality": "COLORADO SPRINGS",
          "city": "COLORADO SPRINGS",
          "stateOrProvince": "CO",
          "postCode": 80903,
          "postCodeSuffix": "string",
          "source": "LFACS",
          "subAddress": {
            "sourceId": "CLSPCOMA1NT9V.1",
            "source": "Trillium",
            "geoSubAddressId": "1",
            "combinedDesignator": "BLDG SHOP",
            "elements": [
              {
                "designator": "APT",
                "value": 2
              }
            ]
          },
          "country": "USA",
          "locationAttributes": {
            "isMdu": true,
            "legacyProvider": "QWEST COMMUNICATIONS",
            "rateCenter": "COLORDOSPG",
            "npa": 318,
            "nxx": 340,
            "wirecenter": "CLSPCOMA",
            "cala": "SCO",
            "tarCode": "NV0200",
            "tta": 471
          }
        },
        "shippingMethod": "string"
      },
      "assessmentInfo": {
        "isAppointmentRequired": true,
        "appointmentType": "SI-RTD",
        "isShippingRequired": false,
        "isDHPEqpShipped": true,
        "isHSIModemShipped": false,
        "isHSIAccessoryShipped": true,
        "shippingCombination": "1"
      }
    },
    "accountInfo": {
      "isBillAddrSameAsServiceAddress": true,
      "billingAdditionalInfo": "string",
      "billingAddressType": "string",
      "billingAddress": {
        "isValidated": true,
        "streetAddress": "918 N ROYER ST",
        "streetNrFirst": 918,
        "streetNrFirstSuffix": "string",
        "streetNamePrefix": "ROYER",
        "streetName": "ROYER",
        "streetType": "ST",
        "locality": "COLORADO SPRINGS",
        "city": "COLORADO SPRINGS",
        "stateOrProvince": "CO",
        "postCode": 80903,
        "postCodeSuffix": "string",
        "source": "LFACS",
        "subAddress": {
          "sourceId": "CLSPCOMA1NT9V.1",
          "source": "Trillium",
          "geoSubAddressId": "1",
          "combinedDesignator": "BLDG SHOP",
          "elements": [
            {
              "designator": "APT",
              "value": 2
            }
          ]
        },
        "country": "USA",
        "locationAttributes": {
          "isMdu": true,
          "legacyProvider": "QWEST COMMUNICATIONS",
          "rateCenter": "COLORDOSPG",
          "npa": 318,
          "nxx": 340,
          "wirecenter": "CLSPCOMA",
          "cala": "SCO",
          "tarCode": "NV0200",
          "tta": 471
        }
      },
      "accountName": {
        "firstName": "string",
        "lastName": "string",
        "middleName": "string",
        "businessName": "string",
        "title": "string",
        "generation": "string"
      },
      "ban": 852185131,
      "accountPin": 1234,
      "billCycle": 4,
      "accountType": "I",
      "accountSubType": "string",
      "creditClass": "Z",
      "geoCode": "string",
      "contact": {
        "contactNumber": "string",
        "smsNumber": "string",
        "emailAddress": "string",
        "emailAddrDeclined": true
      },
      "personalDetails": {
        "dLExpirationDate": "string",
        "dLlicenseNo": "string",
        "dLlicenseState": "string",
        "dateOfBirth": "string",
        "ssn": "string",
        "taxId": "string",
        "creditCheck": true,
        "underAgeAck": true
      },
      "accountPreferences": {
        "paperlessBilling": true,
        "spanishBillPrint": true,
        "largePrint": true,
        "braille": true,
        "noTeleMarketing": true,
        "noEmail": true,
        "noDirectMail": true,
        "emailNotification": {
          "billingNotification": true,
          "orderingNotification": true,
          "repairNotification": true
        },
        "textNotification": {
          "billingNotification": true,
          "orderingNotification": true,
          "repairNotification": true
        }
      }
    },
    "isFinalBillAddressChanged": true,
    "creditReview": {
      "creditApplicationRefNumber": "01000009303498",
      "creditInfo": {
        "creditClass": "2",
        "finalBillInd": true,
        "finalBillInfo": [
          {
            "btn": "208-529-4610",
            "cusCode": 723,
            "finalBillName": "JANE JAMES",
            "ssn": "528-98-4589",
            "finalBillAddress": {
              "streetAddress": "7672 S REDWOOD RD",
              "additionalLocation": "string",
              "city": "WEST JORDAN",
              "stateOrProvince": "UT",
              "postalCode": 84084
            },
            "finalBillDate": "2018-07-04T06:31:28.012Z",
            "entityFinalBillFlag": false,
            "finalBillEntityList": [
              {
                "finalBillEntity": {
                  "entityCode": "MBH",
                  "dueAmt": 14.82
                }
              }
            ],
            "finalBillAmt": {
              "amount": 115.18
            },
            "paymentRequiredInd": true
          }
        ]
      },
      "depositInfo": {
        "success": true,
        "depositRequired": true,
        "products": [
          {
            "productType": "INTERNET",
            "serviceGroup": "HSI",
            "subServiceGroup": "SRV",
            "depositAmount": {
              "amount": 120,
              "units": "USD"
            },
            "installmentInd": true,
            "installmentOptions": [
              {
                "noOfInstallments": 2,
                "paymentAmount": 60
              }
            ]
          }
        ]
      },
      "paymentInfo": [
        {
          "billingAccountId": 3607562159621,
          "paidAmount": 0,
          "paymentTypeCode": "D",
          "paymentStatusCd": "S",
          "depositPayDate": "2018-07-04T06:31:28.012Z",
          "paymentId": "SRV"
        }
      ],
      "billEstimate": {
        "quote": [
          {
            "quoteId": "1"
          }
        ]
      }
    },
    "featureDescription": {
      "subMarketCode": "A2761",
      "ppfcs": [
        {
          "bmProductName": "CENTURYLINK @ EASE",
          "productSubType": "string",
          "productType": "QW",
          "pricePlan": "INTQ9104",
          "ppEffectiveDate": "2018-07-04T06:31:28.012Z",
          "featureCode": "J9104S",
          "isPrimary": false,
          "featureDescription": "CenturyLink atEase - Ultra",
          "recurTermFee": "0.0",
          "termFee": "string",
          "action": "string",
          "term": 0,
          "bundleCode": "string"
        }
      ]
    },
    "returnEquipments": [
      {
        "offerCategory": "string",
        "productType": "string",
        "productId": 0,
        "productName": "string",
        "isLeasedEquipment": true,
        "purchasePrice": {
          "attributesCombination": {
            "name": "string",
            "value": "string",
            "uom": "string",
            "isDefault": true,
            "displayOrder": 0
          },
          "priceType": "string",
          "rc": 0,
          "otc": 0,
          "discountedRc": 0,
          "discountedOtc": 0,
          "currencyCode": "string"
        }
      }
    ],
    "returnDateOfEquipment": "string",
    "charges": [
      {
        "chargeType": "RS",
        "chargeName": "string",
        "billAmount": 0,
        "discount": 0,
        "taxes": 0
      }
    ],
    "addlOrderAttributes": {
      "orderAttributeGroup": [
        {
          "orderAttributeGroupName": "otcInstallmentInfo",
          "orderAttributeGroupInfo": [
            {
              "orderAttributes": [
                {
                  "orderAttributeName": "productName",
                  "orderAttributeValue": "MODEM"
                }
              ]
            }
          ]
        }
      ]
    }
  }
}
```
Error Response
===============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

| API            | /submitOrder                               |
|:---------------|:-------------------------------------------|
| Error Code     | 400                                        |
| Error Message  | Invalid status value; returns Error object |

| Name           | Value                                      |
|:---------------|:-------------------------------------------|
| HTTP Method    | post                                       |
| Base URI       | /bsi                                       |
| URI Syntax     |                                            |
| Operation Name | /customerOrder/submitOrder                 |

Operation Details (Request/Response)
------------------------------------

**Required Attributes**

Attributes present in request are mandatory.

    API: /getCart

Request
--------
orderReferenceNumber 

Response 
--------
```sh
{
  "orderReferenceNumber": "string",
  "customerOrderItems": [
    {
      "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
      "productOfferingId": "string",
      "offerName": "string",
      "offerType": "BUNDLE",
      "offerSubType": "REGULAR",
      "offerCategory": "INTERNET",
      "quantity": 0,
      "action": "ADD",
      "contractStartDate": "2018-07-04T09:59:37.017Z",
      "contractTerm": 24,
      "rc": 0,
      "otc": 0,
      "discountedRc": 0,
      "discountedOtc": 0,
      "customerOrderSubItems": [
        {
          "productId": "string",
          "productName": "string",
          "productType": "INTERNET",
          "componentType": "PRIMARY",
          "productCategory": "CORE",
          "quantity": 1,
          "action": "ADD",
          "provisioningAction": "PROVISIONnBILL",
          "productAttributes": [
            {
              "compositeAttribute": [
                {
                  "attributeName": "downSpeed",
                  "attributeValue": 40128,
                  "uom": "Kbps"
                }
              ],
              "isDefault": 0,
              "displayOrder": 1,
              "isPriceable": true,
              "prices": [
                {
                  "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                  "priceType": "SUBSCRIPTION",
                  "priceTypeDescription": "string",
                  "rc": 39.99,
                  "otc": 69.99,
                  "discountedRc": 29.99,
                  "discountedOtc": 49.99,
                  "frequency": "PERMONTH",
                  "currencyCode": "USD",
                  "provisioningAction": "PROVISIONnBILL"
                }
              ],
              "discounts": [
                {
                  "autoAttachInd": "Y",
                  "discountId": "VP510",
                  "discountDescription": "Discount Description VP510",
                  "discountRate": 50,
                  "discountMethod": "FLATAMOUNT",
                  "discountLevel": "P",
                  "discountDuration": 1,
                  "discountType": "P",
                  "discountCategory": "OTD",
                  "discountMaxAmount": 150,
                  "discountRule": "ANY",
                  "discountMinimumAmount": 50,
                  "discountIdSequence": 2
                }
              ]
            }
          ],
          "productAssociations": [
            {
              "productAssociationType": "COMPATIBLE",
              "productIds": [
                {
                  "productId": "string"
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```
Error Response 
================
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

| HTTP Status Code (BM) | BM Reason Code                           | Message Text   |
|:----------------------|:-----------------------------------------|:---------------|
| 400                   | ORDER_REFERENCE_NUMBER_NOT_FOUND         | Order reference number cannot be null.                                                     |
| 404                   | SERVICE_AVAIL_BAD_REQUEST                | Invalid request- invalid order reference number for service availability.                  |
| 404                   | RESOUCE_NOT_FOUND                        | Invalid order reference number.                                                            |
| 405                   | METHOD_NOT_ALLOWED                       | The server does not implement the requested HTTP method.                                   |
| 500                   | ORDER_BUSINESS_SERVER_ERROR              | \<API Method Name\> Order Business Service is unable to process this request at this time. |
| 500                   | SERVICE_AVAILABILITY_SERVICE_UNAVAILABLE | The server cannot handle the request for a service due to temporary maintenance.           |
| 500                   | ORDER_BUSINESS_DB_ERROR                  | The server is unable to process the request due to database error.                         |


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>
   
