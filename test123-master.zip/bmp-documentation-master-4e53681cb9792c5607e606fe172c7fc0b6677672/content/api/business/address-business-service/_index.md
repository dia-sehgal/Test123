---
title: "Address"
date: 2018-05-24T09:51:24-07:00
draft: false
---


AddressBusinessService is a generic process to move your current products to a different address and also you can add, change or remove new items on completed order from ESHOP UI.

## Sections
* [Resources/Operations](#resources-operations)
* [Swagger Specification](#swagger-specification)
* [Authentication Details](#authentication-details)
* [MAL/Cloud Org](#mal-cloud-org)
* [Dependencies](#dependencies)
  - [MongoDB](#mongodb)
  - [PCF Services](#pcf-services)
  - [Processes Using](#processes-using)
  - [Downstream Services](#downstream-services)
* [Developer Installation](#developer-installation)
* [Setup](#setup)
* [CI/CD Pipeline Details](#ci-cd-pipeline-details)
* [Cloud Environment Details](#cloud-environment-details)
* [Splunk Dashboard](#splunk-dashboard)




## Resources/Operations 

  i) **v1/address** - This API validates given address from goes server.
  	   
 ii) **v1/address/getAddressForm** - This API gives empty address form to bill
     
 iii) **/v1/address/submitByGeoAddressId** - This API validates address according to geoAddress id

 iv) **v1/address/submitE911Address** - This API validates E911 address from intrado system


## Swagger Specification
{{< oai-spec url="https://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-business-service/files/api-docs.json" >}}



# Installation :
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
    - Visit [Oracle] website to get the Oracle JDBC driver â€“ ojdbc6.jar or ojdbc7.jar
    - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} 
      -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar

# SetUp : 
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/address-business-service.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run
```

# Dependent systems :
   geoES_validateServiceAddress.url: https://cxg7i.test.intranet/dev/api/v1/serviceAddresses/validations?
   geoES_getServiceAddress.url: https://cxg7i.test.intranet/dev/api/v1/serviceAddresses?
   geoES_postalAddressValidation.url: https://cxg7i.test.intranet/dev/api/v1/postalAddresses/validations?
   geoES_telcoAttributes.url: https://cxg7i.test.intranet/dev/api/v1/addresses/telcoAttributes?
   
# CI/CD Pipeline Details :
* Name:	 bmp-address-business-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000

* Sonarqube Project URL:	 TBD

* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 https://ne1itcprhas62.ne1.savvis.net/BMP_DEV/address-business-service/blob/release/final/Jenkinsfile
# Cloud Environment Details
* Cloud Group Name:	 BMPO-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-address-business-service-test3.pcfmrnctl.dev.intranet

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/

# Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards

# Swagger URL :
```sh
http://bmp-address-business-service-test3.pcfmrnctl.dev.intranet/
```
# Sample Request for Post(submit Address for validation):
```sh
{
  "addressLine": "2366 PRIMO RD,HIGHLANDS RANCH,CO,80129",
  "city": "string",
  "country": "USA",
  "locality": "string",
  "postCode": "string",
  "postCodeSuffix": "string",
  "postalAddressFlag": false,
  "stateOrProvince": "string",
  "streetAddress": "string",
  "streetName": "string",
  "streetNrFirst": "string",
  "streetNrFirstSuffix": "string",
  "streetNrLast": "string",
  "streetNrLastSuffix": "string",
  "streetType": "string",
  "unitNumber": ""
}
```

# Sample Response :
```sh
{
  "success": true,
  "result": "GREEN - exact match",
  "addressId": "",
  "streetAddress": "2366 PRIMO RD",
  "streetNrFirst": "2366",
  "streetNrFirstSuffix": "",
  "streetNrLast": "",
  "streetNrLastSuffix": "",
  "streetName": "PRIMO RD",
  "streetNamePrefix": null,
  "streetType": "",
  "locality": "HIGHLANDS RANCH",
  "city": "HIGHLANDS RANCH",
  "stateOrProvince": "CO",
  "postCode": "80129",
  "postCodeSuffix": "",
  "sourceId": "LTTNCOHL15RUK.8",
  "source": "LFACS",
  "geoAddressId": "238668185",
  "country": "USA",
  "geoPoint": [
    {
      "source": "Trillium",
      "latitude": 39.564487,
      "longitude": -105.017309,
      "coordinateLevel": "1",
      "accuracy": "1"
    }
  ],
  "subAddress": {
    "sourceId": "",
    "source": "",
    "geoSubAddressId": "",
    "combinedDesignator": "",
    "elements": []
  },
  "locationAttributes": {
    "isMdu": true,
    "legacyProvider": "QWEST COMMUNICATIONS",
    "rateCenter": "DENVER",
    "wirecenter": "LTTNCOHL",
    "npa": "303",
    "nxx": "791",
    "cala": "DNV",
    "tta": "791",
    "tarCode": "CO1890"
  },
  "timeZone": {
    "name": "Mountain Standard Time",
    "ianaName": "America/Denver",
    "isDaylightSavingsTime": true,
    "offset": "-6"
  },
  "npaNxxList": [
    {
      "npa": {
        "code": "720"
      },
      "nxx": {
        "code": "516"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "683"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "346"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "471"
      }
    },
    {
      "npa": {
        "code": "720"
      },
      "nxx": {
        "code": "344"
      }
    },
    {
      "npa": {
        "code": "720"
      },
      "nxx": {
        "code": "348"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "470"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "791"
      }
    }
  ]
}
```

# Sample Request for Get Address:
```sh
Get empty address form to fill.
```

# Sample Response :
```sh
{
  "postalAddressFlag": false,
  "addressLine": "",
  "unitNumber": "",
  "streetAddress": "",
  "streetNrFirst": "",
  "streetNrLastSuffix": "",
  "streetNrFirstSuffix": "",
  "streetNrLast": "",
  "streetName": "",
  "streetType": "",
  "locality": "",
  "city": "",
  "stateOrProvince": "",
  "postCode": "",
  "postCodeSuffix": "",
  "country": ""
}
```

# Sample Request for Post Address (submit By GeoAddressId):
```sh
{
  "geoAddressId": "238668185",
  "geoSubAddressId": "",
  "sourceSystem": "LFACS"
}
```

# Sample Response :
```sh
{
  "success": true,
  "result": "Found",
  "addressId": "",
  "streetAddress": "2366 PRIMO RD",
  "streetNrFirst": "2366",
  "streetNrFirstSuffix": "",
  "streetNrLast": "",
  "streetNrLastSuffix": "",
  "streetName": "PRIMO RD",
  "streetNamePrefix": null,
  "streetType": "",
  "locality": "HIGHLANDS RANCH",
  "city": "HIGHLANDS RANCH",
  "stateOrProvince": "CO",
  "postCode": "80129",
  "postCodeSuffix": "",
  "sourceId": "LTTNCOHL15RUK.8",
  "source": "LFACS",
  "geoAddressId": "238668185",
  "country": "USA",
  "geoPoint": [
    {
      "source": "Trillium",
      "latitude": 39.564487,
      "longitude": -105.017309,
      "coordinateLevel": "1",
      "accuracy": "1"
    }
  ],
  "subAddress": {
    "sourceId": "",
    "source": "",
    "geoSubAddressId": "0",
    "combinedDesignator": "",
    "elements": []
  },
  "locationAttributes": {
    "isMdu": true,
    "legacyProvider": "QWEST COMMUNICATIONS",
    "rateCenter": "DENVER",
    "wirecenter": "LTTNCOHL",
    "npa": "303",
    "nxx": "791",
    "cala": "DNV",
    "tta": "791",
    "tarCode": "CO1890"
  },
  "timeZone": {
    "name": "Mountain Standard Time",
    "ianaName": "America/Denver",
    "isDaylightSavingsTime": true,
    "offset": "-6"
  },
  "npaNxxList": [
    {
      "npa": {
        "code": "720"
      },
      "nxx": {
        "code": "516"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "683"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "346"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "471"
      }
    },
    {
      "npa": {
        "code": "720"
      },
      "nxx": {
        "code": "344"
      }
    },
    {
      "npa": {
        "code": "720"
      },
      "nxx": {
        "code": "348"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "470"
      }
    },
    {
      "npa": {
        "code": "303"
      },
      "nxx": {
        "code": "791"
      }
    }
  ]
}
```


# Sample Request for Post Address (submitE911Address):
```sh
{
  "city": "HIGHLANDS RANCH",
  "continuationParams": {
    "lastRow": 0
  },
  "streetDirectionPrefix": "",
  "streetAddress": "2366 PRIMO RD",
  "location": "HIGHLANDS RANCH",
  "streetNrFirst": "2366",
  "stateOrProvince": "CO",
  "postCode": "80129",
  "postCodeSuffix": "",
  "recordLimit": 0
}
```