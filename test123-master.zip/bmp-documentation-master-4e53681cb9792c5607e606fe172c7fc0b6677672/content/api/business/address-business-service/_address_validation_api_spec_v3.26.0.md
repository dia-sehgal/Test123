Address Validation Business Service 
====================================
    Version: 3.26.0
[Request /address](#Request)

[Response /address](#Response)

Overview
--------

Address Validation business service is used to validate the service address and
postal address as per geography.It interacts with GEOES southbound system to get the address validation done. It responds back with YELLOW, RED and GREEN colour.
RED indicates no address match found.
Yellow indicates multiple nearby matches found,GREEN response indicates exact address found in that locality.
Once Green response received from southbound system, user can continue with further order progression.

![](media/AddressValidatioDiagram.png)

**Request Syntax**

For each resource, the following items are documented.

| Name           | Value                          |
|:---------------|:-------------------------------|
| HTTP Method    | post                           |
| Base URI       | /bsi/AddressBusinessService/v1 |
| URI Syntax     |                                |
| Operation Name | /address                       |

Operation Details (Request/Response)
------------------------------------

**Required Attributes**

| Attribute Name      | Data Type                      |
|:--------------------|:-------------------------------|
| HTTP Method         | post                           |
| Base URI            | /bsi/AddressBusinessService/v1 |
| URI Syntax          |                                |
| Operation Name      | /address                       |

**Required Attributes**

The following attributes present in the API request/responses for **/address** service are mandatory.

Request
=============
    {
     "postalAddressFlag": true,
     "addressLine": "918 N ROYER ST, COLORADO SPRINGS, CO 80903",
     "unitNumber": "APT 1",
     "streetAddress": null,
     "streetNrFirst": null,
     "streetNrFirstSuffix": null,
     "streetNrLast": null,
     "streetNrLastSuffix": null,
     "streetName": null,
     "streetType": null,
     "locality": null,
     "city": null,
     "stateOrProvince": null,
     "postCode": null,
     "postCodeSuffix": 2385,
     "country": null
    }
    
Response
==============
    {
     "success": true,
     "result": "Green - exact match",
     "addressId": "CLSPCOMA16ACF",
     "streetAddress": "918 N ROYER ST",
     "streetNrFirst": "918",
     "streetNrFirstSuffix": null,
     "streetNrLast": null,
     "streetNrLastSuffix": null,
     "streetName": "N ROYER",
     "streetNamePrefix": "E",
     "streetType": "ST",
     "locality": "COLORADO SPRINGS",
     "city": "COLORADO SPRINGS",
     "stateOrProvince": "CO",
     "postCode": "80903",
     "postCodeSuffix": "2385",
     "sourceId": "CLSPCOMA16ACF",
     "source": "LFACS",
     "geoAddressId": "213702098",
     "subAddress": {
      "sourceId": "CLSPCOMA1NT9V.1",
      "source": "LFACS",
      "geoSubAddressId": 1,
      "combinedDesignator": "BLDG 1",
      "elements": [
       {
        "designator": "APT",
        "value": 2
      }
     ]
    },
    "country": "USA",
    "geoPoint": [
     {
      "source": "Trillium",
      "latitude": 38.84703,
      "longitude": -104.814561,
      "coordinateLevel": 1,
      "accuracy": 1
     }
    ],
     "locationAttributes": {
     "isMdu": true,
     "legacyProvider": "QWEST COMMUNICATIONS",
     "rateCenter": "COLORDOSPG",
     "npa": 318,
     "nxx": 340,
     "wirecenter": "CLSPCOMA",
     "cala": "SCO",
     "tarCode": "NV0200",
     "tta": 471
    },
    "npaNxxList": [
     {
      "npa": {
       "code": 303
      },
      "nxx": {
       "code": 291
      }
     }
    ],
    "timeZone": {
     "name": "US Mountain Standard Time",
     "ianaName": "America/Denver",
     "isDaylightSavingsTime": false,
     "offset": -7
     }
    }
    
Error Response
===================
    {
    "errorResponse": [
     {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
      }
     ]
    }

| Name           | Value                          |
|:---------------|:-------------------------------|
| HTTP Method    | post                           |
| Base URI       | /bsi/AddressBusinessService/v1 |
| URI Syntax     |                                |
| Operation Name | /address/submitByGeoAddressId  |

**Required Parameters**

| Parameter       | Description                                    |
|:----------------|:-----------------------------------------------|
| geoAddressId    | unique ID generated for Addresses              |
| geoSubAddressId | unique ID generated for Addresses              |
| sourceSystem    | source system that validation result came from |

Operation Details (Request/Response)
---------------------

The following attributes present in the API request/responses for **/address** service are mandatory.

Request
=============
    {
     "geoAddressId": 213702098,
     "geoSubAddressId": "1",
     "sourceSystem": "LFACS"
    }
    
Response
==============
    {
     "success": true,
     "result": "Green - exact match",
     "addressId": "CLSPCOMA16ACF",
     "streetAddress": "918 N ROYER ST",
     "streetNrFirst": "918",
     "streetNrFirstSuffix": null,
     "streetNrLast": null,
     "streetNrLastSuffix": null,
     "streetName": "N ROYER",
     "streetNamePrefix": "E",
     "streetType": "ST",
     "locality": "COLORADO SPRINGS",
     "city": "COLORADO SPRINGS",
     "stateOrProvince": "CO",
     "postCode": "80903",
     "postCodeSuffix": "2385",
     "sourceId": "CLSPCOMA16ACF",
     "source": "LFACS",
     "geoAddressId": "213702098",
     "subAddress": {
     "sourceId": "CLSPCOMA1NT9V.1",
     "source": "LFACS",
     "geoSubAddressId": 1,
     "combinedDesignator": "BLDG 1",
     "elements": [
       {
        "designator": "APT",
        "value": 2
      }
     ]
    },
    "country": "USA",
    "geoPoint": [
    {
     "source": "Trillium",
     "latitude": 38.84703,
     "longitude": -104.814561,
     "coordinateLevel": 1,
     "accuracy": 1
     }
    ],
    "locationAttributes": {
    "isMdu": true,
    "legacyProvider": "QWEST COMMUNICATIONS",
    "rateCenter": "COLORDOSPG",
    "npa": 318,
    "nxx": 340,
    "wirecenter": "CLSPCOMA",
    "cala": "SCO",
    "tarCode": "NV0200",
    "tta": 471
    },
    "npaNxxList": [
      {
      "npa": {
      "code": 303
     },
      "nxx": {
      "code": 291
      }
     }
    ],
    "timeZone": {
    "name": "US Mountain Standard Time",
    "ianaName": "America/Denver",
    "isDaylightSavingsTime": false,
    "offset": -7
    }
    }
    
Error Response
======================
    {
    "errorResponse": [
     {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
      }
     ]
    }

| HTTP Status Code (BM)       | BM Reason Code           | Message Text      |
|:----------------------------|:-------------------------|:------------------|
| 400 [Bad Request]           | INVALID_ADDRESS_LINE     | AddressLine must exist.                                                                         |
| 400                         | BAD_REQUEST              | addressLine1 must exist.                                                                        |
| 400                         | BAD_REQUEST              | addressLine1: Invalid Format or Length.                                                         |
| 400                         | BAD_REQUEST              | addressLine2: Invalid Format or Length.                                                         |
| 400                         | INVALID_LOCALITY         | Locality value cannot be empty or null.                                                         |
| 400                         | INVALID_STATE_PROVINCE   | State or province cannot be null or empty.                                                      |
| 400                         | BAD_REQUEST              | locality: Invalid Format or Length                                                              |
| 400                         | BAD_REQUEST              | stateOrProvince: Invalid Format or Length.                                                      |
| 400                         | BAD_REQUEST              | postCode: Invalid Format or Length.                                                             |
| 400                         | BAD_REQUEST              | Country must be USA.                                                                            |
| 400                         | INVALID_SOURCE_SYSTEM    | Source system value cannot be empty or null.                                                    |
| 400                         | BAD_REQUEST              | Unable to parse sources. Please check formatting of sources parameter.                          |
| 400                         | BAD_REQUEST              | Unable to parse expand. Please check formatting of expand parameter.                            |
| 400                         | BAD_REQUEST              | Expand Lists cannot contain duplicate expand parameters.                                        |
| 400                         | INVALID_STREET_ADDRESS   | Street address value cannot be empty or null.                                                   |
| 400                         | INVALID_STREET_NR_FIRST  | Street number value cannot be empty or null.                                                    |
| 400                         | INVALID_GEO_ADDRESS_ID   | geoAddressId value cannot be empty or null.                                                     |
| 401 [Unauthorized]          | AUTHENTICATION_FAILURE   | Authentication failed due to invalid authentication credential.                                 |
| 401                         | RESOUCE_NOT_FOUND        | No Resource/Data found for this request                                                         |
| 401                         | METHOD_NOT_ALLOWED       | The requested method is not allowed on the API.                                                 |
| 500 [Internal Server Error] | GEOES_SERVER_ERROR       | Variable - This will be the message of the exception (**Send this error as is**)                |
| 502                         | GEOES_SERVER_ERROR       | Variable - This will be the actual Oracle error (**Send this error as is**)                     |
| 502                         | GEOES_SERVER_ERROR       | Variable - This will be the message of the exception (**Send this error as is**)                |
| 502                         | GEOES_SERVER_ERROR       | Variable - This will be the message of the exception (**Send this error as is**)                |
| 502                         | GEOES_SERVER_ERROR       | Variable - This will be the message of the exception (**Send this error as is**)                |
| 502                         | GEOES_SERVER_ERROR       | Variable - This will be the message of the exception (**Send this error as is**)                |
| 502                         | GEOES_SERVER_ERROR       | Variable - This will be the message of the exception (**Send this error as is**)                |
| 502                         | GEOES_SERVER_ERROR       | GeoES is unable to process this request.                                                        |
| 500                         | BM_ADDRESS_SERVER_ERROR  | Address Business Service - < API/Method Name> is unable to process this request at this time. |
| 503                         | GEOES_SERVER_ERROR       | GeoES is unable to process this request.                                                        |
| 503                         | GEOES_SERVER_UNAVAILABLE | The server cannot handle the request for a service due to temporary maintenance.                |
| 503                         | GEOES_SERVER_TIMEOUT     | The server cannot handle the request and is timing out.                                         |

**Telco Attributes**

| HTTP Status Code (BM)       | BM Reason Code         | Message Text       |
|:----------------------------|:-----------------------|:-------------------|
| 200 [OK]                    |                        |                    |
| 400 [Bad Request]           | INVALID_LATITUDE       | Latitude must exist. |
|                             | INVALID_LONGITUDE      | Longitude is invalid. |
|                             | INVALID_EXPAND_PARAM   | Unable to parse expand. |
| 401 [Unauthorized]          | AUTHENTICATION_FAILURE | Authentication failed due to invalid authentication credential. |
| 500 [Internal Server Error] | GEOES_SERVER_ERROR     | Variable - This will be the actual Oracle error                 |
|                             | GEOES_SERVER_ERROR     | Variable - This will be the message of the exception            |
