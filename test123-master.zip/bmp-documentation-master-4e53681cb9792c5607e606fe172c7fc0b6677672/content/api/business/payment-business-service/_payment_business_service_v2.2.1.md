Payment Business Service 
=========================
    Version: 2.2.1

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [API getUrl](#getUrl)
- [API getPaymentStatus](#getPaymentStatus)
- [API getAutoPayPurl](#getAutoPayPurl)


Overview
--------

> **Payment business service is used to integrate with EPWF for following POST operations:**
>
>1.  getUrl
>
>2.  getPaymentStatus
>
>3.  getAutoPayPurl

![](media/BMPaymentDiagram.png)

_The subsequent sections will cover details of each operation defined under Payment Business Service._

getUrl
-------

>This operation retrieves payment URL from EPWF.

### Request Syntax

For each resource, the following items are documented.

| Name           | Value                          |
|:---------------|:-------------------------------|
| HTTP Method    | post                           |
| Base URI       | /bsi/PaymentBusinessService/v1 |
| URI Syntax     |                                |
| Operation Name | /payment/getUrl                |

### Required Attributes

| Name            | Value  |
|:----------------|:-------|
| paymentRequest  | Object |
| requestId       | String |
| srcSystemTranId | Number |
| partyRoleId     | String |
| customerEmailId | String |
| hostName        | String |
| multiPayment    | Object |

*Note: Attributes present in request are mandatory.*

Operation Details (Request/Response)
------------------------------------

    API: /getUrl

	
Request 
-------
```sh
{
  "requestId": "ORN-20171120105735020",
  "srcSystemTranId": "01000009303475",
  "partyRoleId": "AB83228",
  "customerEmailId": "abc@xyz.com",
  "hostName": "https://eshop-e2e.test.intranet/eshop/customerCare/dist/",
  "multiPayment": [
    {
      "paymentTypeCode": "FB",
      "customerType": "INDIVIDUAL",
      "paymentAmt": {
        "currency": "USD",
        "amount": 0
      },
      "convenienceFeeAmt": {
        "currency": "USD",
        "amount": 0
      },
      "totalTaxAmt": {
        "currency": "USD",
        "amount": 0
      },
      "entityAllocation": {
        "entityCodeId": "000R",
        "entityAmt": {
          "currency": "USD",
          "amount": 0
        }
      },
      "billingAccountId": 3607562159621,
      "businessName": "ACME Roadrunner",
      "customerFirstName": "Keri",
      "customerLastName": "Willis",
      "address": {
        "streetAddress1": "1914 MCKENZIE AVE",
        "streetAddress2": "UNIT 4",
        "city": "BELLINGHAM",
        "stateProvince": "WA",
        "postalCode": 98225,
        "addressType": "BLG"
      }
    }
  ]
}
```

Response 
========
```sh
{
  "ePWFHeaderInfo": {
    "requestId": "ORN-20171120105735020",
    "sendTimeStamp": "2018-07-12T07:26:59.107Z",
    "messageSrcSystem": "ESHOP"
  },
  "transactionStatus": "S",
  "paymentVerificationTranId": "WGVHEYZJQKX2M",
  "sessionDetail": {
    "sessionURL": "https://hcde6-int1.centurylink.com/HCDE/Internal/UI/payment/voicetoken/getSession?sessionId=WGVHEYZJQKX2M",
    "sessionId": "WGVHEYZJQKX2M"
  }
}
```

Error Response 
==============
```sh
{
  "success": false,
  "message": "Payment Information receipt failed"
}
```

| API           | /getUrl               |
|:--------------|:----------------------|
| Error Code    | 400                   |
| Error Message | Bad Request           |
| Error Code    | 404                   |
| Error Message | Not Found             |
| Error Code    | 500                   |
| Error Message | Internal Server Error |

getPaymentStatus
----------------

>This operation gets Payment status from EPWF.

### Request Syntax

For each resource, the following items are documented.

| Name           | Value                          |
|:---------------|:-------------------------------|
| HTTP Method    | post                           |
| Base URI       | /bsi/PaymentBusinessService/v1 |
| URI Syntax     |                                |
| Operation Name | /payment/getPaymentStatus      |

### Required Attributes

| Name                  | Value  |
|:----------------------|:-------|
| statusRequest         | Object |
| paymentConfirmationNo | String |
| requestId             | String |
| orderNumber           | String |
| srcSystemTranId       | Number |
| finalBillInfo         | Object |
| depositInfo           | Object |

*Note: Attributes present in request are mandatory.*

Operation Details (Request/Response)
------------------------------------

    API: /payment/getPaymentStatus

Request 
========
```sh
{
  "paymentConfirmationNo": "string",
  "requestId": "ORN-5668372350300",
  "orderNumber": 5668372350300,
  "srcSystemTranId": "01000009303475",
  "finalBillInfo": [
    {
      "billingAccountId": 3607562159621,
      "paymentTypeCode": "FB",
      "paymentStatusCd": "S",
      "paymentDate": {},
      "finalBillEntityList": [
        {
          "entityCode": 12,
          "dueAmt": 451.11,
          "entityType": "string"
        }
      ],
      "finalBillAmt": 0,
      "paymentRequiredInd": "string",
      "paymentId": "string"
    }
  ],
  "depositInfo": [
    {
      "billingAccountId": 459848721,
      "paidAmount": 75,
      "paymentTypeCode": "D",
      "paymentStatusCd": "S",
      "depositPayDate": {},
      "paymentId": 673173
    }
  ]
}
```

Response 
========
```sh
{
  "success": true,
  "message": "Payment Information received successfully"
}
```

| API            | /payment/getPaymentStatus                                 |
|:---------------|:----------------------------------------------------------|
| Error response | { "success": false, "message": "Payment Information receipt failed" } |
| Error Code     | 400                                                                   |
| Error Message  | Bad Request                                                           |
| Error Code     | 500                                                                   |
| Error Message  | Internal Server Error                                                 |

getAutoPayPurl
--------------

>This operation retrieves Auto Pay PURL from EPWF.

### Request Syntax

For each resource, the following items are documented.

| Name           | Value                          |
|:---------------|:-------------------------------|
| HTTP Method    | post                           |
| Base URI       | /bsi/PaymentBusinessService/v1 |
| URI Syntax     |                                |
| Operation Name | /payment/getAutoPayPurl        |

### Required Attributes

| Name           | Value  |
|:---------------|:-------|
| autoPayRequest | Object |
| requestId      | String |
| hostName       | String |
| ban            | String |
| requestType    | String |
| tokenType      | String |
| partyRoleId    | String |
| emailAddress   | String |
| firstName      | String |
| lastName       | String |
| billingAddress | Object |

*Note: Attributes present in request are mandatory.*

Operation Details (Request/Response)
------------------------------------

    API: /payment/getAutoPayPurl

Request 
=======
```sh
{
  "requestId": "ORN-20171120105735020",
  "hostName": "https://eshop-e2e.test.intranet/eshop/customerCare/dist/",
  "ban": "300006229",
  "requestType": "CreateToken",
  "tokenType": "ManagePaymentOptions",
  "partyRoleId": "string",
  "emailAddress": "string",
  "firstName": "John",
  "lastName": "Doe",
  "billingAddress": {
    "streetAddress": "1914 MCKENZIE AVE",
    "combinedDesignator": "APT 4",
    "city": "BELLINGHAM",
    "stateOrProvince": "WA",
    "postCode": "98225",
    "billingAddressType": "string"
  }
}
```
Response 
=========
```sh
{
  "ban": "300006229",
  "autoPayPURL": "https://myajws-test1.centurylink.com/eam/purl/setupAutoPay.do?ipsTokenCd=UCDCT9FT8SY2ST",
  "transactionStatus": "S"
}
```

Error Response
==============
```sh
{
  "success": false,
  "message": "Payment Information receipt failed"
}
```

| API           | /payment/getAutoPayPurl |
|:--------------|:------------------------|
| Error Code    | 400                     |
| Error Message | Bad Request             |
| Error Code    | 404                     |
| Error Message | Not Found               |
| Error Code    | 500                     |
| Error Message | Internal Server Error   |


#### Error Code

| HTTP Status Code (BM) | BM Reason Code               | Message Text           |
|:----------------------|:-----------------------------|:-----------------------|
| 400 [Bad Request]     | INVALID_ADDRESS_LINE         | AddressLine must exist.                                                                                                                                          |
| 400                   | INVALID_INPUT                | The request XML did not pass validation. For example, invalid date, invalid postal code, invalid money, etc.                                                     |
| 400                   | INVALID_SESSION              | Session Details element is missing.                                                                                                                              |
| 400                   | INVALID_CON_FEE              | Convience Fee cannot be less than 0.00.                                                                                                                          |
| 400                   | INVALID_PAYMENT_AMT          | Missing PaymentAmt field                                                                                                                                         |
| 400                   | INVALID_PAYMENT_AMT_ZERO     | Payment Amount cannot be less than 0.01.                                                                                                                         |
| 400                   | INVALID_FIRST_LAST_NAME      | Both, First Name and Last Name are Required.                                                                                                                     |
| 400                   | REQUIRED_BUSINESS_NAME       | Business Name is required.                                                                                                                                       |
| 400                   | INVALID_ORDER_NO             | Invalid Order Number                                                                                                                                             |
| 400                   | INVALID_ENTITY_CODE          | Entity Code Id is invalid.                                                                                                                                       |
| 400                   | AMOUNT_MISMATCH              | The sum of the Entity Allocation amounts does not add up to the payment amount.                                                                                  |
| 400                   | INVALID_ZIP                  | Invalid Zip Code                                                                                                                                                 |
| 400                   | INVALID_EMAIL                | Invalid Email Address                                                                                                                                            |
| 400                   | INVALID_IP                   | Invalid Initiation IP Address                                                                                                                                    |
| 400                   | REQUIRED_SESSION_FAIL_URL    | Session Detail Failure Notification URL is required when Session Type = Payment.                                                                                 |
| 400                   | REQUIRED_SESSION_SUCCESS_URL | Session Detail Success Notification URL is required when Session Type = Payment.                                                                                 |
| 400                   | INVALID_PROJECT_CODE         | A project code is not defined for your request (The combination of BillingApplicationId + CustomerType + BIllingAcctRegion has a Unique Project Code).           |
| 400                   | INVALID_CHANNEL              | Invalid Input Channel ID                                                                                                                                         |
| 400                   | INVALID_SRC_APP              | Invalid Source Application ID                                                                                                                                    |
| 400                   | INVALID_USER                 | Invalid User ID field                                                                                                                                            |
| 400                   | INVALID_BILLING_APP          | 'For PaymentTypeCode AP or AD, the BillingApplicationId should be either of  CRIS-C, CRIS-E, CRIS-W'.                                                            |
| 400                   | INCORRECT_PMT                | Payment Amount must be evenly divisible by 5 for New or Existing Deposits.                                                                                       |
| 400                   | REQUIRED_BILLING_ACCOUNT     | Missing Billing AccountID                                                                                                                                        |
| 400                   | REQUIRED_PYMT_TRANSACTION_ID | Missing Payment Verification Transaction Id                                                                                                                      |
| 400                   | REQUIRED_TOTAL_PYMT_AMT      | Missing Total Pmt Amt                                                                                                                                            |
| 404                   | RESOURCE_NOT_FOUND_APPROVED  | No Payment records were found with Verification status as Approved, for the input Payment VerificationTranId when PaymentSubmitRequestType = AuthorizePayment.   |
| 400                   | INVALID_INPUT                | Authorization action is not allowed for the input SrcApplicationId and InputChannelId.                                                                           |
| 404                   | RESOURCE_NOT_FOUND_DONE      | No Payment records were found on Verification for the input PaymentVerificationTranId, when PaymentSubmitRequestType = AuthorizePayment.                         |
| 400                   | REQUIRED_EMAIL               | For the input SrcApplicationCd and InputChannelId, if the rule SyncMultiAuth = N or Null (not found in the PaymentProcessRuleRef table), then email is required. |
| 400                   | INVALID_TAX_AMT              | Total Tax Amount cannot be less than zero.                                                                                                                       |
| 401                   | AUTHENTICATION_FAILURE       | Authentication failed due to invalid authentication credential.                                                                                                  |
| 502                   | EPWF_SERVER_ERROR            | Got EPWF Internal Error while calling a sub process within the EPWF system.                                                                                      |
| 500                   | BM_PAYMENT_SERVER_ERROR      | Payment Business Service - \< API/Method Name\> is unable to process this request at this time.                                                                  |
| 500                   | PAYMENT_SERVICE_DB_ERROR     | The server is unable to process the request due to a database error.                                                                                             |
| 400                   | REQUIRED_ORDER_NO            | Order Number cannot be empty.                                                                                                                                    |
| 400                   | REQUIRED_PAYMENT_ID          | Payment Confirmation Number cannot be empty.                                                                                                                     |
| 400                   | ORN_NOT_FOUND_DB             | No data was found for given ORN.                                                                                                                                 |
| 400                   | REQUIRED_POSTAL_CODE         | Postal code cannot be empty.                                                                                                                                     |
| 400                   | REQUIRED_STATE_OR_PROVINCE   | State Or Province cannot be empty.                                                                                                                               |
| 400                   | REQUIRED_CITY                | City cannot be empty.                                                                                                                                            |
| 400                   | REQUIRED_STREET_ADDRESS1     | Address Line 1 cannot be empty.                                                                                                                                  |
| 400                   | REQUIRED_PAYMENT_TYPE_CODE   | Payment Type Code cannot be empty.                                                                                                                               |
| 400                   | INVALID_SRCSYSTEM_TRAN_ID    | SrcSystemTranId cannot be empty.                                                                                                                                 |
| 400                   | INVALID_PARTY_ROLE_ID        | PartyRoleId cannot be empty.                                                                                                                                     |
[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>