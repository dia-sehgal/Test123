---
title: "Offer Sumary"
date: 2018-05-24T09:51:24-07:00
draft: false
---


OfferSummary service is a generic service to deal with various types of offers depending on the service category[DATA,VOICE-HP,VOICE-DHP,DATA/VIDEO].
It is the core service which is the front face for camunda to give offers according to business logic.

In Camunda flow, camunda send request to offer summary then offer summary send request to catalog service then catalog service send all offers response to offer summary.
Offer summary shows only offer category Internet (data) offers.
For other offers created data, using base URL + timestamp + offer category.
Offer summary data populated into mongo DB.
Mongo DB have 3 schema one is ORNCatalogSpecDetail, ORNDatalinkMapping and dataLinkOfferModel.
There are 2 main operations in offer summary one is Add on offer and another is Update cart.

# Installation :
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
    - Visit [Oracle] website to get the Oracle JDBC driver â€“ ojdbc6.jar or ojdbc7.jar
    - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} 
      -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar

# SetUp : 
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/bmp-offersummary-service.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run
```

# Dependent systems :
   NA
   
# CI/CD Pipeline Details :
* Name:	 bmp-offersummary-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000

* Sonarqube Project URL:	 TBD

* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 https://ne1itcprhas62.ne1.savvis.net/BMP_DEV/bmp-offersummary-service/blob/release/final/Jenkinsfile

# Cloud Environment Details
* Cloud Group Name:	 BMPS-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-offersummary-service-test3.pcfmrnctl.dev.intranet

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/  

# Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards

# Swagger URL :
```sh
https://bmp-offersummary-service-test3.pcfmrnctl.dev.intranet
```

Detailed resources/operations specification are available [here](_offer_summary_api_spec_v2.6.1)


# Sample Request for Post(Create Offer Summary):
```sh
  {
     "geography": {
      "wirecenter": "LTTNCOHL",
      "state": "CO",
      "city": "HIGHLANDS RANCH"
    },
    "salesChannel": "ESHOP-Customer Care",
    "customerType": "INDIVIDUAL",
    "customerSegment": "Regular",
    "qualifiedServices": [      
       
      {
        "name": "HSI109120kbps/11008Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2-PB",
        "accessTypeForPrice": "NONE|VDSL2-PB",
        "upSpeed": "11008",
        "downSpeed": "109120",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "false",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI80128kbps/40128Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2-PB",
        "accessTypeForPrice": "NONE|VDSL2-PB",
        "upSpeed": "40128",
        "downSpeed": "80128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "false",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI60128kbps/30144Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2-PB",
        "accessTypeForPrice": "NONE|VDSL2-PB",
        "upSpeed": "30144",
        "downSpeed": "60128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "false",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI65472kbps/5504Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "5504",
        "downSpeed": "65472",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI40128kbps/20128Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "20128",
        "downSpeed": "40128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI40128kbps/5120Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "5120",
        "downSpeed": "40128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI20128kbps/5120Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "5120",
        "downSpeed": "20128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI12128kbps/5120Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "5120",
        "downSpeed": "12128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI7168kbps/5120Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "5120",
        "downSpeed": "7168",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI20128kbps/896Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "896",
        "downSpeed": "20128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI12128kbps/896Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "896",
        "downSpeed": "12128",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI10912kbps/1120Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "1120",
        "downSpeed": "10912",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI7168kbps/896Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "896",
        "downSpeed": "7168",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "false",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI4352kbps/1120Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "1120",
        "downSpeed": "4352",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "true",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": "HSI1536kbps/896Kbps",
        "serviceCategory": "DATA",
        "accessType": "VDSL2",
        "accessTypeForPrice": "NONE|VDSL2",
        "upSpeed": "896",
        "downSpeed": "1536",
        "prismSupported": false,
        "hpSupported": true,
        "dhpSupported": true,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": "false",
        "modemCompatibility": "false",
        "modemCompatibilityMessage": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
      },
      {
        "name": null,
       "serviceCategory": "VOICE-HP",
        "accessType": null,
        "accessTypeForPrice": null,
        "upSpeed": null,
        "downSpeed": null,
        "prismSupported": false,
        "hpSupported": false,
        "dhpSupported": false,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": null,
        "modemCompatibility": "NA",
        "modemCompatibilityMessage": "NA"
      },
      {
        "name": null,
        "serviceCategory": "VIDEO-DTV",
        "accessType": null,
        "accessTypeForPrice": null,
        "upSpeed": null,
        "downSpeed": null,
        "prismSupported": false,
        "hpSupported": false,
        "dhpSupported": false,
        "hdStreaming": 0,
        "sdStreaming": 0,
        "techInstallMandatory": null,
        "modemCompatibility": "NA",
        "modemCompatibilityMessage": "NA"
      }
    ],
    "customerOrderType": "NEWINSTALL"
  }
```

# Sample Response :
```sh
{
   "catalogSpecId": "77659",
   "offers":    [
            {
         "serviceCategory": "DATA",
         "offerDataLinkURL": "https://bmp-offersummary-service-dev3.pcfmrnctl.dev.intranet/bsi/offerdatalink/v1/baseURL/d67141c8-4c02-4036-bdbc-e539bf147ed6/21039070824768759/DATA",
         "catalogs": [         {
            "catalogId": "77659",
            "catalogName": "Catalog CO HIGHLANDS RANCH LTTNCOHL ESHOP-Customer Care Individual Regular",
            "catalogType": null,
            "catalogItems":             [
                              {
                  "productOffer":                   {
                     "productOfferingId": "3277",
                     "offerName": "HSI Upto 20 Mbps/2 Mbps PURE",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "87AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER1"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "1"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~MODEM~Account Type=Purchase::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 100,
                                       "discountedRc": 0,
                                       "discountedOtc": 100,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~MODEM~Account Type=Lease::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182867",
                              "productName": "HSI Upto 20 Mbps/2 Mbps",
                              "productDisplayName": "HSI up to 20 Mbps/2 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 20",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 20"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 2",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 2"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "20128",
                                          "uom": null,
                                          "attributeDisplayName": "20128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "5120",
                                          "uom": null,
                                          "attributeDisplayName": "5120"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~HSI Upto 20 Mbps/2 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 28.01,
                                       "otc": 0,
                                       "discountedRc": 28.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182920",
                              "productName": "Jack and Wire",
                              "productDisplayName": "Need new jacks or wiring?",
                              "productType": "WIRINGWORKS",
                              "productCategory": "OPT-EQP-CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1 jack"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~Jack and Wire~Installation Number=1",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 99,
                                       "discountedRc": 0,
                                       "discountedOtc": 99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Connection Type",
                                       "attributeValue": "USB",
                                       "uom": "NA",
                                       "attributeDisplayName": "USB"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Default Price",
                                       "attributeValue": "Default",
                                       "uom": "NA",
                                       "attributeDisplayName": "Default"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "2",
                                       "uom": "NA",
                                       "attributeDisplayName": "2"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "3",
                                       "uom": "NA",
                                       "attributeDisplayName": "3"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "4 or more",
                                       "uom": "NA",
                                       "attributeDisplayName": "4 or more"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Tech",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "No work is needed",
                                       "uom": null,
                                       "attributeDisplayName": "No work is needed"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~Jack and Wire~Installation Number=No work is needed",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 5
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3277~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        }
                     ],
                     "associatedOffers": [                     {
                        "associatedOfferCategory": "INTERNET",
                        "associationType":                         {
                           "associationType": "ADDON",
                           "selectionRule": "ANY",
                           "associatedOfferIds":                            [
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3222",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3221",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3223",
                                 "discount": null
                              }
                           ]
                        }
                     }],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 45,
                     "otc": 0,
                     "discountedRc": 45,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3277",
                  "displayOrder": 210,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3276",
                     "offerName": "HSI Upto 20 Mbps/896 Kbps PURE",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "87AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER1"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "1"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182920",
                              "productName": "Jack and Wire",
                              "productDisplayName": "Need new jacks or wiring?",
                              "productType": "WIRINGWORKS",
                              "productCategory": "OPT-EQP-CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1 jack"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~Jack and Wire~Installation Number=1",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 99,
                                       "discountedRc": 0,
                                       "discountedOtc": 99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Connection Type",
                                       "attributeValue": "USB",
                                       "uom": "NA",
                                       "attributeDisplayName": "USB"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Default Price",
                                       "attributeValue": "Default",
                                       "uom": "NA",
                                       "attributeDisplayName": "Default"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "2",
                                       "uom": "NA",
                                       "attributeDisplayName": "2"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "3",
                                       "uom": "NA",
                                       "attributeDisplayName": "3"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "4 or more",
                                       "uom": "NA",
                                       "attributeDisplayName": "4 or more"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Tech",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "No work is needed",
                                       "uom": null,
                                       "attributeDisplayName": "No work is needed"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~Jack and Wire~Installation Number=No work is needed",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 5
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182902",
                              "productName": "HSI Upto 20 Mbps/896 Kbps",
                              "productDisplayName": "HSI up to 20 Mbps/896 Kbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 20",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 20"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 896",
                                       "uom": "Kbps",
                                       "attributeDisplayName": "0 - 896"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "20128",
                                          "uom": null,
                                          "attributeDisplayName": "20128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "896",
                                          "uom": null,
                                          "attributeDisplayName": "896"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~HSI Upto 20 Mbps/896 Kbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 28.01,
                                       "otc": 0,
                                       "discountedRc": 28.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~MODEM~Account Type=Purchase::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 100,
                                       "discountedRc": 0,
                                       "discountedOtc": 100,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~MODEM~Account Type=Lease::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3276~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        }
                     ],
                     "associatedOffers": [                     {
                        "associatedOfferCategory": "INTERNET",
                        "associationType":                         {
                           "associationType": "ADDON",
                           "selectionRule": "ANY",
                           "associatedOfferIds":                            [
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3223",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3222",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3221",
                                 "discount": null
                              }
                           ]
                        }
                     }],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 45,
                     "otc": 0,
                     "discountedRc": 45,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3276",
                  "displayOrder": 240,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3274",
                     "offerName": "HSI Upto 20 Mbps/2 Mbps",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET AND UNLIMITED HOME PHONE UNLIMITED CALLING",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "420AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER1"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "1"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "NON STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lease"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchase"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "ADVANCED"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchase"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~MODEM~Account Type=Purchase::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 100,
                                       "discountedRc": 0,
                                       "discountedOtc": 100,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "ADVANCED"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Lease"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~MODEM~Account Type=Lease::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182867",
                              "productName": "HSI Upto 20 Mbps/2 Mbps",
                              "productDisplayName": "HSI up to 20 Mbps/2 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 20",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 20"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 2",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 2"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "20128",
                                          "uom": null,
                                          "attributeDisplayName": "20128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "5120",
                                          "uom": null,
                                          "attributeDisplayName": "5120"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~HSI Upto 20 Mbps/2 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 23.01,
                                       "otc": 0,
                                       "discountedRc": 23.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3274~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        }
                     ],
                     "associatedOffers":                      [
                                                {
                           "associatedOfferCategory": "INTERNET",
                           "associationType":                            {
                              "associationType": "ADDON",
                              "selectionRule": "ANY",
                              "associatedOfferIds":                               [
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3222",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3221",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3223",
                                    "discount": null
                                 }
                              ]
                           }
                        },
                                                {
                           "associatedOfferCategory": "VOICE-HP",
                           "associationType":                            {
                              "associationType": "BUNDLEITEM",
                              "selectionRule": "ANY",
                              "associatedOfferIds": [                              {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3287",
                                 "discount": null
                              }]
                           }
                        }
                     ],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 40,
                     "otc": 0,
                     "discountedRc": 40,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3274",
                  "displayOrder": 200,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3272",
                     "offerName": "HSI Upto 20 Mbps/896 Kbps",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET AND UNLIMITED HOME PHONE UNLIMITED CALLING",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "420AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER1"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "1"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "NON STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182902",
                              "productName": "HSI Upto 20 Mbps/896 Kbps",
                              "productDisplayName": "HSI up to 20 Mbps/896 Kbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 20",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 20"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 896",
                                       "uom": "Kbps",
                                       "attributeDisplayName": "0 - 896"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "20128",
                                          "uom": null,
                                          "attributeDisplayName": "20128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "896",
                                          "uom": null,
                                          "attributeDisplayName": "896"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~HSI Upto 20 Mbps/896 Kbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 23.01,
                                       "otc": 0,
                                       "discountedRc": 23.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lease"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchase"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "ADVANCED"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchase"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~MODEM~Account Type=Purchase::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 100,
                                       "discountedRc": 0,
                                       "discountedOtc": 100,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "ADVANCED",
                                          "uom": null,
                                          "attributeDisplayName": "ADVANCED"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Lease"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~MODEM~Account Type=Lease::Modem Class=ADVANCED",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3272~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        }
                     ],
                     "associatedOffers":                      [
                                                {
                           "associatedOfferCategory": "INTERNET",
                           "associationType":                            {
                              "associationType": "ADDON",
                              "selectionRule": "ANY",
                              "associatedOfferIds":                               [
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3223",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3222",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3221",
                                    "discount": null
                                 }
                              ]
                           }
                        },
                                                {
                           "associatedOfferCategory": "VOICE-HP",
                           "associationType":                            {
                              "associationType": "BUNDLEITEM",
                              "selectionRule": "ANY",
                              "associatedOfferIds": [                              {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3287",
                                 "discount": null
                              }]
                           }
                        }
                     ],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 40,
                     "otc": 0,
                     "discountedRc": 40,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3272",
                  "displayOrder": 230,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3260",
                     "offerName": "HSI Upto 80 Mbps/10 Mbps",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET AND UNLIMITED HOME PHONE UNLIMITED CALLING",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "420AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER2"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "2"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "NON STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~MODEM~Account Type=Lease::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~MODEM~Account Type=Purchase::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 150,
                                       "discountedRc": 0,
                                       "discountedOtc": 150,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182887",
                              "productName": "HSI Upto 80 Mbps/10 Mbps",
                              "productDisplayName": "HSI up to 80 Mbps/10 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 80",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 80"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 10",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 10"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2-PB",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2-PB"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "80128",
                                          "uom": null,
                                          "attributeDisplayName": "80128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "40128",
                                          "uom": null,
                                          "attributeDisplayName": "40128"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~HSI Upto 80 Mbps/10 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 33.01,
                                       "otc": 0,
                                       "discountedRc": 33.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Self Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Self Install"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3260~TECH INSTALL~Service Level=Self Install",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 3
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        }
                     ],
                     "associatedOffers":                      [
                                                {
                           "associatedOfferCategory": "INTERNET",
                           "associationType":                            {
                              "associationType": "ADDON",
                              "selectionRule": "ANY",
                              "associatedOfferIds":                               [
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3223",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3221",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3222",
                                    "discount": null
                                 }
                              ]
                           }
                        },
                                                {
                           "associatedOfferCategory": "VOICE-HP",
                           "associationType":                            {
                              "associationType": "BUNDLEITEM",
                              "selectionRule": "ANY",
                              "associatedOfferIds": [                              {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3287",
                                 "discount": null
                              }]
                           }
                        }
                     ],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 50,
                     "otc": 0,
                     "discountedRc": 50,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3260",
                  "displayOrder": 50,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3238",
                     "offerName": "HSI Upto 60 Mbps/5 Mbps PURE",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "87AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER2"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "2"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~MODEM~Account Type=Purchase::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 150,
                                       "discountedRc": 0,
                                       "discountedOtc": 150,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~MODEM~Account Type=Lease::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Self Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Self Install"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~TECH INSTALL~Service Level=Self Install",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 3
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182920",
                              "productName": "Jack and Wire",
                              "productDisplayName": "Need new jacks or wiring?",
                              "productType": "WIRINGWORKS",
                              "productCategory": "OPT-EQP-CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1 jack"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~Jack and Wire~Installation Number=1",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 99,
                                       "discountedRc": 0,
                                       "discountedOtc": 99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Connection Type",
                                       "attributeValue": "USB",
                                       "uom": "NA",
                                       "attributeDisplayName": "USB"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Default Price",
                                       "attributeValue": "Default",
                                       "uom": "NA",
                                       "attributeDisplayName": "Default"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "2",
                                       "uom": "NA",
                                       "attributeDisplayName": "2"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "3",
                                       "uom": "NA",
                                       "attributeDisplayName": "3"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "4 or more",
                                       "uom": "NA",
                                       "attributeDisplayName": "4 or more"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Tech",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "No work is needed",
                                       "uom": null,
                                       "attributeDisplayName": "No work is needed"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~Jack and Wire~Installation Number=No work is needed",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 5
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182944",
                              "productName": "HSI Upto 60 Mbps/5 Mbps",
                              "productDisplayName": "HSI up to 60 Mbps/5 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 5",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 5"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 60",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 60"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2-PB",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2-PB"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "65472",
                                          "uom": null,
                                          "attributeDisplayName": "65472"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "5504",
                                          "uom": null,
                                          "attributeDisplayName": "5504"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "60128",
                                          "uom": null,
                                          "attributeDisplayName": "60128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "30144",
                                          "uom": null,
                                          "attributeDisplayName": "30144"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3238~HSI Upto 60 Mbps/5 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 38.01,
                                       "otc": 0,
                                       "discountedRc": 38.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        }
                     ],
                     "associatedOffers": [                     {
                        "associatedOfferCategory": "INTERNET",
                        "associationType":                         {
                           "associationType": "ADDON",
                           "selectionRule": "ANY",
                           "associatedOfferIds":                            [
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3222",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3223",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3221",
                                 "discount": null
                              }
                           ]
                        }
                     }],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 55,
                     "otc": 0,
                     "discountedRc": 55,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3238",
                  "displayOrder": 100,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3257",
                     "offerName": "HSI Upto 80 Mbps/10 Mbps PURE",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "87AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER2"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "2"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~MODEM~Account Type=Lease::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~MODEM~Account Type=Purchase::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 150,
                                       "discountedRc": 0,
                                       "discountedOtc": 150,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182887",
                              "productName": "HSI Upto 80 Mbps/10 Mbps",
                              "productDisplayName": "HSI up to 80 Mbps/10 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 80",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 80"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 10",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 10"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2-PB",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2-PB"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "80128",
                                          "uom": null,
                                          "attributeDisplayName": "80128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "40128",
                                          "uom": null,
                                          "attributeDisplayName": "40128"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~HSI Upto 80 Mbps/10 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 38.01,
                                       "otc": 0,
                                       "discountedRc": 38.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Self Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Self Install"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~TECH INSTALL~Service Level=Self Install",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 3
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182920",
                              "productName": "Jack and Wire",
                              "productDisplayName": "Need new jacks or wiring?",
                              "productType": "WIRINGWORKS",
                              "productCategory": "OPT-EQP-CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1 jack"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~Jack and Wire~Installation Number=1",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 99,
                                       "discountedRc": 0,
                                       "discountedOtc": 99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Connection Type",
                                       "attributeValue": "USB",
                                       "uom": "NA",
                                       "attributeDisplayName": "USB"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Default Price",
                                       "attributeValue": "Default",
                                       "uom": "NA",
                                       "attributeDisplayName": "Default"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "2",
                                       "uom": "NA",
                                       "attributeDisplayName": "2"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "3",
                                       "uom": "NA",
                                       "attributeDisplayName": "3"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "4 or more",
                                       "uom": "NA",
                                       "attributeDisplayName": "4 or more"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Tech",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "No work is needed",
                                       "uom": null,
                                       "attributeDisplayName": "No work is needed"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~Jack and Wire~Installation Number=No work is needed",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 5
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3257~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        }
                     ],
                     "associatedOffers": [                     {
                        "associatedOfferCategory": "INTERNET",
                        "associationType":                         {
                           "associationType": "ADDON",
                           "selectionRule": "ANY",
                           "associatedOfferIds":                            [
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3223",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3222",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3221",
                                 "discount": null
                              }
                           ]
                        }
                     }],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 55,
                     "otc": 0,
                     "discountedRc": 55,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3257",
                  "displayOrder": 40,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3245",
                     "offerName": "HSI Upto 60 Mbps/5 Mbps",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET AND UNLIMITED HOME PHONE UNLIMITED CALLING",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "420AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER2"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "2"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "NON STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182944",
                              "productName": "HSI Upto 60 Mbps/5 Mbps",
                              "productDisplayName": "HSI up to 60 Mbps/5 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 5",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 5"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 60",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 60"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2-PB",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2-PB"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "65472",
                                          "uom": null,
                                          "attributeDisplayName": "65472"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "5504",
                                          "uom": null,
                                          "attributeDisplayName": "5504"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "60128",
                                          "uom": null,
                                          "attributeDisplayName": "60128"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "30144",
                                          "uom": null,
                                          "attributeDisplayName": "30144"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~HSI Upto 60 Mbps/5 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 33.01,
                                       "otc": 0,
                                       "discountedRc": 33.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~MODEM~Account Type=Lease::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~MODEM~Account Type=Purchase::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 150,
                                       "discountedRc": 0,
                                       "discountedOtc": 150,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Self Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Self Install"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~TECH INSTALL~Service Level=Self Install",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 3
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3245~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        }
                     ],
                     "associatedOffers":                      [
                                                {
                           "associatedOfferCategory": "VOICE-HP",
                           "associationType":                            {
                              "associationType": "BUNDLEITEM",
                              "selectionRule": "ANY",
                              "associatedOfferIds": [                              {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3287",
                                 "discount": null
                              }]
                           }
                        },
                                                {
                           "associatedOfferCategory": "INTERNET",
                           "associationType":                            {
                              "associationType": "ADDON",
                              "selectionRule": "ANY",
                              "associatedOfferIds":                               [
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3221",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3222",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3223",
                                    "discount": null
                                 }
                              ]
                           }
                        }
                     ],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 50,
                     "otc": 0,
                     "discountedRc": 50,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3245",
                  "displayOrder": 110,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3252",
                     "offerName": "HSI Upto 100 Mbps/10 Mbps PURE",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "87AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER3"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "2"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182920",
                              "productName": "Jack and Wire",
                              "productDisplayName": "Need new jacks or wiring?",
                              "productType": "WIRINGWORKS",
                              "productCategory": "OPT-EQP-CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1 jack"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~Jack and Wire~Installation Number=1",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 99,
                                       "discountedRc": 0,
                                       "discountedOtc": 99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Connection Type",
                                       "attributeValue": "USB",
                                       "uom": "NA",
                                       "attributeDisplayName": "USB"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Default Price",
                                       "attributeValue": "Default",
                                       "uom": "NA",
                                       "attributeDisplayName": "Default"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "2",
                                       "uom": "NA",
                                       "attributeDisplayName": "2"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "3",
                                       "uom": "NA",
                                       "attributeDisplayName": "3"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Quantity",
                                       "attributeValue": "4 or more",
                                       "uom": "NA",
                                       "attributeDisplayName": "4 or more"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Tech",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Shipping Method",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Installation Number",
                                       "attributeValue": "No work is needed",
                                       "uom": null,
                                       "attributeDisplayName": "No work is needed"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~Jack and Wire~Installation Number=No work is needed",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 5
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Self Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Self Install"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~TECH INSTALL~Service Level=Self Install",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 3
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "183007",
                              "productName": "HSI Upto 100 Mbps/10 Mbps",
                              "productDisplayName": "HSI up to 100 Mbps/10 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 10",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 10"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 100",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 100"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2-PB",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2-PB"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "109120",
                                          "uom": null,
                                          "attributeDisplayName": "109120"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "11008",
                                          "uom": null,
                                          "attributeDisplayName": "11008"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~HSI Upto 100 Mbps/10 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 48.01,
                                       "otc": 0,
                                       "discountedRc": 48.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~MODEM~Account Type=Lease::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3252~MODEM~Account Type=Purchase::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 150,
                                       "discountedRc": 0,
                                       "discountedOtc": 150,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        }
                     ],
                     "associatedOffers": [                     {
                        "associatedOfferCategory": "INTERNET",
                        "associationType":                         {
                           "associationType": "ADDON",
                           "selectionRule": "ANY",
                           "associatedOfferIds":                            [
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3222",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3223",
                                 "discount": null
                              },
                                                            {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3221",
                                 "discount": null
                              }
                           ]
                        }
                     }],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 65,
                     "otc": 0,
                     "discountedRc": 65,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3252",
                  "displayOrder": 20,
                  "isDefault": 0
               },
                              {
                  "productOffer":                   {
                     "productOfferingId": "3267",
                     "offerName": "HSI Upto 100 Mbps/10 Mbps",
                     "offerDisplayName": "PRICE FOR LIFE INTERNET AND UNLIMITED HOME PHONE UNLIMITED CALLING",
                     "offerType": "P4L",
                     "offerSubType": "REGULAR",
                     "offerCategory": "INTERNET",
                     "offerAttributes":                      [
                                                {
                           "attributeName": "with-INTERNET",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withPhone-DHP",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withPhone-HP",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "withTV-DTV",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "withTV-PRISM",
                           "attributeValue": "NO"
                        },
                                                {
                           "attributeName": "isPriceForLife",
                           "attributeValue": "YES"
                        },
                                                {
                           "attributeName": "bundlePromoId",
                           "attributeValue": "420AQ"
                        },
                                                {
                           "attributeName": "priceTier",
                           "attributeValue": "TIER3"
                        },
                                                {
                           "attributeName": "noOfHighestSpeedsInTier",
                           "attributeValue": "2"
                        },
                                                {
                           "attributeName": "EN_OFFER_TYPE",
                           "attributeValue": "NON STANDALONE-BUNDLE"
                        }
                     ],
                     "productComponents":                      [
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182927",
                              "productName": "MODEM",
                              "productDisplayName": "Your Modem",
                              "productType": "INTERNET",
                              "productCategory": "EQP",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Lease",
                                       "uom": "NA",
                                       "attributeDisplayName": "Leased Modem"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Account Type",
                                       "attributeValue": "Purchase",
                                       "uom": "NA",
                                       "attributeDisplayName": "Purchased Modem"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Below 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Below 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Modem Type",
                                       "attributeValue": "Above 1G",
                                       "uom": "NA",
                                       "attributeDisplayName": "Above 1G"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibility",
                                       "attributeValue": "NA",
                                       "uom": null,
                                       "attributeDisplayName": "NA"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "modemCompatibilityMessage",
                                       "attributeValue": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem.",
                                       "uom": null,
                                       "attributeDisplayName": "Current modem is NOT COMPATIBLE with the requested service. Order a new modem."
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Lease",
                                          "uom": null,
                                          "attributeDisplayName": "Leased Modem"
                                       }
                                    ],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~MODEM~Account Type=Lease::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 10,
                                       "otc": 0,
                                       "discountedRc": 10,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Modem Class",
                                          "attributeValue": "PREMIUM",
                                          "uom": null,
                                          "attributeDisplayName": "NODISPLAY"
                                       },
                                                                              {
                                          "attributeName": "Account Type",
                                          "attributeValue": "Purchase",
                                          "uom": null,
                                          "attributeDisplayName": "Purchased Modem"
                                       }
                                    ],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~MODEM~Account Type=Purchase::Modem Class=PREMIUM",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 150,
                                       "discountedRc": 0,
                                       "discountedOtc": 150,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 3
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182983",
                              "productName": "ISP",
                              "productDisplayName": "ISP",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Vendor",
                                       "attributeValue": "CenturyLink",
                                       "uom": "NA",
                                       "attributeDisplayName": "CenturyLink"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~ISP",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 16.99,
                                       "otc": 0,
                                       "discountedRc": 16.99,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "10",
                                       "uom": "NA",
                                       "attributeDisplayName": "10"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Number of Mailboxes",
                                       "attributeValue": "11",
                                       "uom": "NA",
                                       "attributeDisplayName": "11"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 2
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 0
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "180194",
                              "productName": "TECH INSTALL",
                              "productDisplayName": "Your best installation option",
                              "productType": "INTERNET",
                              "productCategory": "TECHINST",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Lite",
                                       "uom": "NA",
                                       "attributeDisplayName": "Lite"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~TECH INSTALL~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 60,
                                       "discountedRc": 0,
                                       "discountedOtc": 60,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Self Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Self Install"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~TECH INSTALL~Service Level=Self Install",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 3
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 2
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "183007",
                              "productName": "HSI Upto 100 Mbps/10 Mbps",
                              "productDisplayName": "HSI up to 100 Mbps/10 Mbps",
                              "productType": "INTERNET",
                              "productCategory": "CORE",
                              "quantity":                               {
                                 "minQuantity": 1,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 1
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "IsPrimary",
                                       "attributeValue": "ADDON",
                                       "uom": "NA",
                                       "attributeDisplayName": "ADDON"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Transport Medium",
                                       "attributeValue": "Optical Fiber Network",
                                       "uom": "NA",
                                       "attributeDisplayName": "Optical Fiber Network"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductActivationDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Product Sub-Type",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Ensemble Product Type",
                                       "attributeValue": "QW",
                                       "uom": "NA",
                                       "attributeDisplayName": "QW"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Group",
                                       "attributeValue": "HSI",
                                       "uom": "NA",
                                       "attributeDisplayName": "HSI"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Max Quantity",
                                       "attributeValue": "1",
                                       "uom": "NA",
                                       "attributeDisplayName": "1"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "ProductDisconnectDate",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Sub Service Group",
                                       "attributeValue": "SRV",
                                       "uom": "NA",
                                       "attributeDisplayName": "SRV"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived Upspeed",
                                       "attributeValue": "0 - 10",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 10"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "allowMACD",
                                       "attributeValue": "",
                                       "uom": "NA",
                                       "attributeDisplayName": ""
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Derived DownSpeed",
                                       "attributeValue": "0 - 100",
                                       "uom": "Mbps",
                                       "attributeDisplayName": "0 - 100"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "prismSupported",
                                       "attributeValue": "false",
                                       "uom": null,
                                       "attributeDisplayName": "false"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "dhpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "hpSupported",
                                       "attributeValue": "true",
                                       "uom": null,
                                       "attributeDisplayName": "true"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 },
                                                                  {
                                    "compositeAttribute":                                     [
                                                                              {
                                          "attributeName": "Technology",
                                          "attributeValue": "VDSL2-PB",
                                          "uom": null,
                                          "attributeDisplayName": "VDSL2-PB"
                                       },
                                                                              {
                                          "attributeName": "Downspeed",
                                          "attributeValue": "109120",
                                          "uom": null,
                                          "attributeDisplayName": "109120"
                                       },
                                                                              {
                                          "attributeName": "Upspeed",
                                          "attributeValue": "11008",
                                          "uom": null,
                                          "attributeDisplayName": "11008"
                                       }
                                    ],
                                    "displayOrder": 0,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~HSI Upto 100 Mbps/10 Mbps~Technology=NONE",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 43.01,
                                       "otc": 0,
                                       "discountedRc": 43.01,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": [],
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "PRIMARY",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 1
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182940",
                              "productName": "CENTURYLINK @ EASE",
                              "productDisplayName": "@ Ease",
                              "productType": "INTERNET",
                              "productCategory": "VAS",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.22,
                                          "otc": 0,
                                          "discountedRc": 1.22,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level I)",
                                          "rc": 4.45,
                                          "otc": 0,
                                          "discountedRc": 4.45,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (5GB)",
                                          "rc": 0.44,
                                          "otc": 0,
                                          "discountedRc": 0.44,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 9.99,
                                          "otc": 0,
                                          "discountedRc": 9.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Standard",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 3.88,
                                          "otc": 0,
                                          "discountedRc": 3.88,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Ultra",
                                       "uom": "NA",
                                       "attributeDisplayName": "Ultra"
                                    }],
                                    "displayOrder": 4,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 0.49,
                                          "otc": 0,
                                          "discountedRc": 0.49,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Ultd)",
                                          "rc": 4.04,
                                          "otc": 0,
                                          "discountedRc": 4.04,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (200 GB)",
                                          "rc": 2.7,
                                          "otc": 0,
                                          "discountedRc": 2.7,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Identity Theft Protection",
                                          "rc": 9.87,
                                          "otc": 0,
                                          "discountedRc": 9.87,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 19.99,
                                          "otc": 0,
                                          "discountedRc": 19.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 0.77,
                                          "otc": 0,
                                          "discountedRc": 0.77,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Ultra",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 2.12,
                                          "otc": 0,
                                          "discountedRc": 2.12,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 4
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Advanced",
                                       "uom": "NA",
                                       "attributeDisplayName": "Advanced"
                                    }],
                                    "displayOrder": 3,
                                    "isPriceable": true,
                                    "prices":                                     [
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "PRICE",
                                          "priceTypeDescription": "MRC/OTC",
                                          "rc": 14.99,
                                          "otc": 0,
                                          "discountedRc": 14.99,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Desktop Security",
                                          "rc": 1.46,
                                          "otc": 0,
                                          "discountedRc": 1.46,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Equip Warranty w/ Modem Purch",
                                          "rc": 1.07,
                                          "otc": 0,
                                          "discountedRc": 1.07,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "Online Backup (50 GB)",
                                          "rc": 0.61,
                                          "otc": 0,
                                          "discountedRc": 0.61,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Protection Plan",
                                          "rc": 4.69,
                                          "otc": 0,
                                          "discountedRc": 4.69,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       },
                                                                              {
                                          "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Advanced",
                                          "priceType": "INCLUDED",
                                          "priceTypeDescription": "PC Support Services (Level II)",
                                          "rc": 7.16,
                                          "otc": 0,
                                          "discountedRc": 7.16,
                                          "discountedOtc": 0,
                                          "frequency": "1",
                                          "currencyCode": "USD",
                                          "provisioningAction": null
                                       }
                                    ],
                                    "discounts": null,
                                    "isDefault": 3
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Basic",
                                       "uom": null,
                                       "attributeDisplayName": "Basic"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~CENTURYLINK @ EASE~Service Level=Basic",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/NRC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": null,
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": true,
                           "isDefault": 0,
                           "displayOrder": 4
                        },
                                                {
                           "additionalUiAttrProduct": null,
                           "product":                            {
                              "productId": "182840",
                              "productName": "SHIPPING",
                              "productDisplayName": "SHIPPING",
                              "productType": "INTERNET",
                              "productCategory": "SHIPPING",
                              "quantity":                               {
                                 "minQuantity": 0,
                                 "maxQuantity": 1,
                                 "defaultQuantity": 0
                              },
                              "productAttributes":                               [
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Overnight",
                                       "uom": "NA",
                                       "attributeDisplayName": "Overnight"
                                    }],
                                    "displayOrder": 2,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~SHIPPING~Service Level=Overnight",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 22.99,
                                       "discountedRc": 0,
                                       "discountedOtc": 22.99,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 2
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Standard",
                                       "uom": "NA",
                                       "attributeDisplayName": "Standard"
                                    }],
                                    "displayOrder": 1,
                                    "isPriceable": true,
                                    "prices": [                                    {
                                       "priceKey": "77659~77659~3267~SHIPPING~Service Level=Standard",
                                       "priceType": "PRICE",
                                       "priceTypeDescription": "MRC/OTC",
                                       "rc": 0,
                                       "otc": 0,
                                       "discountedRc": 0,
                                       "discountedOtc": 0,
                                       "frequency": "1",
                                       "currencyCode": "USD",
                                       "provisioningAction": null
                                    }],
                                    "discounts": null,
                                    "isDefault": 1
                                 },
                                                                  {
                                    "compositeAttribute": [                                    {
                                       "attributeName": "Service Level",
                                       "attributeValue": "Tech Install",
                                       "uom": "NA",
                                       "attributeDisplayName": "Tech Install"
                                    }],
                                    "displayOrder": 0,
                                    "isPriceable": false,
                                    "prices": null,
                                    "discounts": null,
                                    "isDefault": 0
                                 }
                              ],
                              "productAssociations": [],
                              "isRegulated": false
                           },
                           "componentType": "COMPONENT",
                           "isMandatory": false,
                           "isDefault": 0,
                           "displayOrder": 0
                        }
                     ],
                     "associatedOffers":                      [
                                                {
                           "associatedOfferCategory": "INTERNET",
                           "associationType":                            {
                              "associationType": "ADDON",
                              "selectionRule": "ANY",
                              "associatedOfferIds":                               [
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3222",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3223",
                                    "discount": null
                                 },
                                                                  {
                                    "displayOrder": 0,
                                    "associatedOfferId": "3221",
                                    "discount": null
                                 }
                              ]
                           }
                        },
                                                {
                           "associatedOfferCategory": "VOICE-HP",
                           "associationType":                            {
                              "associationType": "BUNDLEITEM",
                              "selectionRule": "ANY",
                              "associatedOfferIds": [                              {
                                 "displayOrder": 0,
                                 "associatedOfferId": "3287",
                                 "discount": null
                              }]
                           }
                        }
                     ],
                     "contract":                      {
                        "contractTerm": 0,
                        "isPriceLock": false,
                        "priceLockDuration": 0,
                        "etf": 0,
                        "currencyCode": null
                     },
                     "validFor":                      {
                        "saleEffectiveDate": "2018-07-09T05:20:40.000Z",
                        "saleExpirationDate": "2118-07-09T05:20:40.000Z"
                     }
                  },
                  "defaultOfferPrice":                   {
                     "rc": 60,
                     "otc": 0,
                     "discountedRc": 60,
                     "discountedOtc": 0
                  },
                  "productOfferingId": "3267",
                  "displayOrder": 30,
                  "isDefault": 0
               }
            ]
         }]
      },
            {
         "serviceCategory": "VOICE-HP",
         "offerDataLinkURL": "https://bmp-offersummary-service-dev3.pcfmrnctl.dev.intranet/bsi/offerdatalink/v1/baseURL/d67141c8-4c02-4036-bdbc-e539bf147ed6/21039070824768759/VOICE-HP",
         "catalogs": []
      },
            {
         "serviceCategory": "VIDEO-DTV",
         "offerDataLinkURL": "https://bmp-offersummary-service-dev3.pcfmrnctl.dev.intranet/bsi/offerdatalink/v1/baseURL/d67141c8-4c02-4036-bdbc-e539bf147ed6/21039070824768759/VIDEO-DTV",
         "catalogs": []
      }
   ],
   "cart":    {
      "catalogSpecId": "77659",
      "customerOrderItems": [      {
         "contractStartDate": null,
         "offerName": null,
         "catalogId": null,
         "productOfferingId": null,
         "offerType": null,
         "offerSubType": null,
         "offerCategory": null,
         "contractTerm": 0,
         "quantity": null,
         "action": null,
         "rc": 0,
         "otc": 0,
         "discountedRc": 0,
         "discountedOtc": 0,
         "customerOrderSubItems": [         {
            "provisioningAction": null,
            "productId": null,
            "productName": null,
            "productType": null,
            "productCategory": null,
            "componentType": null,
            "quantity": null,
            "action": null,
            "productAttributes": [            {
               "compositeAttribute": null,
               "displayOrder": 0,
               "isPriceable": false,
               "prices": null,
               "discounts": null,
               "isDefault": 0
            }],
            "productAssociations": [            {
               "productIds": null,
               "productAssociationType": null
            }]
         }]
      }]
   }
}
```