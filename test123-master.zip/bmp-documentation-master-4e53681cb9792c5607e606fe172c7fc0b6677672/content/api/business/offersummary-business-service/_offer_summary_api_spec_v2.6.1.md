Offer Summary Business Service 
===============================
    Version: 2.6.1

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[vx.x.x.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /getOfferSummary](#Request)
- [Response /getAddOnOffers](#Response)

Overview
--------

> **This is an internal business service to create **Offer Summary** with discounts, add-on offer details and update cart information.**

![](media/OfferSummaryDiagram.png)

Resources
---------

For each resource, the following items are documented.

| Name           | Value                               |
|:---------------|:------------------------------------|
| HTTP Method    | GET                                 |
| Base URI       | /bsi/OfferSummaryBusinessService/v1 |
| URI Syntax     |                                     |
| Operation Name | /getOfferSummary                    |

Request and Response Formats
----------------------------

    API: /getOfferSummary

Request
=======
```sh
{
  "orderReferenceNumber": "ORN-20170808100628481",
  "geography": {
    "wirecenter": "CYLKFL",
    "city": "FORT MYERS",
    "state": "FL"
  },
  "salesChannel": "ESHOP",
  "customerType": "Individual",
  "customerSegment": "Regular",
  "qualifiedServices": [
    {
      "name": "HSI 40128 Kbps/5214 Kbps",
      "serviceCategory": "DATA",
      "accessType": "ADSL2+",
      "downSpeed": 40128,
      "upSpeed": 5128,
      "prismSupported": true,
      "hdStreaming": 4,
      "sdStreaming": 3,
      "dhpSupported": true,
      "isTechInstallMandatory": true,
      "hpSupported": true,
      "modemCompatibility": "NA",
      "modemCompatibilityMessage": "NA"
    }
  ],
  "customerOrderType": "string"
}
```

Response
==========
```sh
{
  "catalogSpecId": "b982b278",
  "offers": [
    {
      "serviceCategory": "DATA",
      "offerDataLink": "{RandomUniqueIdentifier}/productOfferings/DATA",
      "catalogs": [
        {
          "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
          "catalogName": "Catalog Spec HSI",
          "catalogType": "US West Residential Internet",
          "catalogItems": [
            {
              "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
              "productOffer": {
                "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
                "offerName": "HSI Upto 20 Mbps Downstream/5 Mbps Upstream",
                "offerDisplayName": "20M/5M",
                "offerDescription": "string",
                "offerType": "BUNDLE",
                "offerSubType": "REGULAR",
                "offerCategory": "INTERNET",
                "offerAttributes": [
                  {
                    "attributeName": "name",
                    "attributeValue": "value"
                  }
                ],
                "productComponents": [
                  {
                    "product": {
                      "productId": 101,
                      "productName": "HSI 20128 Kbps/5128 Kbps",
                      "productDisplayName": "20M/5M",
                      "productType": "INTERNET",
                      "productCategory": "CORE",
                      "isRegulated": false,
                      "quantity": {
                        "minQuantity": 1,
                        "maxQuantity": 1,
                        "defaultQuantity": 1
                      },
                      "productAttributes": [
                        {
                          "compositeAttribute": [
                            {
                              "attributeName": "downSpeed",
                              "attributeValue": 20128,
                              "uom": "Kbps",
                              "attributeDisplayName": "string"
                            }
                          ],
                          "isDefault": 0,
                          "displayOrder": 1,
                          "isPriceable": true,
                          "prices": [
                            {
                              "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                              "priceType": "SUBSCRIPTION",
                              "priceTypeDescription": "string",
                              "rc": 39.99,
                              "otc": 69.99,
                              "discountedRc": 29.99,
                              "discountedOtc": 49.99,
                              "frequency": "PERMONTH",
                              "currencyCode": "USD",
                              "provisioningAction": "PROVISIONnBILL"
                            }
                          ],
                          "discounts": [
                            {
                              "autoAttachInd": "Y",
                              "discountId": "DC1",
                              "discountDescription": "Discount Description DC1",
                              "discountRate": 10,
                              "discountMethod": "FLATAMOUNT",
                              "discountLevel": "P",
                              "discountDuration": 1,
                              "discountType": "P",
                              "discountCategory": "RCD",
                              "discountMaxAmount": 10,
                              "discountMinimumAmount": 5,
                              "discountIdSequence": 1,
                              "discountRule": "ANY"
                            }
                          ]
                        }
                      ],
                      "additionalUiAttrProduct": [
                        {
                          "name": "string",
                          "value": "string"
                        }
                      ],
                      "productAssociations": [
                        {
                          "productAssociationType": "COMPATIBLE",
                          "productIds": [
                            {
                              "productId": "string"
                            }
                          ]
                        }
                      ]
                    },
                    "componentType": "PRIMARY",
                    "isMandatory": true,
                    "isDefault": 0,
                    "displayOrder": 1
                  }
                ],
                "contract": {
                  "contractTerm": 24,
                  "isPriceLock": true,
                  "priceLockDuration": 24,
                  "etf": 0,
                  "currencyCode": "USD"
                },
                "validFor": {
                  "salesStartDateTime": "2018-06-29T11:50:08.692Z",
                  "salesEndDateTime": "2018-06-29T11:50:08.692Z"
                },
                "additionalUiAttrOffer": [
                  {
                    "name": "string",
                    "value": "string"
                  }
                ],
                "associatedOffers": [
                  {
                    "associatedOfferCategory": "VIDEO-PRISM",
                    "associationType": [
                      {
                        "associationType": "BUNDLEITEM",
                        "selectionRule": "ANY",
                        "associatedOfferIds": [
                          {
                            "displayOrder": 1,
                            "associatedOfferId": "840776ab-8785-4746-94ec-5edccbPRISM1",
                            "discount": {
                              "discountId": "B1",
                              "discountDescription": "HSI with PRISM1",
                              "discountAmount": 4.99
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              },
              "defaultOfferPrice": {
                "rc": 39.99,
                "otc": 69.99,
                "discountedRc": 29.99,
                "discountedOtc": 49.99
              },
              "isDefault": 0,
              "displayOrder": 1
            }
          ]
        }
      ]
    }
  ],
  "cart": {
    "catalogSpecId": "b982b278-cbf8-435c-9695-576b1a3b3378",
    "customerOrderItems": [
      {
        "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
        "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
        "offerName": {},
        "offerType": "BUNDLE",
        "offerSubType": "REGULAR",
        "offerCategory": "INTERNET",
        "contractTerm": 24,
        "quantity": 1,
        "action": "ADD",
        "contractStartDate": "2018-06-29T11:50:08.692Z",
        "rc": 39.99,
        "otc": 69.99,
        "discountedRc": 29.99,
        "discountedOtc": 49.99,
        "customerOrderSubItems": [
          {
            "productId": 101,
            "productName": "HSI 20128 Kbps/5128 Kbps",
            "productType": "INTERNET",
            "componentType": "PRIMARY",
            "productCategory": "CORE",
            "quantity": 1,
            "action": "ADD",
            "provisioningAction": "PROVISIONnBILL",
            "productAttributes": [
              {
                "compositeAttribute": [
                  {
                    "attributeName": "downSpeed",
                    "attributeValue": 20128,
                    "uom": "Kbps"
                  }
                ],
                "isDefault": 0,
                "displayOrder": 1,
                "isPriceable": true,
                "prices": [
                  {
                    "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                    "priceType": "SUBSCRIPTION",
                    "priceTypeDescription": "string",
                    "rc": 39.99,
                    "otc": 69.99,
                    "discountedRc": 29.99,
                    "discountedOtc": 49.99,
                    "frequency": "PERMONTH",
                    "currencyCode": "USD",
                    "provisioningAction": "PROVISIONnBILL"
                  }
                ],
                "discounts": [
                  {
                    "autoAttachInd": "Y",
                    "discountId": "DC1",
                    "discountDescription": "Discount Description DC1",
                    "discountRate": 10,
                    "discountMethod": "FLATAMOUNT",
                    "discountLevel": "P",
                    "discountDuration": 1,
                    "discountType": "P",
                    "discountCategory": "RCD",
                    "discountMaxAmount": 10,
                    "discountMinimumAmount": 5,
                    "discountIdSequence": 1,
                    "discountRule": "ANY"
                  }
                ]
              }
            ],
            "productAssociations": [
              {
                "productAssociationType": "COMPATIBLE",
                "productIds": [
                  {
                    "productId": "string"
                  }
                ]
              }
            ]
          }
        ]
```
Error Response
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}

```

| API            | /getOfferSummary                           |
|:---------------|:-------------------------------------------|
| Error Code     | 400                                        |
| Error Message  | Invalid status value; returns Error object |
| Name           | Value                                      |
| HTTP Method    | GET                                        |
| Base URI       | /bsi/OfferSummaryBusinessService/v1        |
| URI Syntax     |                                            |
| Operation Name | /getAddOnOffers                            |

    API: /getAddOnOffers

Request
========
```sh
{
  "orderReferenceNumber": "ORN-20170808100628481",
  "catalogSpecId": "b982b278-cbf8-435c-9695-576b1a3b3378",
  "customerOrderItems": [
    {
      "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
      "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
      "offerName": {},
      "offerType": "BUNDLE",
      "offerSubType": "REGULAR",
      "offerCategory": "INTERNET",
      "contractTerm": 24,
      "quantity": 1,
      "action": "ADD",
      "contractStartDate": "2018-07-02T08:31:22.867Z",
      "rc": 39.99,
      "otc": 69.99,
      "discountedRc": 29.99,
      "discountedOtc": 49.99,
      "customerOrderSubItems": [
        {
          "productId": 101,
          "productName": "HSI 20128 Kbps/5128 Kbps",
          "productType": "INTERNET",
          "componentType": "PRIMARY",
          "productCategory": "CORE",
          "quantity": 1,
          "action": "ADD",
          "provisioningAction": "PROVISIONnBILL",
          "productAttributes": [
            {
              "compositeAttribute": [
                {
                  "attributeName": "downSpeed",
                  "attributeValue": 20128,
                  "uom": "Kbps"
                }
              ],
              "isDefault": 0,
              "displayOrder": 1,
              "isPriceable": true,
              "prices": [
                {
                  "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                  "priceType": "SUBSCRIPTION",
                  "priceTypeDescription": "string",
                  "rc": 39.99,
                  "otc": 69.99,
                  "discountedRc": 29.99,
                  "discountedOtc": 49.99,
                  "frequency": "PERMONTH",
                  "currencyCode": "USD",
                  "provisioningAction": "PROVISIONnBILL"
                }
              ],
              "discounts": [
                {
                  "autoAttachInd": "Y",
                  "discountId": "DC1",
                  "discountDescription": "Discount Description DC1",
                  "discountRate": 10,
                  "discountMethod": "FLATAMOUNT",
                  "discountLevel": "P",
                  "discountDuration": 1,
                  "discountType": "P",
                  "discountCategory": "RCD",
                  "discountMaxAmount": 10,
                  "discountMinimumAmount": 5,
                  "discountIdSequence": 1,
                  "discountRule": "ANY"
                }
              ]
            }
          ],
          "productAssociations": [
            {
              "productAssociationType": "COMPATIBLE",
              "productIds": [
                {
                  "productId": "string"
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```

Response
==========
```sh
{
  "catalogSpecId": "b982b278",
  "addOnOffers": [
    {
      "serviceCategory": "DATA",
      "offerDataLink": "{RandomUniqueIdentifier}/productOfferings/DATA",
      "catalogs": [
        {
          "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
          "catalogName": "Catalog Spec HSI",
          "catalogType": "US West Residential Internet",
          "catalogItems": [
            {
              "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
              "productOffer": {
                "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
                "offerName": "HSI Upto 20 Mbps Downstream/5 Mbps Upstream",
                "offerDisplayName": "20M/5M",
                "offerDescription": "string",
                "offerType": "BUNDLE",
                "offerSubType": "REGULAR",
                "offerCategory": "INTERNET",
                "offerAttributes": [
                  {
                    "attributeName": "name",
                    "attributeValue": "value"
                  }
                ],
                "productComponents": [
                  {
                    "product": {
                      "productId": 101,
                      "productName": "HSI 20128 Kbps/5128 Kbps",
                      "productDisplayName": "20M/5M",
                      "productType": "INTERNET",
                      "productCategory": "CORE",
                      "isRegulated": false,
                      "quantity": {
                        "minQuantity": 1,
                        "maxQuantity": 1,
                        "defaultQuantity": 1
                      },
                      "productAttributes": [
                        {
                          "compositeAttribute": [
                            {
                              "attributeName": "downSpeed",
                              "attributeValue": 20128,
                              "uom": "Kbps",
                              "attributeDisplayName": "string"
                            }
                          ],
                          "isDefault": 0,
                          "displayOrder": 1,
                          "isPriceable": true,
                          "prices": [
                            {
                              "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                              "priceType": "SUBSCRIPTION",
                              "priceTypeDescription": "string",
                              "rc": 39.99,
                              "otc": 69.99,
                              "discountedRc": 29.99,
                              "discountedOtc": 49.99,
                              "frequency": "PERMONTH",
                              "currencyCode": "USD",
                              "provisioningAction": "PROVISIONnBILL"
                            }
                          ],
                          "discounts": [
                            {
                              "autoAttachInd": "Y",
                              "discountId": "DC1",
                              "discountDescription": "Discount Description DC1",
                              "discountRate": 10,
                              "discountMethod": "FLATAMOUNT",
                              "discountLevel": "P",
                              "discountDuration": 1,
                              "discountType": "P",
                              "discountCategory": "RCD",
                              "discountMaxAmount": 10,
                              "discountMinimumAmount": 5,
                              "discountIdSequence": 1,
                              "discountRule": "ANY"
                            }
                          ]
                        }
                      ],
                      "additionalUiAttrProduct": [
                        {
                          "name": "string",
                          "value": "string"
                        }
                      ],
                      "productAssociations": [
                        {
                          "productAssociationType": "COMPATIBLE",
                          "productIds": [
                            {
                              "productId": "string"
                            }
                          ]
                        }
                      ]
                    },
                    "componentType": "PRIMARY",
                    "isMandatory": true,
                    "isDefault": 0,
                    "displayOrder": 1
                  }
                ],
                "contract": {
                  "contractTerm": 24,
                  "isPriceLock": true,
                  "priceLockDuration": 24,
                  "etf": 0,
                  "currencyCode": "USD"
                },
                "validFor": {
                  "salesStartDateTime": "2018-07-02T08:32:07.273Z",
                  "salesEndDateTime": "2018-07-02T08:32:07.273Z"
                },
                "additionalUiAttrOffer": [
                  {
                    "name": "string",
                    "value": "string"
                  }
                ],
                "associatedOffers": [
                  {
                    "associatedOfferCategory": "VIDEO-PRISM",
                    "associationType": [
                      {
                        "associationType": "BUNDLEITEM",
                        "selectionRule": "ANY",
                        "associatedOfferIds": [
                          {
                            "displayOrder": 1,
                            "associatedOfferId": "840776ab-8785-4746-94ec-5edccbPRISM1",
                            "discount": {
                              "discountId": "B1",
                              "discountDescription": "HSI with PRISM1",
                              "discountAmount": 4.99
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              },
              "defaultOfferPrice": {
                "rc": 39.99,
                "otc": 69.99,
                "discountedRc": 29.99,
                "discountedOtc": 49.99
              },
              "isDefault": 0,
              "displayOrder": 1
            }
          ]
        }
      ]
    }
  ],
  "cart": {
    "catalogSpecId": "b982b278-cbf8-435c-9695-576b1a3b3378",
    "customerOrderItems": [
      {
        "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
        "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
        "offerName": {},
        "offerType": "BUNDLE",
        "offerSubType": "REGULAR",
        "offerCategory": "INTERNET",
        "contractTerm": 24,
        "quantity": 1,
        "action": "ADD",
        "contractStartDate": "2018-07-02T08:32:07.273Z",
        "rc": 39.99,
        "otc": 69.99,
        "discountedRc": 29.99,
        "discountedOtc": 49.99,
        "customerOrderSubItems": [
          {
            "productId": 101,
            "productName": "HSI 20128 Kbps/5128 Kbps",
            "productType": "INTERNET",
            "componentType": "PRIMARY",
            "productCategory": "CORE",
            "quantity": 1,
            "action": "ADD",
            "provisioningAction": "PROVISIONnBILL",
            "productAttributes": [
              {
                "compositeAttribute": [
                  {
                    "attributeName": "downSpeed",
                    "attributeValue": 20128,
                    "uom": "Kbps"
                  }
                ],
                "isDefault": 0,
                "displayOrder": 1,
                "isPriceable": true,
                "prices": [
                  {
                    "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                    "priceType": "SUBSCRIPTION",
                    "priceTypeDescription": "string",
                    "rc": 39.99,
                    "otc": 69.99,
                    "discountedRc": 29.99,
                    "discountedOtc": 49.99,
                    "frequency": "PERMONTH",
                    "currencyCode": "USD",
                    "provisioningAction": "PROVISIONnBILL"
                  }
                ],
                "discounts": [
                  {
                    "autoAttachInd": "Y",
                    "discountId": "DC1",
                    "discountDescription": "Discount Description DC1",
                    "discountRate": 10,
                    "discountMethod": "FLATAMOUNT",
                    "discountLevel": "P",
                    "discountDuration": 1,
                    "discountType": "P",
                    "discountCategory": "RCD",
                    "discountMaxAmount": 10,
                    "discountMinimumAmount": 5,
                    "discountIdSequence": 1,
                    "discountRule": "ANY"
                  }
                ]
              }
            ],
            "productAssociations": [
              {
                "productAssociationType": "COMPATIBLE",
                "productIds": [
                  {
                    "productId": "string"
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
}
```
Error Response
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}

```

[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [vx.x.x.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>
   
