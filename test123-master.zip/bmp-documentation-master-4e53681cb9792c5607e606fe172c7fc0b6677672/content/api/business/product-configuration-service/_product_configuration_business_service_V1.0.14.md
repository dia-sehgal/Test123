Product Configuration Service
=============================
    Version: 1.0.14

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /productConfigByCart](#Request)
- [Response /productConfigByCart](#Response)

Overview
--------

> **Product Configuration business service is used for new Product Configuration. This service provides operations for retrieving configurations for all the products. Operations include retrieving configuration by product and saving product configuration in the order document.**

![](media/ProductConfigurationDiagram.png)

### Request Syntax

For each resource, the following items are documented.

| Name           | Value           |
|:---------------|:----------------|
| HTTP Method    | POST            |
| Base URI       | /bsi/InitService/v1                                                                          |
| URI Syntax     | bmp-productconfiguration-business-service-ctltest1.pcfmrnctl.dev.intranet/bsi/InitService/v1 |
| Operation Name | /productConfigByCart                                                                         |

### Required Parameters


| Parameter             | Description  |
|:----------------------|:-------------|
|Each Request Attribute | Is mandatory |

Operation Details (Request/Response)
------------------------------------

    API: /productConfigByCart

Request 
=======
```sh
 {
  "addOnOffers": [
    {
      "serviceCategory": "DATA",
      "offerDataLink": "{RandomUniqueIdentifier}/productOfferings/DATA",
      "catalogs": [
        {
          "catalogId": 1051302,
          "catalogName": "Catalog CO CENTENNIAL DNVRCODC ESHOP-Customer Care Individual Regular",
          "catalogType": "US West Residential Internet",
          "catalogItems": [
            {
              "productOffer": {
                "productOfferingId": 12220,
                "offerName": "HSI Upto 12 Mbps/896 Kbps PURE",
                "offerDisplayName": "Price for Life High Speed Internet",
                "offerDescription": "string",
                "offerType": "P4L",
                "offerSubType": "REGULAR",
                "offerCategory": "INTERNET",
                "offerAttributes": [
                  {
                    "attributeName": "with-INTERNET",
                    "attributeValue": "YES"
                  },
                  {
                    "attributeName": "EN_OFFER_TYPE",
                    "attributeValue": "STANDALONE-BUNDLE"
                  }
                ],
                "productComponents": [
                  {
                    "product": {
                      "productId": 18869,
                      "productName": "HSI up to 12 Mbps/896 Kbps",
                      "productDisplayName": "HSI up to 12 Mbps/896 Kbps",
                      "productType": "INTERNET",
                      "productCategory": "CORE",
                      "quantity": {
                        "minQuantity": 1,
                        "maxQuantity": 1,
                        "defaultQuantity": 1
                      },
                      "additionalUiAttrProduct": [
                        {
                          "name": "string",
                          "value": "string"
                        }
                      ],
                      "productAttributes": [
                        {
                          "compositeAttribute": [
                            {
                              "attributeName": "downSpeed",
                              "attributeValue": 20128,
                              "uom": "Kbps"
                            }
                          ],
                          "isDefault": 0,
                          "displayOrder": 1,
                          "isPriceable": true,
                          "prices": [
                            {
                              "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                              "priceType": "SUBSCRIPTION",
                              "priceTypeDescription": "string",
                              "rc": 39.99,
                              "otc": 69.99,
                              "discountedRc": 29.99,
                              "discountedOtc": 49.99,
                              "frequency": "PERMONTH",
                              "currencyCode": "USD",
                              "provisioningAction": "PROVISIONnBILL"
                            }
                          ],
                          "discounts": [
                            {
                              "autoAttachInd": "Y",
                              "discountId": "DC1",
                              "discountDescription": "Discount Description DC1",
                              "discountRate": 10,
                              "discountMethod": "FLATAMOUNT",
                              "discountLevel": "P",
                              "discountDuration": 1,
                              "discountType": "P",
                              "discountCategory": "RCD",
                              "discountMaxAmount": 10,
                              "discountMinimumAmount": 5,
                              "discountIdSequence": 1,
                              "discountRule": "ANY"
                            }
                          ]
                        }
                      ],
                      "isRegulated": false
                    },
                    "componentType": "PRIMARY",
                    "isMandatory": true,
                    "isDefault": 0,
                    "displayOrder": 1
                  }
                ],
                "associatedOffers": [
                  {
                    "associatedOfferCategory": "INTERNET",
                    "associationType": [
                      {
                        "associationType": "ADDON",
                        "selectionRule": "ANY",
                        "associatedOfferIds": [
                          {
                            "displayOrder": 0,
                            "associatedOfferId": 12195,
                            "discount": {
                              "discountId": "B1",
                              "discountDescription": "HSI with PRISM1",
                              "discountAmount": 4.9
                            }
                          }
                        ]
                      }
                    ]
                  }
                ],
                "contract": {
                  "contractTerm": 0,
                  "isPriceLock": false,
                  "priceLockDuration": 0,
                  "etf": 0,
                  "currencyCode": null
                },
                "validFor": {
                  "salesStartDateTime": "2018-07-18T10:55:47.775Z",
                  "salesEndDateTime": "2018-07-18T10:55:47.775Z"
                },
                "additionalUiAttrOffer": [
                  {
                    "name": "string",
                    "value": "string"
                  }
                ]
              },
              "defaultOfferPrice": {
                "rc": 45,
                "otc": 0,
                "discountedRc": 45,
                "discountedOtc": 0
              },
              "productOfferingId": 12220,
              "displayOrder": 90,
              "isDefault": 0
            }
          ]
        }
      ]
    }
  ],
  "cart": {
    "catalogSpecId": 1050799,
    "customerOrderItems": [
      {
        "action": "NOCHANGE",
        "catalogId": 1051302,
        "contractTerm": 0,
        "customerOrderSubItems": [
          {
            "productId": 18880,
            "productName": "HSI Upto 40 Mbps/5 Mbps",
            "productType": "INTERNET",
            "componentType": "PRIMARY",
            "productCategory": "CORE",
            "quantity": 1,
            "action": "CHANGE",
            "provisioningAction": "PROVISIONnBILL",
            "productAttributes": [
              {
                "compositeAttribute": [
                  {
                    "attributeName": "downSpeed",
                    "attributeValue": 20128,
                    "uom": "Kbps"
                  }
                ],
                "isDefault": 0,
                "displayOrder": 1,
                "isPriceable": true,
                "prices": [
                  {
                    "priceKey": "840776ab-8785-4746-94ec-5edccb034381",
                    "priceType": "SUBSCRIPTION",
                    "priceTypeDescription": "string",
                    "rc": 39.99,
                    "otc": 69.99,
                    "discountedRc": 29.99,
                    "discountedOtc": 49.99,
                    "frequency": "PERMONTH",
                    "currencyCode": "USD",
                    "provisioningAction": "PROVISIONnBILL"
                  }
                ],
                "discounts": [
                  {
                    "autoAttachInd": "Y",
                    "discountId": "DC1",
                    "discountDescription": "Discount Description DC1",
                    "discountRate": 10,
                    "discountMethod": "FLATAMOUNT",
                    "discountLevel": "P",
                    "discountDuration": 1,
                    "discountType": "P",
                    "discountCategory": "RCD",
                    "discountMaxAmount": 10,
                    "discountMinimumAmount": 5,
                    "discountIdSequence": 1,
                    "discountRule": "ANY"
                  }
                ]
              }
            ],
            "productAssociations": [
              {
                "productAssociationType": "DEPENDSON",
                "productIds": [
                  {
                    "productId": "string"
                  }
                ]
              }
            ]
          }
        ],
        "discountedOtc": 0,
        "discountedRc": 55,
        "offerCategory": "INTERNET",
        "offerSubType": "REGULAR",
        "offerType": "P4L",
        "otc": 0,
        "productOfferingId": 12208,
        "quantity": 1,
        "rc": 55,
        "contractStartDate": null,
        "offerName": null
      }
    ]
  }
}
```                                          

Response 
=========
```sh
{
  "productConfiguration": [
    {
      "productType": "INTERNET",
      "configItems": [
        {
          "productId": "string",
          "productName": "string",
          "prodSelectionRule": [
            {
              "name": "Service Level",
              "value": "Standard",
              "type": "productAttribute",
              "action": "SELECT"
            }
          ],
          "configDetails": [
            {
              "isConfigRequired": true,
              "formName": "string",
              "nextOrderAction": "NORPT",
              "macdReq": "string",
              "formSelectionRule": [
                {
                  "name": "Service Level",
                  "value": "Standard",
                  "type": "productAttribute",
                  "action": "SELECT"
                }
              ],
              "formItems": [
                {
                  "attributeName": "string",
                  "attributeType": "string",
                  "isMandatory": true,
                  "attributeValue": [
                    {
                      "value": "string",
                      "isDefault": true
                    }
                  ],
                  "attrSelectionRule": [
                    {
                      "name": "Service Level",
                      "value": "Standard",
                      "type": "productAttribute",
                      "action": "SELECT"
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```

Error Response 
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```


| HTTP Status Code (BM) | BM Reason Code  | Message Text                    |
|:----------------------|:----------------|:--------------------------------|
| 400                   | INVALID_REQUEST | Expected request is not provided to the system. |


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>