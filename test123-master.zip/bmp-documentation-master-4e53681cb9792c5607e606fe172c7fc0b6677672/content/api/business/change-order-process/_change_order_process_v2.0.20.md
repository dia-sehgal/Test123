Order Process for Init Order Flow
=================================
    Version: 2.0.20

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /init](#Request)
- [Response /init](#Response)

Process Purpose
---------------

> **To capture and understand E2E order journey of a change order. The request and response of each operation indicates what has been sent from eSHOP to fulfill the change order journey via BM.**

![](media/ChangeOrderProcessDiagram.png)

### Process Scope 


This order process is implemented as part of change order journey.

### Process Input 


> All business processes have an input or a need to be fulfilled. This need or input is what triggers the process to begin. This section should identify the need or input required to initiate the process.

### Process Boundaries 


Change order process starts with init task, which initiates the change request. Service address will be sent to find out the offers available on the given serviceAddress.

Process Flow
------------

| Step\# | Client Tasks   | System Tasks   | Description   | API Operation           |
|:--------|:--------------|:---------------|:--------------|:------------------------|
| 1      | Init                   | init                  | This is a Request to initiate a CHANGE order on existing product.                                                                                                                                              | /init                   |
| 2      | getAddon               | Get Addon Offers      | Gets AddOn Offers                                                                                                                                                                                              | /getAddon               |
| 3      | checkoutsAndScheduling | Checkout & Scheduling | Gets the updated Cart (with addons added) along with TN and config Info                                                                                                                                        | /checkoutsAndScheduling |
| 4      | confirmScheduling      | Confirm Scheduling    | This task is used to call Appointment service to reserve a slot and open up the page for account management.                                                                                                   | /confirmScheduling      |
| 5      | creditReview           | Credit Review         | This task is used for showing account/credit/deposit and past due information.                                                                                                                                 | /creditReview           |
| 6      | payment                | Payments              | For Deposit required scenarios, the UI will render the payment related information/installments as provided and once payment is done (e.g. For Deposits/past Bills Due), it will send the payment information. | /payment                |
| 7      | Response from EsHOP    | Submit Order          | This operation is to store additional info captured on order summary page during ordering journey and submit the order.                                                                                        | /submitOrder            |

Process Output
--------------

> All business processes have an output or result that they must achieve. This is directly tied to the process purpose. While the output may not necessarily be a formal part of the process itself—depending on where the boundary is established—it is an integral part of the document as it explains what it expected upon completion of the process. This section should provide an explanation of the process’s output.

| **Name**       | **Value**              |
|:---------------|:-----------------------|
| HTTP Method    | POST                   |
| Base URI       | /v1/orderprocess/order |
| URI Syntax     |                        |
| Operation Name | /init                  |

Operation Details (Request/Response)
------------------------------------

    API: /init

Request
--------

XXXXXXXXX

Response
========
```sh
{
  "success": true,
  "orderRefNumber": "ORN-20170808100628481",
  "processInstanceId": 58649,
  "taskId": 58669,
  "taskName": "Get Addon Offers",
  "payload": {
    "catalogSpecId": 1050799,
    "offers": [
      {
        "serviceCategory": "DATA",
        "offerDataLink": "{RandomUniqueIdentifier}/productOfferings/DATA",
        "catalogs": [
          {
            "catalogId": 1051302,
            "catalogName": "Catalog CO CENTENNIAL DNVRCODC ESHOP-Customer Care Individual Regular",
            "catalogType": "US West Residential Internet",
            "catalogItems": [
              {
                "productOffer": {
                  "productOfferingId": 12220,
                  "offerName": "HSI Upto 12 Mbps/896 Kbps PURE",
                  "offerDisplayName": "Price for Life High Speed Internet",
                  "offerDescription": "string",
                  "offerType": "P4L",
                  "offerSubType": "REGULAR",
                  "offerCategory": "INTERNET",
                  "offerAttributes": [
                    {
                      "attributeName": "with-INTERNET",
                      "attributeValue": "YES"
                    },
                    {
                      "attributeName": "EN_OFFER_TYPE",
                      "attributeValue": "STANDALONE-BUNDLE"
                    }
                  ],
                  "productComponents": [
                    {
                      "product": {
                        "productId": 18869,
                        "productName": "HSI up to 12 Mbps/896 Kbps",
                        "productDisplayName": "HSI up to 12 Mbps/896 Kbps",
                        "productType": "INTERNET",
                        "productCategory": "CORE",
                        "quantity": {
                          "minQuantity": 1,
                          "maxQuantity": 1,
                          "defaultQuantity": 1
                        },
                        "additionalUiAttrProduct": [
                          {
                            "name": "string",
                            "value": "string"
                          }
                        ],
                        "productAttributes": [
                          {
                            "compositeAttribute": [
                              {
                                "attributeName": "Sub Service Group",
                                "attributeValue": "SRV",
                                "uom": "NA",
                                "attributeDisplayName": "string"
                              }
                            ],
                            "displayOrder": 0,
                            "isPriceable": false,
                            "prices": [
                              {
                                "priceKey": "string",
                                "priceType": "SUBSCRIPTION",
                                "priceTypeDescription": "string",
                                "rc": 39.99,
                                "otc": 69.99,
                                "discountedRc": 29.99,
                                "discountedOtc": 49.99,
                                "frequency": "PERMONTH",
                                "currencyCode": "USD",
                                "provisioningAction": "PROVISIONnBILL"
                              }
                            ],
                            "discounts": [
                              {
                                "autoAttachInd": "Y",
                                "discountId": "DC1",
                                "discountDescription": "Discount Description DC1",
                                "discountRate": 10,
                                "discountMethod": "FLATAMOUNT",
                                "discountLevel": "P",
                                "discountDuration": 1,
                                "discountType": "P",
                                "discountCategory": "RCD",
                                "discountMaxAmount": 10,
                                "discountMinimumAmount": 5,
                                "discountIdSequence": 2,
                                "discountRule": "ANY"
                              }
                            ],
                            "isDefault": 0
                          }
                        ],
                        "isRegulated": false
                      },
                      "componentType": "PRIMARY",
                      "isMandatory": true,
                      "isDefault": 0,
                      "displayOrder": 1
                    }
                  ],
                  "associatedOffers": [
                    {
                      "associatedOfferCategory": "INTERNET",
                      "associationType": [
                        {
                          "associationType": "ADDON",
                          "selectionRule": "ANY",
                          "associatedOfferIds": [
                            {
                              "displayOrder": 0,
                              "associatedOfferId": 12195,
                              "discount": {
                                "discountId": "B1",
                                "discountDescription": "HSI with PRISM1",
                                "discountAmount": 4.99
                              }
                            }
                          ]
                        }
                      ]
                    }
                  ],
                  "contract": {
                    "contractTerm": 0,
                    "isPriceLock": false,
                    "priceLockDuration": 0,
                    "etf": 0,
                    "currencyCode": null
                  },
                  "validFor": {
                    "salesStartDateTime": "2018-07-05T06:38:16.837Z",
                    "salesEndDateTime": "2018-07-05T06:38:16.837Z"
                  },
                  "additionalUiAttrOffer": [
                    {
                      "name": "string",
                      "value": "string"
                    }
                  ]
                },
                "defaultOfferPrice": {
                  "rc": 45,
                  "otc": 0,
                  "discountedRc": 45,
                  "discountedOtc": 0
                },
                "productOfferingId": 12220,
                "displayOrder": 90,
                "isDefault": 0
              }
            ]
          }
        ]
      }
    ],
    "cart": {
      "catalogSpecId": 1050799,
      "customerOrderItems": [
        {
          "action": "NOCHANGE",
          "catalogId": 1051302,
          "contractTerm": 0,
          "customerOrderSubItems": [
            {
              "productId": 18880,
              "productName": "HSI Upto 40 Mbps/5 Mbps",
              "productType": "INTERNET",
              "componentType": "PRIMARY",
              "productCategory": "CORE",
              "quantity": 1,
              "action": "CHANGE",
              "provisioningAction": "PROVISIONnBILL",
              "productAttributes": [
                {
                  "compositeAttribute": [
                    {
                      "attributeName": "downSpeed",
                      "attributeValue": 20128,
                      "uom": "Kbps"
                    }
                  ],
                  "isDefault": 0,
                  "displayOrder": 1,
                  "isPriceable": true,
                  "prices": [
                    {
                      "priceKey": "string",
                      "priceType": "SUBSCRIPTION",
                      "priceTypeDescription": "string",
                      "rc": 39.99,
                      "otc": 69.99,
                      "discountedRc": 29.99,
                      "discountedOtc": 49.99,
                      "frequency": "PERMONTH",
                      "currencyCode": "USD",
                      "provisioningAction": "PROVISIONnBILL"
                    }
                  ],
                  "discounts": [
                    {
                      "autoAttachInd": "Y",
                      "discountId": "DC1",
                      "discountDescription": "Discount Description DC1",
                      "discountRate": 10,
                      "discountMethod": "FLATAMOUNT",
                      "discountLevel": "P",
                      "discountDuration": 1,
                      "discountType": "P",
                      "discountCategory": "RCD",
                      "discountMaxAmount": 10,
                      "discountMinimumAmount": 5,
                      "discountIdSequence": 2,
                      "discountRule": "ANY"
                    }
                  ]
                }
              ],
              "productAssociations": [
                {
                  "productAssociationType": "DEPENDSON",
                  "productIds": [
                    {
                      "productId": "string"
                    }
                  ]
                }
              ]
            }
          ],
          "discountedOtc": 0,
          "discountedRc": 55,
          "offerCategory": "INTERNET",
          "offerSubType": "REGULAR",
          "offerType": "P4L",
          "otc": 0,
          "productOfferingId": 12208,
          "quantity": 1,
          "rc": 55,
          "contractStartDate": null,
          "offerName": null
        }
      ]
    },
    "productConfiguration": [
      {
        "productType": "INTERNET",
        "configItems": [
          {
            "productId": "string",
            "productName": "string",
            "prodSelectionRule": [
              {
                "name": "Service Level",
                "value": "Standard",
                "type": "productAttribute",
                "action": "SELECT"
              }
            ],
            "configDetails": [
              {
                "isConfigRequired": true,
                "formName": "string",
                "nextOrderAction": "NORPT",
                "formSelectionRule": [
                  {
                    "name": "Service Level",
                    "value": "Standard",
                    "type": "productAttribute",
                    "action": "SELECT"
                  }
                ],
                "formItems": [
                  {
                    "attributeName": "string",
                    "attributeType": "string",
                    "isMandatory": true,
                    "attributeValue": [
                      {
                        "value": "string",
                        "isDefault": true
                      }
                    ],
                    "attrSelectionRule": [
                      {
                        "name": "Service Level",
                        "value": "Standard",
                        "type": "productAttribute",
                        "action": "SELECT"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "existingServices": {
      "catalogSpecId": null,
      "existingServiceItems": [
        {
          "action": "NOCHANGE",
          "catalogId": 1051302,
          "contractTerm": 0,
          "customerOrderSubItems": [
            {
              "quantity": 1,
              "productId": 18880,
              "productName": "HSI Upto 40Mbps/5 Mbps",
              "action": "NOCHANGE",
              "productType": "INTERNET",
              "componentType": "PRIMARY",
              "productCategory": "CORE",
              "productAttributes": [
                {
                  "compositeAttribute": [
                    {
                      "attributeName": "downSpeed",
                      "attributeValue": 20128,
                      "uom": "Kbps"
                    }
                  ],
                  "isDefault": 0,
                  "displayOrder": 1,
                  "isPriceable": true,
                  "prices": [
                    {
                      "priceKey": "string",
                      "priceType": "SUBSCRIPTION",
                      "priceTypeDescription": "string",
                      "rc": 39.99,
                      "otc": 69.99,
                      "discountedRc": 29.99,
                      "discountedOtc": 49.99,
                      "frequency": "PERMONTH",
                      "currencyCode": "USD",
                      "provisioningAction": "PROVISIONnBILL"
                    }
                  ],
                  "discounts": [
                    {
                      "autoAttachInd": "Y",
                      "discountId": "DC1",
                      "discountDescription": "Discount Description DC1",
                      "discountRate": 10,
                      "discountMethod": "FLATAMOUNT",
                      "discountLevel": "P",
                      "discountDuration": 1,
                      "discountType": "P",
                      "discountCategory": "RCD",
                      "discountMaxAmount": 10,
                      "discountMinimumAmount": 5,
                      "discountIdSequence": 2,
                      "discountRule": "ANY"
                    }
                  ]
                }
              ],
              "provisioningAction": null
            }
          ],
          "discountedOtc": 0,
          "discountedRc": 0,
          "offerCategory": "DATA",
          "offerSubType": "REGULAR",
          "offerType": "P4L",
          "otc": 0,
          "productOfferingId": 12208,
          "quantity": 1,
          "rc": 55,
          "contractStartDate": null,
          "offerName": null
        }
      ]
    }
  }
}
```
Error Response
===============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

Exceptions to Normal Process Flow
---------------------------------

Error Response
==================
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "source": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss",
      "orderRefNumber": "ORN-20170808100628481"
    }
  ],
  "payload": {}
}
```

| HTTP Status Code (BM) | BM Reason Code                          | Message Text     |
|-----------------------|-----------------------------------------|-------------------|
| 503                   | ADDRESS_SERVER_UNAVAILABLE              | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | ORDERSUMMARY_SERVER_UNAVAILABLE         | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | SERVICEAVAILIBILITY_SERVER_UNAVAILABLE  | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | OFFERSUMMARY_SERVER_UNAVAILABLE         | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | PRODUCTCONFIGURATION_SERVER_UNAVAILABLE | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | DUEDATE_SERVER_UNAVAILABLE              | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | APPOINTMENT_SERVER_UNAVAILABLE          | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | ACCOUNTMANAGEMENT_SERVER_UNAVAILABLE    | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | DEPOSIT_SERVER_UNAVAILABLE              | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | CREDITCHECK_SERVER_UNAVAILABLE          | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | BILLESTIMATE_SERVER_UNAVAILABLE         | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | PAYMENT_SERVER_UNAVAILABLE              | The server cannot handle the request for a service due to temporary maintenance. |
| 503                   | OMPROCESS_SERVER_UNAVAILABLE            | The server cannot handle the request for a service due to temporary maintenance. |
| 500                   | BM_ORDER_CAPTURE_SERVER_ERROR           | Order Capture Process is unable to process this request at this time.            |
| 504                   | ADDRESS_SERVER_TIMEOUT                  | The server cannot handle the request and is timing out                           |
| 504                   | ORDERSUMMARY_SERVER_TIMEOUT             | The server cannot handle the request and is timing out.                          |
| 504                   | SERVICEAVAILIBILITY_SERVER_TIMEOUT      | The server cannot handle the request and is timing out.                          |
| 504                   | OFFERSUMMARY_SERVER_TIMEOUT             | The server cannot handle the request and is timing out.                          |
| 504                   | PRODUCTCONFIGURATION_SERVER_TIMEOUT     | The server cannot handle the request and is timing out.                          |
| 504                   | DUEDATE_SERVER_TIMEOUT                  | The server cannot handle the request and is timing out.                          |
| 504                   | APPOINTMENT_SERVER_TIMEOUT              | The server cannot handle the request and is timing out.                          |
| 504                   | ACCOUNTMANAGEMENT_SERVER_TIMEOUT        | The server cannot handle the request and is timing out.                          |
| 504                   | DEPOSIT_SERVER_TIMEOUT                  | The server cannot handle the request and is timing out.                          |


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>
   
