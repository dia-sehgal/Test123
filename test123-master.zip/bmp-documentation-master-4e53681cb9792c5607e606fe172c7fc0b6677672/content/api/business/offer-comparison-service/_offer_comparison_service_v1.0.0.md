Offer Comparison Service 
=========================
    Version: 1.0.0

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /getOfferDetails](#Request)
- [Response /getOfferDetails](#Response)

Overview
========

> **Offer Comparison business service is request to retrieve offers details.**

### getOfferDetails


### Request Syntax

For each resource, the following items are documented.

| Name           | Value            |
|:---------------|:-----------------|
| HTTP Method    | post             |
| Base URI       | /camunda/        |
| URI Syntax     |                  |
| Operation Name | /getOfferDetails |

### Required Attributes

| Name         | Value  |
|:-------------|:-------|
| OfferRequest | Object |
| featureCode  | String |
| pricePlan    | String |
| bundleCode   | String |

*Note: Attributes present in request are mandatory.*

Operation Details (Request/Response)
--------------------------------------

    API: /getOfferDetails

Request 
=======
```sh
{
  "featureCode": "string",
  "pricePlan": "string",
  "submarketCode": "string",
  "bundleCode": "string"
}
```

Response 
========
```sh
{
  "offers": [
    {
      "serviceCategory": "DATA",
      "offerDataLink": "{RandomUniqueIdentifier}/productOfferings/DATA",
      "catalogs": [
        {
          "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
          "catalogName": "Catalog Spec HSI",
          "catalogType": "US West Residential Internet",
          "catalogItems": [
            {
              "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
              "productOffer": {
                "productOfferingId": "840776ab-8785-4746-94ec-5edccb034389",
                "offerName": "HSI Upto 20 Mbps Downstream/5 Mbps Upstream",
                "offerDisplayName": "20M/5M",
                "offerType": "SUBOFFER",
                "offerSubType": "REGULAR",
                "offerCategory": "INTERNET",
                "offerAttributes": [
                  {
                    "attributeName": "name",
                    "attributeValue": "value"
                  }
                ],
                "selectionRule": [
                  {
                    "ruleType": "SERVICE",
                    "ruleName": "Offer Selection",
                    "ruleValue": "href",
                    "requestData": "string"
                  }
                ],
                "productComponents": [
                  {
                    "product": {
                      "productId": 101,
                      "productName": "HSI 20128 Kbps/5128 Kbps",
                      "productDisplayName": "20M/5M",
                      "productType": "INTERNET",
                      "productCategory": "CORE",
                      "isRegulated": false,
                      "quantity": {
                        "maxQuantity": 1,
                        "minQuantity": 1,
                        "defaultQuantity": 1
                      },
                      "productAttributes": [
                        {
                          "compositeAttribute": [
                            {
                              "attributeName": "downSpeed",
                              "attributeValue": 40128,
                              "uom": "Kbps"
                            }
                          ],
                          "isDefault": 0,
                          "displayOrder": 1,
                          "isPriceable": true,
                          "prices": [
                            {
                              "priceKey": "string",
                              "priceType": "SUBSCRIPTION",
                              "priceTypeDescription": "string",
                              "rc": 39.99,
                              "otc": 69.99,
                              "discountedRc": 29.99,
                              "discountedOtc": 49.99,
                              "frequency": "PERMONTH",
                              "currencyCode": "USD",
                              "provisioningAction": "PROVISIONnBILL"
                            }
                          ],
                          "discounts": [
                            {
                              "autoAttachInd": "Y",
                              "discountId": "DC1",
                              "discountDescription": "Discount Description DC1",
                              "discountRate": 10,
                              "discountMethod": "FLATAMOUNT",
                              "discountLevel": "P",
                              "discountDuration": 1,
                              "discountType": "P",
                              "discountCategory": "RCD",
                              "discountMaxAmount": 10,
                              "discountMinimumAmount": 5,
                              "discountIdSequence": 2,
                              "discountRule": "ANY"
                            }
                          ]
                        }
                      ]
                    },
                    "componentType": "PRIMARY",
                    "isMandatory": true,
                    "isDefault": 0,
                    "displayOrder": 1
                  }
                ],
                "contract": {
                  "contractTerm": 24,
                  "isPriceLock": true,
                  "priceLockDuration": 24,
                  "etf": 0,
                  "currencyCode": "USD"
                },
                "validFor": {
                  "salesStartDateTime": "2018-07-12T10:41:01.526Z",
                  "salesEndDateTime": "2018-07-12T10:41:01.526Z"
                },
                "associatedOffers": [
                  {
                    "associatedOfferCategory": "VIDEO-PRISM",
                    "associationType": [
                      {
                        "associationType": "BUNDLEITEM",
                        "selectionRule": [
                          {
                            "ruleType": "SERVICE",
                            "ruleName": "Offer Selection",
                            "ruleValue": "href",
                            "requestData": "string"
                          }
                        ],
                        "associatedOfferIds": [
                          {
                            "displayOrder": 1,
                            "associatedOfferId": "840776ab-8785-4746-94ec-5edccbPRISM1",
                            "discount": {
                              "discountId": "B1",
                              "discountDescription": "HSI with PRISM1",
                              "discountAmount": 4.99
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              },
              "defaultOfferPrice": {
                "rc": 0,
                "otc": 0,
                "discountedRc": 0,
                "discountedOtc": 0
              },
              "isDefault": 0,
              "displayOrder": 1
            }
          ]
        }
      ]
    }
  ]
}
```

Error Response 
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

| API           | /getOfferDetails |
|:--------------|:-----------------|
| Error Code    | 400              |
| Error Message | Error            |


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>