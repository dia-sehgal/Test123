---
title: "Credit Check"
date: 2018-06-24T09:51:24-07:00
draft: false
---


Credit Check Business Service is used to check customer credit history.BM service will call cxgcreditcheck.uri and fetch the customer history and populate in response based on the credit history deposit will be applicable.

## Sections
* [Resources/Operations](#resources-operations)
* [Swagger Specification](#swagger-specification)
* [Authentication Details](#authentication-details)
* [MAL/Cloud Org](#mal-cloud-org)
* [Dependencies](#dependencies)
  - [MongoDB](#mongodb)
  - [PCF Services](#pcf-services)
  - [Processes Using](#processes-using)
  - [Downstream Services](#downstream-services)
* [Developer Installation](#developer-installation)
* [Setup](#setup)
* [CI/CD Pipeline Details](#ci-cd-pipeline-details)
* [Cloud Environment Details](#cloud-environment-details)
* [Splunk Dashboard](#splunk-dashboard)

## Resources/Operations  
  i) **/bsi/creditcheck/risk/creditDecision** - This API performs Credit Check from Equifax and returns final bill amount and credit risk information.
  	   
 ii) **/bsi/creditcheck/risk/refreshDecision** - This API refreshes CPWEB with final bill information.
     
 iii) **/bsi/creditcheck/risk/updateFinalBillInfo** - This API updates CPWEB with final bill information.

 iv) **/bsi/creditcheck/risk/v1/getAPIInfo** - This API fetches API Information.

## Swagger Specification
{{< oai-spec url="https://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/files/api-docs.json" >}}


# Installation :
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
    - Visit [Oracle] website to get the Oracle JDBC driver - ojdbc6.jar or ojdbc7.jar
    - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar

# SetUp : 
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/creditcheck-business-service.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run
```

# Dependent systems :
   TBD
   
# CI/CD Pipeline Details :
* Name:	 bmp-creditcheck-business-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000

* Sonarqube Project URL:	 TBD

* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 https://ne1itcprhas62.ne1.savvis.net/BMP_DEV/creditcheck-business-service/blob/release/final/Jenkinsfile

# Cloud Environment Details
* Cloud Group Name:	 BMCO-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-creditcheck-business-service-test3.pcfmrnctl.dev.intranet

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/

# Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards

# Swagger URL :
```sh
https://bmp-creditcheck-business-service-test3.pcfmrnctl.dev.intranet/
```
# Sample Request for Post(submit Address for validation):
```sh
{
  "customerAddress": {
    "addressId": "",
    "city": "PAPILLION",
    "geoAddressId": "200005657",
    "geoPoint": [
      {
        "accuracy": "1",
        "coordinateLevel": "1",
        "latitude": 41.137394,
        "longitude": -96.036615,
        "source": "Trillium"
      }
    ],
    "locality": "PAPILLION",
    "locationAttributes": {
      "cala": "NE",
      "isMdu": false,
      "legacyProvider": "QWEST COMMUNICATIONS",
      "mdu": true,
      "npa": "402",
      "nxx": "331",
      "rateCenter": "OMAHA",
      "tarCode": "NE7703",
      "tta": "331",
      "wirecenter": "OMAHNE84"
    },
    "postCode": "68046",
    "postCodeSuffix": "",
    "postcode": "68046",
    "source": "LFACS",
    "sourceId": "OMAHNE841F7KF.Q",
    "stateOrProvince": "NE",
    "streetAddress": "611 FENWICK DR",
    "streetName": "FENWICK DR",
    "streetNrFirst": "611",
    "streetNrLast": "",
    "streetNrLastSuffix": "",
    "streetNrSuffix": "",
    "streetType": "",
    "subAddress": {
      "combinedDesignator": "",
      "elements": [
        {
          "designator": "",
          "value": ""
        }
      ],
      "geoSubAddressId": "",
      "source": "",
      "sourceId": ""
    },
    "timeZone": {
      "ianaName": "America/Chicago",
      "isDaylightSavingsTime": true,
      "name": "Central Standard Time",
      "offset": "-5"
    }
  },
  "individual": {
    "creditCheck": true,
    "customerAccountId": null,
    "dateOfBirth": "1987-07-02",
    "driversLicenseIdentification": {
      "expirationDate": null,
      "issuingState": null,
      "licenseNr": null
    },
    "email": "srikanta.dash@centurylink.com",
    "familyNames": "Ahmer",
    "givenNames": "James",
    "middleNames": "",
    "phone": "9699837337",
    "socialSecurityNr": "666150907"
  }
}
```

# Sample Response :
```sh
{
   "creditApplicationRefNumber": "01000003721717",
   "creditReportId": "01000003721717",
   "creditClass": "1",
   "finalBillInd": false,
   "finalBillInfo": null
}
```