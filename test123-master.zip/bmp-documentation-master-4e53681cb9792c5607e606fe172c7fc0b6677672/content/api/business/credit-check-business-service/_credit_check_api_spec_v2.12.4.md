Credit Check Business Service 
==============================
    Version: 2.12.4

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
|Bill Estimates|[v3.12.3.md]|
| Credit Check|[v2.12.0.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /creditcheck/risk/creditDecision](#Request)
- [Response /creditcheck/risk/creditDecision](#Response)

Overview
--------

> **Credit Check business service is used to check customer credit history.BM service will call cxgcreditcheck.uri and fetch the customer history and populate in response based on the credit history deposit will be applicable.**

![](media/00dd6b76f321f64e6da49e73da2607e2.png)

Request Syntax
--------------

For each resource, the following items are documented.

| Name           | Value               |
|:---------------|:--------------------|
| HTTP Method    | POST                |
| Base URI       | /bsi/creditcheck/risk |
| URI Syntax     | https://bmp-creditcheck-business-service-test3.pcfmrnctl.dev.intranet/bsi/creditcheck/risk/creditDecision |
| Operation Name | /creditDecision     |

Required parameters:
--------------------

| Parameter        | Description                            |
|:-----------------|:---------------------------------------|
| familyNames      | Surname or familynameof the customer   |
| givenNames       | Name of the customer                   |
| socialSecurityNr | Social Security Number of the customer |
| dateOfBirth      | Date of Birth of the customer          |
| email            | Email ID of the customer               |
| customerAddress  | Address details of the customer        |

Operation details (Request/Response)
------------------------------------

    API: /creditcheck/risk/creditDecision

### Request and Response Formats

Request
=======
```sh
{
  "individual": {
    "creditCheck": true,
    "familyNames": "Undine",
    "givenNames": "Jason",
    "socialSecurityNr": 666489832,
    "driversLicenseIdentification": {
      "licenseNr": "string",
      "issuingState": "string",
      "expirationDate": "string"
    },
    "customerAccountId": "string",
    "middleNames": "string",
    "phone": 8175656236,
    "email": "jason.undine@aol.com",
    "dateOfBirth": "1978-10-31T07:00:00.000Z"
  },
  "customerAddress": {
    "addressId": "CLSPCOMA16ACF",
    "city": "COLORADO SPRINGS",
    "country": "USA",
    "geoAddressId": "string",
    "geoPoint": [
      {
        "source": "Trillium",
        "latitude": 38.84703,
        "longitude": -104.814561,
        "coordinateLevel": 1,
        "accuracy": 1
      }
    ],
    "locality": "COLORADO SPRINGS",
    "locationAttributes": {
      "isMdu": true,
      "legacyProvider": "QWEST COMMUNICATIONS",
      "rateCenter": "COLORDOSPG",
      "npa": 318,
      "nxx": 340,
      "wirecenter": "CLSPCOMA",
      "cala": "SCO",
      "tarCode": "NV0200",
      "tta": 471
    },
    "postCode": 80903,
    "postCodeSuffix": 2385,
    "sourceId": "string",
    "source": "LFACS",
    "stateOrProvince": "CO",
    "streetAddress": "918 N ROYER ST",
    "streetName": "ROYER",
    "streetNrFirst": 918,
    "streetNrFirstSuffix": "string",
    "streetNrLast": "string",
    "streetNrLastSuffix": "string",
    "streetNamePrefix": "E",
    "streetType": "ST",
    "subAddress": {
      "sourceId": "CLSPCOMA1NT9V.1",
      "source": "Trillium",
      "geoSubAddressId": 1,
      "combinedDesignator": "BLDG SHOP",
      "elements": [
        {
          "designator": "APT",
          "value": 2
        }
      ]
    },
    "timeZone": {
      "name": "US Mountain Standard Time",
      "ianaName": "America/Denver",
      "isDaylightSavingsTime": false,
      "offset": -7
    },
    "npaNxxList": [
      {
        "npa": {
          "code": "303"
        },
        "nxx": {
          "code": "291"
        }
      }
    ]
  }
}
```
Response
========
```sh
{
  "creditApplicationRefNumber": "01000009303498",
  "creditReportId": "01000009303498",
  "creditClass": 7,
  "finalBillInd": true,
  "finalBillInfo": {
    "btn": "208-529-4610",
    "cusCode": 723,
    "finalBillName": "JANE JAMES",
    "ssn": "528-98-4589",
    "finalBillAddress": {
      "streetAddress": "7672 S REDWOOD RD",
      "additionalLocation": "string",
      "city": "WEST JORDAN",
      "stateOrProvince": "UT",
      "postalCode": 84084
    },
    "finalBillDate": "2018-07-03T14:49:44.282Z",
    "entityFinalBillFlag": false,
    "finalBillEntityList": [
      {
        "finalBillEntity": {
          "entityCode": "MBH",
          "dueAmt": 14.82
        }
      }
    ],
    "finalBillAmt": {
      "amount": 115.18
    },
    "paymentRequiredInd": true
  }
}
```
Error Response
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```


| HTTP Status Code (BM) | BM Reason Code               | Message Text  |
|:----------------------|:-----------------------------|:---------------|
| BAD_REQUEST_400       | INVALID_SSN                  | SSN value cannot be empty or null.                                                                   |
|                       | INVALID_SSN_FORMAT_OR_LENGTH | SSN: Invalid Format or Length.                                                                      |
|                       | INVALID_INPUT                | Send the "Secondary Result Message" from CP Web.                                                     |
|                       | INVALID_DATA                 | Send the "Secondary Result Code -Secondary Result Message" from CP Web.                              |
|                       | INVALID_DATA                 | Send the "Secondary Result Code -Secondary Result Message" from CP Web.                              |
|                       | INVALID_DATA                 | Send the "Secondary Result Code -Secondary Result Message" from CP Web.                              |
| 401 [Unauthorized]    | AUTHENTICATION_FAILURE       | Authentication failed due to invalid authentication credential.                                      |
| 404                   | RESOURCE_NOT_FOUND           | No Records Found   |
| 502                   | CPWEB_SERVER_ERROR           | Web service is unable to process request.                                                               |
| 500                   | BM_CREDIT_CHECK_SERVER_ERROR | Credit Check Business Service - \< API/Method Name\> is unable to process this request at this time. |
| 503                   | CPWEB_SERVER_UNAVAILABLE     | Failure connecting to external syatem                                                               |
| 502                   | CPWEB_SERVER_ERROR           | Send the "Secondary Result Message" from CP Web.                                                     |
| 502                   | CPWEB_SERVER_ERROR           | Send the "Secondary Result Message" from CP Web.                                                     |
| 502                   | CPWEB_SERVER_ERROR           | Send the "Explanation" from CP Web.                                                                  |
| 502                   | CPWEB_SERVER_ERROR           | Send the "Explanation" from CP Web.                                                                  |

[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v3.12.3.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/bill-estimates-process-business-service/>
   [v2.12.0.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>
   
