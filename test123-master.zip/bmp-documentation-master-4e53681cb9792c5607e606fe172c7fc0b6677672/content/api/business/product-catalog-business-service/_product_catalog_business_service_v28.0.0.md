Product Catalog/Service Availability Business Service 
======================================================
    Version: 28.0.0

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /findAvailableServices](#Request)
- [Response /address/getAvailableServices](#Response)

Overview
--------

> **This business service lists qualified service categories for the given address.**

![](media/ProductCatalogDiagram.png)

Request Syntax
--------------

For each resource, the following items are documented.

| Name           | Value                                      |
|:---------------|:-------------------------------------------|
| HTTP Method    | post                                       |
| Base URI       | /bsi/ServiceAvailabilityBusinessService/v1 |
| URI Syntax     |                                            |
| Operation Name | /findAvailableServices                     |

Operation Details (Request/Response)
------------------------------------

### Required Attributes

The attributes in request is mandatory.

    API: /findAvailableServices

Request
=======
```sh
{
  "postalAddressFlag": true,
  "addressLine": "918 N ROYER ST, COLORADO SPRINGS, CO 80903",
  "unitNumber": "APT 1",
  "streetAddress": null,
  "streetNrFirst": null,
  "streetNrFirstSuffix": null,
  "streetNrLast": null,
  "streetNrLastSuffix": null,
  "streetName": null,
  "streetType": null,
  "locality": null,
  "city": null,
  "stateOrProvince": null,
  "postCode": null,
  "postCodeSuffix": 2385,
  "country": null
}{
  "success": true,
  "result": "Green - exact match",
  "serviceAddress": {
    "addressId": "CLSPCOMA16ACF",
    "streetAddress": "918 N ROYER ST",
    "streetNrFirst": "918",
    "streetNrFirstSuffix": null,
    "streetNrLast": null,
    "streetNrLastSuffix": null,
    "streetName": "N ROYER",
    "streetNamePrefix": "E",
    "streetType": "ST",
    "locality": "COLORADO SPRINGS",
    "city": "COLORADO SPRINGS",
    "stateOrProvince": "CO",
    "postCode": "80903",
    "postCodeSuffix": "2385",
    "sourceId": "CLSPCOMA16ACF",
    "source": "LFACS",
    "geoAddressId": "213702098",
    "subAddress": {
      "sourceId": "CLSPCOMA1NT9V.1",
      "source": "LFACS",
      "geoSubAddressId": 1,
      "combinedDesignator": "BLDG 1",
      "elements": [
        {
          "designator": "APT",
          "value": 2
        }
      ]
    },
    "country": "USA",
    "geoPoint": [
      [
        {
          "source": "Trillium",
          "latitude": 0,
          "longitude": 0,
          "coordinateLevel": 0,
          "accuracy": 0
        }
      ]
    ],
    "locationAttributes": {
      "isMdu": true,
      "legacyProvider": "QWEST COMMUNICATIONS",
      "rateCenter": "COLORDOSPG",
      "npa": 318,
      "nxx": 340,
      "wirecenter": "CLSPCOMA",
      "cala": "SCO",
      "tarCode": "NV0200",
      "tta": 471
    },
    "npaNxxList": [
      {
        "npa": {
          "code": 303
        },
        "nxx": {
          "code": 291
        }
      }
    ],
    "timeZone": {
      "name": "US Mountain Standard Time",
      "ianaName": "America/Denver",
      "isDaylightSavingsTime": false,
      "offset": -7
    }
  },
  "orderReference": {
    "orderReferenceNumber": "ORN-20171127071857795",
    "salesChannel": "ESHOP-Customer Care",
    "customerType": "Individual",
    "customerSegment": "Regular",
    "customerOrderType": "NEWINSTALL",
    "ban": 852185131,
    "customerOrderNumber": "CON-20170814091333089"
  }
}
```
Response
=========
```sh
{
  "success": true,
  "result": "Green - exact match",
  "serviceAddress": {
    "addressId": "CLSPCOMA16ACF",
    "streetAddress": "918 N ROYER ST",
    "streetNrFirst": "918",
    "streetNrFirstSuffix": null,
    "streetNrLast": null,
    "streetNrLastSuffix": null,
    "streetName": "N ROYER",
    "streetNamePrefix": "E",
    "streetType": "ST",
    "locality": "COLORADO SPRINGS",
    "city": "COLORADO SPRINGS",
    "stateOrProvince": "CO",
    "postCode": "80903",
    "postCodeSuffix": "2385",
    "sourceId": "CLSPCOMA16ACF",
    "source": "LFACS",
    "geoAddressId": "213702098",
    "subAddress": {
      "sourceId": "CLSPCOMA1NT9V.1",
      "source": "LFACS",
      "geoSubAddressId": 1,
      "combinedDesignator": "BLDG 1",
      "elements": [
        {
          "designator": "APT",
          "value": 2
        }
      ]
    },
    "country": "USA",
    "geoPoint": [
      [
        {
          "source": "Trillium",
          "latitude": 0,
          "longitude": 0,
          "coordinateLevel": 0,
          "accuracy": 0
        }
      ]
    ],
    "locationAttributes": {
      "isMdu": true,
      "legacyProvider": "QWEST COMMUNICATIONS",
      "rateCenter": "COLORDOSPG",
      "npa": 318,
      "nxx": 340,
      "wirecenter": "CLSPCOMA",
      "cala": "SCO",
      "tarCode": "NV0200",
      "tta": 471
    },
    "npaNxxList": [
      {
        "npa": {
          "code": 303
        },
        "nxx": {
          "code": 291
        }
      }
    ],
    "timeZone": {
      "name": "US Mountain Standard Time",
      "ianaName": "America/Denver",
      "isDaylightSavingsTime": false,
      "offset": -7
    }
  },
  "orderReference": {
    "orderReferenceNumber": "ORN-20171127071857795",
    "salesChannel": "ESHOP-Customer Care",
    "customerType": "Individual",
    "customerSegment": "Regular",
    "customerOrderType": "NEWINSTALL",
    "ban": 852185131,
    "customerOrderNumber": "CON-20170814091333089"
  }
}
```
Error Response 
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

| API            | /findAvailableServices              |
|:---------------|:------------------------------------|
| Error Code     | 202                                 |
| Error Message  | Red - no match, Address Not found   |
| Error Code     | 203                                 |
| Error Message  | successfully found multiple matches |
| Error ode      | 401                                 |
| Error Message  | Unauthorized Scenario               |
| Error Code     | 500                                 |
| Error Message  | Internal Server Error               |
| Name           | Value                               |
| HTTP Method    | post                                |
| Base URI       | /bsi/AddressBusinessService/v1      |
| URI Syntax     |                                     |
| Operation Name | /getAvailableServices               |

### Required Parameters

| Parameter            | Description    |
|:---------------------|:---------------|
| orderReferenceNumber | auto-generated number to share with external interfaces including human interfaces |
| serviceCategory      | 'CustomerProductType from LoopQual, such as DATA, VIDEO and DATA/VIDEO'            |

Operation Details (Request/Response)
------------------------------------

    API: /address/getAvailableServices

Request
=======
```sh
{
  "orderReferenceNumber": "ORN-20171127071857795",
  "serviceCategory": [
    {
      "serviceCategory": "DATA"
    }
  ]
} 
```
Response
========
```sh
{
  "success": true,
  "status": [
    {
      "statusCode": null,
      "reasonCode": null,
      "message": null
    }
  ],
  "orderReferenceNumber": "ORN-20171127071857795",
  "serviceQualification": {
    "qualificationResult": "Success",
    "failureComment": null,
    "qualificationResultDate": "2018-07-04T05:05:42.559Z",
    "maxSpeed": "Upto 40 Mbps Downstream/10 Mbps Upstream",
    "accessType": "ADSL2+",
    "prismSupported": true,
    "hdStreaming": 4,
    "sdStreaming": 3,
    "dhpSupported": true,
    "hpSupported": true
  },
  "serviceCategory": [
    {
      "networkInfrastructureIndicatorCode": "FTTN-ETH-A2P",
      "qualificationColorName": "GREEN",
      "serviceSpecification": [
        {
          "id": 0,
          "name": "HSI 43008 Kbps/10000 Kbps",
          "serviceCategory": "DATA",
          "serviceDescription": "Upto 40 Mbps Downstream/10 Mbps Upstream",
          "accessType": "ADSL2+",
          "accessTypeForPrice": "ADSL2+",
          "prismSupported": true,
          "hdStreaming": 4,
          "sdStreaming": 3,
          "dhpSupported": true,
          "hpSupported": true,
          "serviceCharacteristics": [
            {
              "id": 0,
              "name": "downSpeed",
              "valueFrom": "0 Mbps",
              "valueTo": "43008 Mbps"
            }
          ],
          "repairProductFlag": false,
          "grandfatheredProductFlag": false,
          "mandatoryTechInstallFlag": true,
          "modemCompatibility": "NA",
          "modemCompatibilityMessage": "NA"
        }
      ],
      "processInfo": [
        {
          "processInfoGroupName": "GROOMING_REQUIRED",
          "processInfoAttribute": [
            {
              "name": "REASON",
              "value": "SP"
            }
          ]
        }
      ],
      "remark": [
        {
          "text": "Local Loop may support broadband service. Issue order following GROOMING loop qual process.",
          "infoText": "additional info.",
          "remarkRef": "GROOMING_REQUIRED"
        }
      ],
      "accessQualification": [
        {
          "accessQualificationResult": "failure",
          "failureReason": [
            {
              "code": "OTHER",
              "description": "A downstream callout error is preventing successful qualification."
            }
          ]
        }
      ]
    }
  ],
  "processInfoAdditional": [
    {
      "processInfoGroupName": "FRANCHISE_INFORMATION",
      "processInfoAttribute": [
        {
          "name": "PRISM_FRANCHISE_AREA",
          "value": true
        }
      ]
    }
  ]
}
```
Error Response 
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

| HTTP Status Code (BM) | BM Reason Code | Message Text   |
|:----------------------|:---------------|:---------------|
| 400                   | INVALID_ADDRESS                              | addressLine must exist.                                                                                                             |
| 400                   | INVALID_ADDRESS_FORMAT                       | The address of a service address qualification request is not formatted correctly.                                                  |
| 400                   | INVALID_SOURCE_SYSTEM                        | An unknown value was specified for the MessageSrcSystem field.                                                                      |
| 400                   |                                              | An unknown value was specified for the RequestType field.                                                                           |
| 400                   |                                              | Either an invalid value was specified for the SourceAddressSystemIndicator field or too many instances of the field were specified. |
| 400                   |                                              | Some other request message error was identified.                                                                                    |
| 400                   |                                              | This is an obsolete code that is not returned now.                                                                                  |
| 404                   | RESOURCE_NOT_FOUND                           | No service is available at this location                                                                                            |
| 500                   | LOOPQUAL_SERVER_ERROR                        | An internal Loop Qual error prevented successful qualification completion.                                                          |
| 500                   | SERVICE_AVAIL_SERVER_ERROR                   | ServiceAvailability - \< API/Method Name\> is unable to process this request at this time.                                          |
| 502                   | LOOPQUAL_SERVER_ERROR                        | LoopQual is unable to process this request.                                                                                         |
| 503                   | LOOPQUAL_SERVER_ERROR                        | The server cannot handle the request for a service due to temporary maintenance.                                                    |
| 504                   | LOOPQUAL_SERVER_ERROR                        | The server cannot handle the request and is timing out.                                                                             |
| 500                   | SERVICE_AVAIL_DB_ERROR                       | The server is unable to process the request due to a database error.                                                                |
| 500                   | SERVICE_AVAIL_RULES_ERROR                    | The server is unable to process the request due to rules service error.                                                             |
| 400                   | INVALID_ORDERREFERENCE_NUMBER                | OrderReferenceNumber must exist.                                                                                                    |
| 400                   | INVALID_ADDRESS                              | AddressLine must exist.                                                                                                             |
| 401                   | UNKNOWN                                      | An internal Loop Qual error prevented successful qualification completion.                                                          |
| 400                   | REQUEST_FORMAT_INCORRECT                     | An internal Loop Qual error prevented successful qualification completion.                                                          |
| 400                   | ADDRESS_REQUEST_FORMAT_INCORRECT             | The address of a service address qualification request is not formatted correctly.                                                  |
| 400                   | UNKNOWN_MESSAGESYSTEM                        | An unknown value was specified for the MessageSrcSystem field.                                                                      |
| 400                   | UNKNOWN_VALUE_FOR_REQUESTTYPE                | An unknown value was specified for the RequestType field.                                                                           |
| 400                   | INVALID_VALUE_OF_SOURCEADRESSSYSTEMINDICATOR | Either an invalid value was specified for the SourceAddressSystemIndicator field or too many.                                       |
| 400                   | INVALID_REQUEST_XML_FORMAT                   | Some other request message error was identified.                                                                                    |
| 400                   | INVALID_CATEGORY                             | This is an obsolete code that is not returned now.                                                                                  |
| 401                   | QUALIFIED_PRODUCT_NOT_FOUND                  | NoQualifiedProducts                                                                                                                 |
| 503                   | LOOPQUAL_SERVER_ERROR                        | The server cannot handle the request and is timing out.                                                                             |
| 404                   | STANDALONE_BRMS_RULES_NOT_FOUND              | No service is available at this location.                                                                                           |
| 404                   | DATABASE_CONNECTION_FAILED                   | The server is unable to process the request due to a database error.                                                                |
| 500                   | LOOPQUAL_BRMS_RULES_UNAVAILABLE              | No service is available at this location.                                                                                           |
| 404                   | LOOPQUAL_BRMS_RULES_NOT_FOUND                | No service is available at this location.                                                                                           |
| 404                   | CATALOG_RESOURCE_NOT_FOUND                   | No service is available at this location.                                                                                           |
| 404                   | COMPATABILITY_BRMS_RESOURCE_NOT_FOUND        | No service is available at this location.                                                                                           |
| 404                   | HD_SD_BRMS_RESOURCE_NOT_FOUND                | No service is available at this location.                                                                                           |

[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>