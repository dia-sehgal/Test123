Due Date Service 
=================
    Version: 3.17.3

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Bill Estimates|[v3.12.3.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /dueDate](#Request)
- [Response /dueDate](#Response)

Overview
--------

> **Due Date service is used to calculate earliest possible Due Date for the order and get exception days (holidays) falling within a given duration.**

![](media/DueDateDiagram.png)

Request Syntax
--------------

For each resource, the following items are documented.

| Name           | Value           |
|:---------------|:----------------|
| HTTP Method    | post     |
| Base URI       | /v1      |
| URI Syntax     |          |
| Operation Name | /dueDate |

Operation Details (Request/Response)
------------------------------------
### Required Attributes

    API: /dueDate

Request
=======
```sh
{
  "customerOrderType": "string",
  "cycleEndDate": "string",
  "cycleStartDate": "string",
  "orderReferenceNumber": "string",
  "qualificationColorName": "string",
  "processInfo": [
    {
      "processInfoGroupName": "string",
      "processInfoAttribute": [
        {
          "name": "string",
          "value": "string"
        }
      ]
    }
  ],
  "portTN": "Yes",
  "possiblePortoutDate": "string",
  "possiblePortDueDays": "6",
  "requestedDueDate": {
    "requestedDueDate": "2018-07-03T11:25:32.162Z",
    "overrideFlag": true
  }
}
```
Response
========
```sh
{
  "success": true,
  "requestedDueDate": "2018-07-03T11:35:03.732Z",
  "calculatedDueDate": "2018-07-03T11:35:03.732Z",
  "finalDueDate": "2018-07-03T11:35:03.732Z",
  "overrideFlag": true,
  "isCRDAvailable": true
}
```
Error Response
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

| HTTP Status Code (BM) | BM Reason Code                        | Message Text|
|:----------------------|:--------------------------------------|-------------|
| 400                   | CITY_NOT_FOUND                                | City field cannot be empty or null.                                                              |
| 400                   | WIRECENTRE_NOT_FOUND                          | Wirecentre field cannot be empty or null.                                                        |
| 400                   | STATE_NOT_FOUND                               | State field cannot be empty or null.                                                             |
| 400                   | GROOMING_DETAILS_NOT_FOUND                    | Grooming Details array cannot be empty or null.                                                  |
| 400                   | CUSTOMER_ORDER_TYPE_NOT_FOUND                 | Customer Order Type field cannot be empty or null.                                               |
| 400                   | GEOGRAPHY_OR_ORDER_REFERENCE_NUMBER_NOT_FOUND | OrderReferenceNumber or Geography field cannot be empty or null.                                 |
| 400                   | START_DATE_NOT_FOUND                          | Start date is invalid or not found.                                                              |
| 404                   | RESOUCE_NOT_FOUND                             | No Resource/Data found for this request.                                                         |
| 405                   | METHOD_NOT_ALLOWED                            | The server does not implement the requested HTTP method.                                         |
| 500                   | BM_DUE_DATE_SERVER_ERROR                      | Due Date Business Service - \< API/Method Name\> is unable to process this request at this time. |
| 500                   | DUEDATE_DATA_SERVICE_UNAVAILABLE              | The server cannot handle the request for a service due to temporary maintenance.                 |
| 500                   | TRANSLATION_SERVICE_UNAVAILABLE               | The server cannot handle the request for a service due to temporary maintenance.                 |
| 500                   | ORDER_BUSINESS_SERVICE_UNAVAILABLE            | The server cannot handle the request for a service due to temporary maintenance.                 |
| 502                   | BAD_GATEWAY                                   | Something wrong happened while processing the request in southbound service.                     |
| 502                   | BAD_GATEWAY                                   | Something wrong happened while processing the request in southbound service.                     |


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v3.12.3.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/bill-estimates-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>
   
