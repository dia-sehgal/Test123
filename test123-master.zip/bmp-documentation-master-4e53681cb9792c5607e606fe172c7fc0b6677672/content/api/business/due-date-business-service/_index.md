---
title: "Due Date"
date: 2018-05-24T09:51:24-07:00
draft: false
---

This is a generic service to calculate Due Date for order captured based on order date and order attributes.
Currently it deals with data service and Order-Business-Service.
In data service it checks for no of days required to fulfill order and non working days.
And from Order-Business-Service it gets other order related information like order placed date etc.

## Sections
* [Resources/Operations](#resources-operations)
* [Swagger Specification](#swagger-specification)
* [Authentication Details](#authentication-details)
* [MAL/Cloud Org](#mal-cloud-org)
* [Dependencies](#dependencies)
  - [MongoDB](#mongodb)
  - [PCF Services](#pcf-services)
  - [Processes Using](#processes-using)
  - [Downstream Services](#downstream-services)
* [Developer Installation](#developer-installation)
* [Setup](#setup)
* [CI/CD Pipeline Details](#ci-cd-pipeline-details)
* [Cloud Environment Details](#cloud-environment-details)
* [Splunk Dashboard](#splunk-dashboard)


## Resources/Operations   
  i) **/bsi/dueDate** - This API Calculates due date for given order number(ORN) based on multiple parameters like Port TN is Yes or No or is there any non working days etc. Detailed specification available [here](_due_date_api_spec_v3.17.3)
  	 It calls due date data service and OBS for response.  
 ii) **/bsi/getExceptionDays** - This API provides the non working days in given time period.
     It calls due date data service for response.  
     
## Swagger Specification
{{< oai-spec url="https://bmp-documentation.pcfmrnctl.dev.intranet/api/business/due-date-business-service/files/api-docs.json" >}}

     
## Developer Installation :
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
    - Visit [Oracle] website to get the Oracle JDBC driver â€“ ojdbc6.jar or ojdbc7.jar
    - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} 
      -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar     
	   
## SetUp : 
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/duedate-business-service.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run    
```
	   
## Dependencies :
   Translation data Service
   	prod: https://bmp-ds-service-translation.pcfmrnctl.corp.intranet/bsi/Translation/v1/modemDetails
    e2e: https://bmp-ds-service-translation-ctle2e.pcfmrnctl.dev.intranet/bsi/Translation/v1/modemDetails
    
   Due Date Data Service
   	prod: https://bmp-ds-service-due-date.pcfmrnctl.dev.intranet/DueDateDsService
    e2e: https://bmp-ds-service-due-date-ctle2e.pcfmrnctl.dev.intranet/DueDateDsService
    
   Order Business Service
   	prod: https://bmp-order-business-service-checkout-ctle2e.pcfmrnctl.dev.intranet/#!/feature-description-controller/getFeatureDescriptionUsingGET
    e2e: https://bmp-order-business-service-checkout-ctle2e.pcfmrnctl.dev.intranet/#!/feature-description-controller/getFeatureDescriptionUsingGET
    
## CI/CD Pipeline Details :
* Name:	 bmp-duedate-business-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000

* Sonarqube Project URL:	 TBD

* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 https://ne1itcprhas62.ne1.savvis.net/BMP_DEV/duedate-business-service/blob/release/final/Jenkinsfile      

## Cloud Environment Details
* Cloud Group Name:	 BMCO-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-duedate-business-service-test3.pcfmrnctl.dev.intranet/

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/  

## Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards

## Swagger URL :
```sh
https://bmp-duedate-business-service-test3.pcfmrnctl.dev.intranet/
```

## Sample Request for Post(dueDate):
```sh
{
	"customerOrderType": "string",
	"cycleEndDate": "string",
	"cycleStartDate": "string",
	"orderReferenceNumber": "ORN-10499453528649410",
	"qualificationColorName": "GREEN",
	"processInfo": [{
		"processInfoGroupName": "GROOMING_REQUIRED",
		"processInfoAttribute": [{
			"name": "string",
			"value": "string"
		}]
	}],
	"portTN": "Yes",
	"possiblePortoutDate": "string",
	"possiblePortDueDays": "string",
	"requestedDueDate": {
		"requestedDueDate": "string",
		"overrideFlag": true
	},
	"featureDescription": {
		"subMarketCode": "B2608",
		"ppfcs": [{
				"bmProductName": "ISP",
				"productSubType": "  ",
				"productType": "TD",
				"pricePlan": "INTQ6907",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "JQISPB",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "High-Speed Internet Access",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "SHIPPING",
				"productSubType": "IB",
				"productType": "TD",
				"pricePlan": "DEFINR",
				"ppExpirationDate": null,
				"ppEffectiveDate": null,
				"featureCode": "1001I",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Shipping and Handling Fee",
				"recurTermFee": 0,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "MODEM",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "INTQ685I",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "Q685I",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Standard Modem - Purchase ADSL2 TI",
				"recurTermFee": 0,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "HSI Upto 40 Mbps/20 Mbps",
				"productSubType": "",
				"productType": "QW",
				"pricePlan": "INTQ6913",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "J6913Q",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": true,
				"featureDescription": "VDSL SA 40M/20M",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "TECH INSTALL",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "CVBATABBU",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-02-19",
				"featureCode": "7330",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Non-Excludable RC",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "CENTURYLINK @ EASE",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "INTQ9104",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "J9104S",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "CenturyLink atEase - Ultra",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism TV Install",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQADSTB4",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "7176Q",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Additional TV Install Charge",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Video Access Point",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQWSTB1T",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "VAPQ  ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Video Access Point",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "DVR Service",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQPKRRA3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-10",
				"featureCode": "DVRS2Q",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Prism DVR Service included",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Wired Set Top Box",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQPKRRA3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-10",
				"featureCode": "1RTBXQ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Primary Set Top Box",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism Complete TV",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQPKRRA3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-10",
				"featureCode": "PKG3QB",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": true,
				"featureDescription": "Prism Complete TV (rack rate)",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "MODEM",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "INTQ685I",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "Q685I",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Standard Modem - Purchase ADSL2 TI",
				"recurTermFee": 0,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Wireless Set Top Box",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQWSTB1T",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "WST1TQ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "1st Wireless Set Top Box",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism WSTB Surcharge",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQWSTB2T",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "1240IQ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Prism WSTB Surcharge Fee",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism HD TV",
				"productSubType": null,
				"productType": null,
				"pricePlan": "TVHDTV2",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-11",
				"featureCode": "HDTV2",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": null,
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "TV Caller ID",
				"productSubType": null,
				"productType": null,
				"pricePlan": "TVPK24A3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-11",
				"featureCode": "DTVID ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": null,
				"recurTermFee": 20,
				"termFee": null,
				"action": "",
				"term": 24,
				"bundleCode": null,
				"billingFeatureCodes": null
			}
		]
	}
}
```
# Sample Response :
```sh
{
    "requestedDueDate": null,
    "calculatedDueDate": "2017-11-09T00:00:00.000Z",
    "finalDueDate": "2017-11-09T00:00:00.000Z",
    "overrideFlag": false
  
}
```
# Sample Request for Post(getExceptionDays):
```sh
{
	"durationEndDate": "2018-04-11T",
	"durationStartDate": "2018-04-01",
	"geography": {
		"wirecenter": "EPHRWA01",
		"city": "EPHRATA",
		"state": "WA"
	},
	"orderRefNumber": "string",
	"submarketCode": "string",
	"featureDescription": {
		"subMarketCode": "B2608",
		"ppfcs": [{
				"bmProductName": "ISP",
				"productSubType": "  ",
				"productType": "TD",
				"pricePlan": "INTQ6907",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "JQISPB",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "High-Speed Internet Access",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "SHIPPING",
				"productSubType": "IB",
				"productType": "TD",
				"pricePlan": "DEFINR",
				"ppExpirationDate": null,
				"ppEffectiveDate": null,
				"featureCode": "1001I",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Shipping and Handling Fee",
				"recurTermFee": 0,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "MODEM",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "INTQ685I",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "Q685I",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Standard Modem - Purchase ADSL2 TI",
				"recurTermFee": 0,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "HSI Upto 40 Mbps/20 Mbps",
				"productSubType": "",
				"productType": "QW",
				"pricePlan": "INTQ6913",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "J6913Q",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": true,
				"featureDescription": "VDSL SA 40M/20M",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "TECH INSTALL",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "CVBATABBU",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-02-19",
				"featureCode": "7330",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Non-Excludable RC",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "CENTURYLINK @ EASE",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "INTQ9104",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "J9104S",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "CenturyLink atEase - Ultra",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism TV Install",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQADSTB4",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "7176Q",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Additional TV Install Charge",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Video Access Point",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQWSTB1T",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "VAPQ  ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Video Access Point",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "DVR Service",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQPKRRA3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-10",
				"featureCode": "DVRS2Q",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Prism DVR Service included",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Wired Set Top Box",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQPKRRA3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-10",
				"featureCode": "1RTBXQ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Primary Set Top Box",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism Complete TV",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQPKRRA3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-10",
				"featureCode": "PKG3QB",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": true,
				"featureDescription": "Prism Complete TV (rack rate)",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "MODEM",
				"productSubType": "  ",
				"productType": "QW",
				"pricePlan": "INTQ685I",
				"ppExpirationDate": null,
				"ppEffectiveDate": "1950-01-01",
				"featureCode": "Q685I",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Standard Modem - Purchase ADSL2 TI",
				"recurTermFee": 0,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Wireless Set Top Box",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQWSTB1T",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "WST1TQ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "1st Wireless Set Top Box",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism WSTB Surcharge",
				"productSubType": "  ",
				"productType": "QP",
				"pricePlan": "TVQWSTB2T",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2016-04-02",
				"featureCode": "1240IQ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": "Prism WSTB Surcharge Fee",
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "Prism HD TV",
				"productSubType": null,
				"productType": null,
				"pricePlan": "TVHDTV2",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-11",
				"featureCode": "HDTV2",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": null,
				"recurTermFee": null,
				"termFee": null,
				"action": "",
				"term": 0,
				"bundleCode": null,
				"billingFeatureCodes": null
			},
			{
				"bmProductName": "TV Caller ID",
				"productSubType": null,
				"productType": null,
				"pricePlan": "TVPK24A3",
				"ppExpirationDate": null,
				"ppEffectiveDate": "2017-02-11",
				"featureCode": "DTVID ",
				"ftrExpirationDate": null,
				"ftrEffectiveDate": null,
				"isPrimary": false,
				"featureDescription": null,
				"recurTermFee": 20,
				"termFee": null,
				"action": "",
				"term": 24,
				"bundleCode": null,
				"billingFeatureCodes": null
			}
		]
	}
}
```
# Sample Response :
```sh
{
    "orderRefNumber": "string",
    "geography": {
      "wirecenter": "EPHRWA01",
      "city": "EPHRATA",
      "state": "WA"
    },
    "submarketCode": "C2064",
    "exceptionDaysInfo": {
      "durationStartDate": "2017-10-10",
      "durationEndDate": "2017-11-11",
      "dueDateExceptionDays": [
        {
          "exceptionDate": "2017-10-22"
        },
        {
          "exceptionDate": "2017-10-29"
        },
        {
          "exceptionDate": "2017-11-05"
        }
      ]
    }
  }
```