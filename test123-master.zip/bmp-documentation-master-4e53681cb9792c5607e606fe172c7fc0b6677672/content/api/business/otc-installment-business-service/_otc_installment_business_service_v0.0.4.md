OTC Instalment Business Service
===============================
    Version: 0.0.4

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /getOfferDetails](#Request)
- [Response /getOfferDetails](#Response)

Overview
--------

> **OTC Instalment business service is used for sending OTC USOC for WTN. This service checks if any deposits or OTC has instalment eligibility and provides the max number of instalments.**

![](media/OTCInstalmentDiagram.png)

### Request Syntax

For each resource, the following items are documented.

| Name           | Value    |
|:---------------|:---------|
| HTTP Method    | POST     |
| Base URI       | /v1      |
| URI Syntax     |          |
| Operation Name | /SendOTC |

### Required Parameters

| Parameter     | Description        |
|:--------------|:-------------------|
| sourceSystem  | sourceSystem is the system from which component service will initiate. E.g. BLUEMARBLE |
| timestamp     | Timestamp of request                                                                   |
| WTN           |                                                                                        |
| ban           | Billing Number                                                                         |
| dueDate       | Due Date of the product                                                                |
| USOC          |                                                                                        |
| transactionId | Transaction Id for reference                                                           |

Operation Details (Request/Response)
------------------------------------

    API: /SendOTC

Request 
=======
```sh
{
  "sourceSystem": "string",
  "transactionId": "string",
  "timestamp": "string",
  "WTN": "string",
  "ban": "string",
  "dueDate": "string",
  "USOC": [
    {
      "name": "string",
      "value": "string"
    }
  ],
  "additionalData": [
    {
      "attributeName": "string",
      "attributeType": "string",
      "attributeValue": "string"
    }
  ]
}
```

Response 
========
```sh
{
  "Status": "string"
}
```
Error Response 
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```


| HTTP Status Code (BM) | BM Reason Code       | Message Text          |
|:----------------------|:---------------------|:----------------------|
| 400                   | INVALID_REQUEST_TYPE | Bad Request           |
| 401                   | UNKNOWN              | Unauthorized Scenario |
| 500                   | SERVER_ERROR         | Internal Server Error |



[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>