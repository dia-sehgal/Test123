---
title: "Account Management"
date: 2018-05-24T09:51:24-07:00
draft: false
---


AccountManagementBusinessService is a generic process to create Account  for customer order. Also, provides BAN for further processing.

## Sections
* [Resources/Operations](#resources-operations)
* [Swagger Specification](#swagger-specification)
* [Authentication Details](#authentication-details)
* [MAL/Cloud Org](#mal-cloud-org)
* [Dependencies](#dependencies)
  - [MongoDB](#mongodb)
  - [PCF Services](#pcf-services)
  - [Processes Using](#processes-using)
  - [Downstream Services](#downstream-services)
* [Developer Installation](#developer-installation)
* [Setup](#setup)
* [CI/CD Pipeline Details](#ci-cd-pipeline-details)
* [Cloud Environment Details](#cloud-environment-details)
* [Splunk Dashboard](#splunk-dashboard)




## Resources/Operations 
  i) **accountMgmt/contactMediumProfileInfo** - This API fetch Contact Medium info by ban.
  	   
 ii) **accountMgmt/createAccount** - This API submit Customer Account info for Account Creation.
     
 iii) **accountMgmt/createCustomerAccountInCDS** - This API create Customer Account info in CDS.

 iv) **accountMgmt/updateCustomeAccountInCDS** - This API update Customer Account info in CDS.
 
 v) **accountMgmt/deleteDTVAccountInCDS** - This API delete DTV Account info in CDS.
  	   
 vi) **accountMgmt/getAccountByBAN{ban}** - This API get Account details by ban.
     
 vii) **accountMgmt/getAccountForm** - This API sends a blank account form to the client to capture all the information needed to create account in Ensemble.

 viii) **/v1/getAPIInfo** - This API fetches API Information.
 
## Swagger Specification
{{< oai-spec url="https://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/files/api-docs.json" >}}

# Installation :
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
    - Visit [Oracle] website to get the Oracle JDBC driver â€“ ojdbc6.jar or ojdbc7.jar
    - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} 
      -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar


# SetUp : 
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/account-management-business-service.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run
```

# Dependent systems :
   getsubmarketcode.url:  https://bmp-order-business-service-checkout-test3.pcfmrnctl.dev.intranet/#!/feature-description-controller/getFeatureDescriptionUsingGET
   eas.url: https://eas-account-e2e.pcfmrnctl.dev.intranet/v1/accounts
   eas.getaccounturl: https://eas-account-e2e.pcfmrnctl.dev.intranet/v1/accounts/
   cds.retrieve.endpoint.url: https://cxg7i.test.intranet/soap/service/RetrieveCustomerData
   cds.endpoint.url: https://cxg7i.test.intranet/soap/service/ManageCustomerData


# CI/CD Pipeline Details :
* Name:	 bmp-account-management-business-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000

* Sonarqube Project URL:	 TBD

* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 https://ne1itcprhas62.ne1.savvis.net/BMP_DEV/account-management-business-service/blob/release/final/Jenkinsfile

# Cloud Environment Details
* Cloud Group Name:	 BMBILL-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-account-management-business-service-test3.pcfmrnctl.dev.intranet/

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/

# Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards

# Swagger URL :
```sh
https://bmp-account-management-business-service-test3.pcfmrnctl.dev.intranet/
```

# Sample Request for Post(create Account):
```sh
{
                "orderRefNumber": "ORN-11822203313362596",
                "accountInfo": {
                                "isBillAddrSameAsServiceAddress": true,
                                "accountName": {
                                                "firstName": "Dave",
                                                "lastName": "Matthews",
                                                "middleName": "",
                                                "businessName": null,
                                                "title": "",
                                                "generation": null
                                },
                                "accountPin": null,
                                "accountSubType": "R",
                                "accountType": "I",
                                "accountPreferences": {
                                                "paperlessBilling": false,
                                                "spanishBillPrint": false,
                                                "noTeleMarketing": false,
                                                "noEmail": false,
                                                "noDirectMail": false,
                                                "braille": false,
                                                "largePrint": false,
                                                "emailNotification": {
                                                                "billingNotification": true,
                                                                "orderingNotification": true,
                                                                "repairNotification": true
                                                },
                                                "textNotification": {
                                                                "billingNotification": true,
                                                                "orderingNotification": true,
                                                                "repairNotification": true
                                                }
                                },
                                "ban": null,
                                "billCycle": 0,
                                "billingAddress": {
                                                "isValidated": true,
                                                "streetAddress": "1120 S COLUMBIA ST",
                                                "streetNrFirstSuffix": "S",
                                                "streetNrFirst": "1120",
                                                "streetName": "COLUMBIA",
                                                "streetType": "ST",
                                                "streetNamePrefix": null,
                                                "city": "SEASIDE",
                                                "locality": "SEASIDE",
                                                "stateOrProvince": "OR",
                                                "postCode": "97138",
                                                "source": "Trillium",
                                                "postCodeSuffix": "5414",
                                                "country": "USA",
                                                "subAddress": {
                                                                "combinedDesignator": "",
                                                                "elements": [],
                                                                "geoSubAddressId": "",
                                                                "source": "",
                                                                "sourceId": ""
                                                },
                                                "locationAttributes": {
                                                                "isMdu": false,
                                                                "legacyProvider": "",
                                                                "rateCenter": "",
                                                                "wirecenter": "",
                                                                "npa": "503",
                                                                "nxx": "738",
                                                                "tta": "",
                                                                "tarCode": "",
                                                                "cala": ""
                                                }
                                },
                                "contact": {
                                                "contactNumber": "2089944000",
                                                "smsNumber": "2089944000",
                                                "emailAddress": "test029@vamh.net",
                                                "emailAddrDeclined": false
                                },
                                "cycleStartDate": "2018-07-14",
                                "creditClass": "7",
                                "geoCode": null,
                                "personalDetails": {
                                                "dateOfBirth": "1980-02-31",
                                                "dLExpirationDate": null,
                                                "dLlicenseNo": null,
                                                "dLlicenseState": null,
                                                "ssn": "518885296",
                                                "taxId": null,
                                                "creditCheck": true,
                                                "underAgeAck": false
                                },
                                "billingAdditionalInfo": "",
                                "billingAddressType": null
                }
}
```