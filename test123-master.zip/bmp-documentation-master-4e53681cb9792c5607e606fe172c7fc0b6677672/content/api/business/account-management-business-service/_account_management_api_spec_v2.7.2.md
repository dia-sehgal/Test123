Account Management Business Service
===================================
    Version: 2.7.2

[Request /accountMgmt/createAccount](#Request)

[Response /accountMgmt/createAccount](#Response)

Overview
--------

Account Management business service is used to Submit information that will be
sent to EaS to create BAN if new customer.

![](media/AccountMgmtDiagram.png)

**Request Syntax**

For each resource, the following items are documented.

| Name           | Value                                       |
|:---------------|:--------------------------------------------|
| HTTP Method    | POST          |
| Base URI       | /accountMgmt/createAccount                  |
| URI Syntax     | https://bmp-account-management-business-service-ctle2e.pcfmrnctl.dev.intranet/accountMgmt/createAccount                           |
| Operation Name | /createAccount                              |

**Required Parameters**


| Parameter                | Description                                |
|:-------------------------|:-------------------------------------------|
| ORN                      | OrderReferenceNumber can't be empty or null.|
| FIRSTNAME                | First name can't be empty or null.          |
| CONTACT_NUMBER           | Contact number can't be empty or null.      |
| LASTNAME                 | Last Name can't be empty or null. |
| LOCALITY                 | Locality can't be empty or null.            |
| STREET_NR_FIRST          | Street Nr First can't be empty or null.     |
| STREET_NAME              | Street name can't be empty or null. |
| STATE  (StateOrProvince) | StateOrProvince can't be empty or null.     |
| POSTCODE                 | PostCode can't be empty or null.            |
| SSN                      | Please enter a valid 9 digit ssn.           |
| STREET_TYPE              | Length should not be more than 4.           |
| STREET_DIRECTION_LENGTH  | Invalid length for Street Direction and Length should not be more than 2. |

Operation Details (Request/Response)
------------------------------------

The following attributes present in the API request/responses for **/accountMgmt/createAccount** service are mandatory.

   
Request
=========
    { 
    "orderRefNumber": "ORN-20694402410390219",   
    "accountInfo": 
    {                                     
            "cycleStartDate":"",
            "isBillAddrSameAsServiceAddress": true,
            "accountName": {                    "firstName": "vishal",
                                                "lastName": "garud",
                                                "middleName": "B",
                                                "businessName": null,
                                                "title": "MR",
                                                "generation": null
                                },
                                "accountPin": "5411",
                                "accountSubType": "R",
                                "accountType": "I",
                                "accountPreferences": {
                                                "paperlessBilling": true,
                                                "spanishBillPrint": false,
                                                "noTeleMarketing": true,
                                                "noEmail": false,
                                                "noDirectMail": false,
                                                "braille": null,
                                                "largePrint": null,
                                                "emailNotification": {
                                                                "billingNotification": true,
                                                                "orderingNotification": true,
                                                                "repairNotification": false
                                                },
                                                "textNotification": {
                                                                "billingNotification": true,
                                                                "orderingNotification": true,
                                                                "repairNotification": true
                                                }
                                },
                                "ban": null,
                                "billCycle": "2",
                                "billingAddress": {
                                                "country": "USA",
                                                "streetType": "",
                                                "city": "LITTLETON",
                                                "postCodeSuffix": null,
                                                "streetNrFirst": "3150",
                                                "locality": "LITTLETON",
                                                "locationAttributes": null,
                                                "source": null,
                                                "streetName": "E COUNTY LINE RD",
                                                "isValidated": false,
                                                "subAddress": {
                                                                "sourceId": "",
                                                                "geoSubAddressId": "",
                                                                "elements": [],
                                                                "combinedDesignator": "",
                                                                "source": ""
                                                },
                                                "stateOrProvince": "CO",
                                                "streetAddress": "3150 E COUNTY LINE RD",
                                                "streetNrFirstSuffix": "",
                                                "postCode": "80126",
                                                "streetNamePrefix": null
                                },
                                "contact": {
                                                "contactNumber": "9123456889",
                                                "smsNumber": "9123456889",
                                                "emailAddress": "abc@centurylink.com",
                                                "emailAddrDeclined": false
                                },
                                "creditClass": "4",
                                "geoCode": null,
                                "personalDetails": {
                                                "dateOfBirth": "1992-01-28",
                                                "dLExpirationDate": null,
                                                "dLlicenseNo": null,
                                                "dLlicenseState": null,
                                                "ssn": "123256352",
                                                "taxId": null,
                                                "creditCheck": true,
                                                "underAgeAck": true
                                }
                }
    }

    
Response
=============== 
    { 
    "success": true, 
    "ban": 852185131, 
    "accountPin": 1234, 
    "billCycle": "2" 
    } 
    
Error Response 
==============
    { 
     "errorResponse": [ 
      { 
       "statusCode": "string", 
       "reasonCode": "string", 
       "message": "string", 
       "messageDetail": "string", 
       "timestamp": "yyyy-mm-dd hh:mm:ss" 
      } 
     ] 
    }      

| HTTP Status Code (BM) | BM Reason Code| Message Text |
|:----|:-----|:---|
| 400            | INVALID_SSN_FORMAT                 | Invalid ssn                  |
| 400            | INVALID_BAN                        | Invalid BAN format           |
| 404            | INVALID_ORDER_REF                  | No SubMarketCode was found in OrderBusiness service.|
| 502            | EAS_EXCEPTION                      | Error Occured from EaS (Alongwith the errorresponse from EAS)    |
| 404            | NOT_FOUND_IN_EAS                   | Message from EaS (In case of getAccountInfoBy BAN)               |
| 503            | OBS_NOT_AVAILABLE                  | Connection to OrderBusinessService failed.                        |
| 400            | INVALID_ORN                        | OrderReferenceNumber can't be empty or null.                      |
| 400            | INVALID_FIRSTNAME                  | First name can't be empty or null.                                |
| 400            | INVALID_LASTNAME                   | Last Name can't be empty or null.   |
| 400            | INVALID_CONTACT_NUMBER             | Contact number can't be empty or null.                            |
| 400            | INVALID_LOCALITY                   | Locality can't be empty or null.    |
| 400            | INVALID_STREET_NR_FIRST            | Street Nr First can't be empty or null.                           |
| 400            | INVALID_STREET_NAME                | Street name can't be empty or null.                               |
| 400            | INVALID_STATE                      | StateOrProvince can't be empty or null.                           |
| 400            | INVALID_POSTCODE                   | PostCode can't be empty or null.    |
| 503            | EAS_SERVER_UNAVAILABLE             | The southBound URL is not active at this moment.                  |
| 500            | BMP_ACCOUNTMANAGEMENT_SERVER_ERROR | AccountManagement Service can't process the request at this time. |
