---
title: "Service Availability"
date: 2018-06-24T09:51:24-07:00
draft: false
---


This service provides access to Product Offering available based on Loop Qualification.

## Swagger Specification (E2E)
{{< oai-spec url="https://bmp-documentation.pcfmrnctl.dev.intranet/api/business/service-availability-business-service/files/api-docs.json" >}}

## Authentication Details
Access is granted based on membership to the following LDAP groups:

## MAL/Cloud Org
BMPO

## Dependencies
### MongoDB
* BMP_SERVICEAVAILABILITY_* database

### PCF Services
* bmp-mongodb-service-availability-bs
* bmp-redis-service

### Processes Using
* bmp-order-process
* bmp-order-process-move
* bmp-order-process-sup1
* bmp-order-process-sup2

### Downstream Services
* Loop Qualification Rule Services (all of them)
    - loopqualification-rule-service
    - loopqualification-hdsd-rule-service
    - loopqualstandaloneprism-rule-service
    - loopqualprism-rule-service
    - loopqualification-atm-rule-service
    - loopqualification-vdsl-rule-service
    - loopqualification-vdslpb-rule-service
    - loopqualification-adsl-rule-service
    - loopqualification-adslpb-rule-service
    - technologymapping-rule-service
    - atm-existingspeed-rule-service

{{<mermaid align="left">}}
graph TD;
    A[service-availability-business-service] --> B[All the rules services]
{{< /mermaid >}}

* LoopQualWebService
{{<mermaid align="left">}}
graph TD;
    A[service-availability-business-service] --> B[LoopQualWebService]
    B --> C[The Depths]
{{< /mermaid >}}

* order-management-business-service
{{<mermaid align="left">}}
graph TD;
    A[service-availability-business-service] --> B[order-management-business-service]
{{< /mermaid >}}


* ds-service-catalogs
{{<mermaid align="left">}}
graph TD;
    A[service-availability-business-service] --> B[ds-service-catalogs]
    B --> C[MongoDB]
{{< /mermaid >}}


# Installation/Setup :
1) Take the code from GIT.
2) Uncomment the application.properties
3) And also uncomment in JWTFilter.
  Comment for -->String jwtFilterFlag = System.getenv("jwtFilterFlag");
  Uncomment for --> String jwtFilterFlag = "false";
4) Please comment in below lines of code in SpringRedisConfig
  connectionFactory.setHostName("148.156.85.115");
  connectionFactory.setPort(37376);
  connectionFactory.setPassword("d57fa032-cf33-4c16-a728-721fa84a3947");
5) After done all these, do take maven update for the project.
6) Run maven install and spring boot application.

## For Each Operation (more detail available in swagger):
* Example Request/Response

## CI/CD Pipeline Details (example - not accurate)
* Name:	 bmp-service-availability-business-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000
* Sonarqube Project URL:	 TBD
* Pipeline Tool:	 Go.CD
* Pipeline URL:	 https://ne1itcprhas62.ne1.savvis.net/BMP_DEV/service-availability-business-service/blob/release/final/Jenkinsfile

## Links
* Deployment (CI/CD) Overview 
* BM Architectural Overview
* Development Practices (ENV Setup for Localhost, etc...)
* Splunk Details (dashboard, queries, etc...)


