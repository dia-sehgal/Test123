Hold/Unhold Order Business 
===========================
    Version: 1.0.1

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /getReason](#Request)
- [Response /getReason](#Response)

Overview
--------

This service is called whenever user wants to hold an order or resume an order.

### Request Syntax

For each resource, the following items are documented.

### Hold/Unhold an Order

#### Get Reason for Hold Order

| **Name**     | **Value**                             |
|:-------------|:--------------------------------------|
| HTTP Method  | GET                                   |
| Base URI     | /camunda/                             |
| URI Syntax   | test2.pcfmrnctl.dev.intranet/camunda/ |
| Operation    | /getReason                            |
| Operation id | getReason                             |

Operation Details (Request/Response)
------------------------------------

    API: /getReason

Request 
=======
```sh
{
  "orderReferenceNumber": "string",
  "salesChannel": "ESHOP-Customer Care",
  "reasonType": "HOLD"
}
```
    Response Code: 200 – Reason Retrieved Successfully

Response 
========
```sh
{
  "reasonList": {
    "reasonType": "string",
    "reasons": [
      {
        "code": "ASYMIS",
        "description": "Due Date Miskey",
        "waiverFlag": "No",
        "reasonType": "string",
        "reasonText": "string",
        "offerCategory": "string",
        "terminationFee": "string",
        "currencyCode": "string"
      }
    ],
    "notes": {
      "name": "Order Remarks",
      "value": "Take Left",
      "date": "2018-07-18T15:18:39.862Z",
      "author": "string"
    }
  }
}
```
    Error Code: 400 – Error

Error Response 
=============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

### Put an Order on Hold/Unhold

| **Name**     | **Value**  |
|:-------------|:-----------|
| HTTP Method  | POST       |
| Operation    | /orderHold |
| Operation id | orderHold  |

Request
=======
```sh
{
  "orderReferenceNumber": "string",
  "salesChannel": "ESHOP-Customer Care",
  "reasonType": "HOLD",
  "reasons": [
    {
      "code": "ASYMIS",
      "description": "Due Date Miskey",
      "waiverFlag": "No",
      "reasonType": "string",
      "reasonText": "string",
      "offerCategory": "string",
      "terminationFee": "string",
      "currencyCode": "string"
    }
  ],
  "notes": {
    "name": "Order Remarks",
    "value": "Take Left",
    "date": "2018-07-18T15:11:22.979Z",
    "author": "string"
  }
}
```

    Response Code: 200 – Order put on hold successfully

Response
========
```sh
{
  "success": true,
  "orderRefNumber": "ORN-20170808100628481",
  "message": {
    "message": "Order placed on Hold"
  }
}
```
 
    Error Code: 400 – Submit order error response

Error Response
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```

### Submit Request to Resume Order

| **Name**     | **Value**    |
|:-------------|:-------------|
| HTTP Method  | POST         |
| Operation    | /resumeOrder |
| Operation id | resumeOrder  |

Request	
=======
```sh
{
  "sfdcAccountId": "string",
  "orderReferenceNumber": "string",
  "salesChannel": "ESHOP-Customer Care",
  "reasonType": "HOLD",
  "reasons": [
    {
      "code": "ASYMIS",
      "description": "Due Date Miskey",
      "waiverFlag": "No",
      "reasonType": "string",
      "reasonText": "string",
      "offerCategory": "string",
      "terminationFee": "string",
      "currencyCode": "string"
    }
  ],
  "notes": {
    "name": "Order Remarks",
    "value": "Take Left",
    "date": "2018-07-18T15:11:31.012Z",
    "author": "string"
  }
}
```
    Response Code: 200 – Order resumed successfully

Response
=========
```sh
{
  "success": true,
  "orderRefNumber": "ORN-20170808100628481",
  "processInstanceId": "525833",
  "validationResult": [
    {
      "code": "ASYMIS",
      "description": "Due Date Miskey"
    }
  ],
  "taskId": "525926",
  "taskName": "Account Information",
  "payload": {}
}
```
 
    Error Code: 400 – Submit order error response

Error Response	
=============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>
