Bill Estimate Service 
======================
    Version: 3.12.3

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[vx.x.x.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /createBillEstimate](#Request)
- [Response /createBillEstimate](#Response)


Overview
--------

> **Bill Estimate business service is used to get generic Customer Bill quote service to create the estimate bill by submitting range and product details.**

![](media/BillEstimatesDiagram.png)

Request Syntax
--------------

For each resource, the following items are documented.

| Name           | Value               |
|:---------------|:--------------------|
| HTTP Method    | Post                |
| Base URI       | /v1                 |
| URI Syntax     |                     |
| Operation Name | /createBillEstimate |

**Required Parameters**

| Parameter      | Description                                     |
|:---------------|:------------------------------------------------|
| billStartDate  | Billing start date                              |
| billEndDate    | Billing end date                                |
| billEstimateID | ID can be used to retrieve the previous version |
| catalogSpecId  | Catalog spec id                                 |

Operation Details (Request/Response)
------------------------------------

### Request and Response Formats

    API: /createBillEstimate

Request
========
```sh
{
  "billStartDate": "string",
  "billEndDate": "string",
  "billEstimateID": "string",
  "catalogSpecId": "b982b278-cbf8-435c-9695-576b1a3b3378",
  "customerOrderItems": [
    {
      "catalogId": "b982b278-cbf8-435c-9695-576b1a3b3379",
      "productOfferingId": "string",
      "offerName": "string",
      "offerType": "BUNDLE",
      "offerSubType": "REGULAR",
      "offerCategory": "INTERNET",
      "quantity": 0,
      "action": "ADD",
      "contractStartDate": "2018-07-04T06:36:53.855Z",
      "contractTerm": 24,
      "rc": 0,
      "otc": 0,
      "discountedRc": 0,
      "discountedOtc": 0,
      "customerOrderSubItems": [
        {
          "productId": "string",
          "productName": "string",
          "productType": "INTERNET",
          "componentType": "PRIMARY",
          "productCategory": "CORE",
          "quantity": 1,
          "action": "ADD",
          "provisioningAction": "PROVISIONnBILL",
          "productAttributes": [
            {
              "compositeAttribute": [
                {
                  "attributeName": "downSpeed",
                  "attributeValue": 40128,
                  "uom": "Kbps"
                }
              ],
              "isDefault": 0,
              "displayOrder": 1,
              "isPriceable": true,
              "prices": [
                {
                  "priceKey": "string",
                  "priceType": "SUBSCRIPTION",
                  "priceTypeDescription": "string",
                  "rc": 39.99,
                  "otc": 69.99,
                  "discountedRc": 29.99,
                  "discountedOtc": 49.99,
                  "frequency": "PERMONTH",
                  "currencyCode": "USD",
                  "provisioningAction": "PROVISIONnBILL"
                }
              ],
              "discounts": [
                {
                  "autoAttachInd": "string",
                  "discountId": 0,
                  "discountDescription": "string",
                  "discountRate": 0,
                  "discountMethod": "string",
                  "discountLevel": "string",
                  "discountDuration": 0,
                  "discountType": "string",
                  "discountCategory": "string",
                  "discountMaxAmount": "string",
                  "discountRule": "string",
                  "discountMinimumAmount": "string",
                  "discountIdSequence": 0
                }
              ]
            }
          ],
          "productAssociations": [
            {
              "productAssociationType": "string",
              "productIds": [
                {
                  "productId": "2"
                }
              ]
            }
          ]
        }
      ]
    }
  ],
  "serviceLocation": {
    "streetAddress": "string",
    "streetName": "string",
    "streetType": "string",
    "locality": "string",
    "city": "string",
    "stateOrProvince": "string",
    "postCode": "string",
    "postCodeSuffix": "string",
    "country": "string"
  }
}
```
Response
========
```sh
[
  {
    "billStartDate": "string",
    "billEndDate": "string",
    "billEstimateID": "string",
    "billEstimate": {
      "quote": [
        {
          "quoteId": "1"
        }
      ]
    }
  }
]
```
Error Response
==============
```sh
{
  "errorResponse": [
    {
      "statusCode": "string",
      "reasonCode": "string",
      "message": "string",
      "messageDetail": "string",
      "timestamp": "yyyy-mm-dd hh:mm:ss"
    }
  ]
}
```


| HTTP Status Code (BM)     | BM Reason Code             | Message Text               |
|:--------------------------|:---------------------------|:---------------------------|
| 400 BAD_REQUEST           | BAD_REQUEST                | Mandatory field is missing in Request.  |
|                           | BAD_REQUEST                | As from South Bound                     |
| 404 NOT_FOUND             | NOT_FOUND                  | 404 Not Found                           |
|                           | NOT_FOUND                  | 404 Not Found                           |
| 500 INTERNAL_SERVER_ERROR | BM_BILL_QUOTE_SERVER_ERROR | An internal error occurred.             |
| 502 BAD_GATEWAY           | INVALID_RESPONSE           | Mandatory field is missing in Response. |


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [vx.x.x.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>
   
