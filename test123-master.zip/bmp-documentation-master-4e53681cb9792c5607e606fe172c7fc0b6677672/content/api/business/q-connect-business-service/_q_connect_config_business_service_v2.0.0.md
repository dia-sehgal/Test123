Quick Connect Config Business Service
=====================================
    Version: 2.0.0

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /retrieveCustomerDataForActivation](#Request)
- [Response /retrieveCustomerDataForActivation](#Response)

Overview
--------

> **Quick Connect Business Service serves the purpose of retrieving Customer Account Activation details from various applications like CDS (customer account information), IMPROV (to get the opuserName and password), Service Registry (product details), Ensemble (account details) and combine them into one response to provide to Quick connect application for service activation. Other operations include updating modem attributes (MACID and Serial Number).**

### Request Syntax

For each resource, the following items are documented.

| Name           | Value                                                           |
|:---------------|:----------------------------------------------------------------|
| HTTP Method    | POST                                                            |
| Base URI       | /bsi/qConnect                                                   |
| URI Syntax     | bmp-qconnect-service-ctle2e.pcfmrnctl.dev.intranet/bsi/qConnect |
| Operation Name | /retrieveCustomerDataForActivation                              |

### Required Parameters

| Parameter              | Description  |
|:-----------------------|:-------------|
| Each Request Attribute | Is mandatory |
|                        |              |
|                        |              |

Operation Details (Request/Response)
------------------------------------

    API: /retrieveCustomerDataForActivation

Request 
=======
```sh
{
  "ban": 413132184,
  "username": "mnklmono",
  "productAttributes": [
    {
      "name": "MACID",
      "value": "00-14-22-01-23-45"
    }
  ],
  "wtn": 5089693645
}
```

Response 
========
```sh
{
  "synacorId": "CTL0012345",
  "userInfo": {
    "wtn": "5089693645",
    "userName": "mnklmono",
    "password": "khojklmno"
  },
  "billingInfo": {
    "ban": 413132184,
    "accountPIN": 2338,
    "accountName": [
      {
        "lastBusinessName": "CONTINGENT",
        "firstName": "JOHN"
      }
    ],
    "ssn": 5896,
    "accountType": "I",
    "accountAddress": [
      {
        "addressAttention": "COMCAST-PRODUCTION",
        "addressId": 976206433,
        "addressRouteNumber": "",
        "addressType": "P",
        "boxNo": 578,
        "city": "EL PASO",
        "country": "USA",
        "houseNo": 500,
        "href": "string",
        "primaryLine": "P.O. BOX 981822",
        "secondaryLine": "COMCAST MEDIA PROCESSING CENTER",
        "state": "TX",
        "streetDirection": "E",
        "streetName": "ROGER ST",
        "streetType": "string",
        "trailingDirection": "",
        "unitNo": "APT 2",
        "unitType": "BLDG",
        "zip": 65988,
        "zip4": 6598
      }
    ],
    "submarket": "B2608",
    "accountStatus": "O"
  },
  "customerInfo": {
    "contactMediumProfileInfo": [
      {
        "contactMediumType": "EMAIL",
        "contactMediumValue": "mailme@mail.com"
      }
    ]
  },
  "serviceRegistry": {
    "serviceRegistryData": [
      {
        "customerServiceId": "CSID-856975011138855__1",
        "customerServiceOrderNumber": "CSNO-856975011138855",
        "customerOrderNumber": "CON-20171020095913844",
        "parentCustomerServiceId": "",
        "allowMACD": "Y",
        "disconnectDate": "",
        "holdStartDate": "",
        "holdEndDate": "",
        "tn": 4023930337,
        "billingOrderReference": 1000016903,
        "orderType": "NEWINSTALL",
        "supType": "",
        "productAttributes": [
          {
            "name": "MACID",
            "value": "00-14-22-01-23-45"
          }
        ],
        "provisioningAccountId": 4023930337,
        "version": 1,
        "provisioningServiceOrder": [
          {
            "provisioningServiceOrderReference": "CSPR-22015091940944630__1"
          }
        ],
        "provisioningChannel": "TOM",
        "serviceStatus": "ACTIVE",
        "bmserviceRegistryObject": "",
        "rfsId": "HSI-20M-2M-ADSL2-PB",
        "date": "2018-07-17T12:02:56.950Z",
        "lastUpdate": "2018-07-17T12:02:56.950Z",
        "oldCustomerServiceId": "",
        "dueDate": "2018-07-17T12:02:56.950Z",
        "dueDateChangeDescription": "",
        "dueDateChangeReasonCode": "",
        "activationDate": "2018-07-17T12:02:56.950Z",
        "disconnectDescription": "",
        "disconnectReasonCode": "",
        "cancellationDate": "",
        "cancellationDescription": "",
        "cancellationReasonCode": "",
        "serviceAddress": [
          {
            "streetAddress": "918 N ROYER ST",
            "postCodeSuffix": "2385",
            "streetNrLast": null,
            "streetNrLastSuffix": null,
            "streetName": "N ROYER",
            "streetType": "ST",
            "locality": "COLORADO SPRINGS",
            "city": "COLORADO SPRINGS",
            "stateOrProvince": "CO",
            "postCode": "80903",
            "country": "USA",
            "subAddress": {
              "sourceId": "CLSPCOMA1NT9V.1",
              "source": "LFACS",
              "geoSubAddressId": 1,
              "combinedDesignator": "BLDG 1",
              "elements": [
                {
                  "designator": "APT",
                  "value": 2
                }
              ]
            },
            "addressId": "CLSPCOMA16ACF",
            "streetNrFirst": "918",
            "streetNrFirstSuffix": null,
            "sourceId": "CLSPCOMA16ACF",
            "source": "LFACS",
            "geoAddressId": "213702098",
            "geoPoint": [
              {
                "source": "Trillium",
                "latitude": 38.84703,
                "longitude": -104.814561,
                "coordinateLevel": 1,
                "accuracy": 1
              }
            ],
            "npaNxxList": [
              {
                "npa": {
                  "code": 303
                },
                "nxx": {
                  "code": 291
                }
              }
            ],
            "locationAttributes": {
              "isMdu": true,
              "legacyProvider": "QWEST COMMUNICATIONS",
              "rateCenter": "COLORDOSPG",
              "npa": 318,
              "nxx": 340,
              "wirecenter": "CLSPCOMA",
              "cala": "SCO",
              "tarCode": "NV0200",
              "tta": 471
            },
            "timeZone": {
              "name": "US Mountain Standard Time",
              "ianaName": "America/Denver",
              "isDaylightSavingsTime": false,
              "offset": -7
            }
          }
        ],
        "productOfferId": 12377,
        "offerType": "P4L",
        "name": "string",
        "contractTerm": 0,
        "quantity": 1,
        "productId": 35829,
        "productName": "HSI Upto 20 Mbps/1.5 Mbps",
        "productOfferingAssociations": [
          {
            "productOfferingAssociationType": "COMPATIBLE",
            "productOfferings": [
              {
                "productOfferingId": "string"
              }
            ]
          }
        ],
        "BAN": 472246403
      }
    ],
    "billingOrder": [
      {
        "href": "",
        "TransactionDetails": {
          "href": "",
          "sourceSystem": "BLUE MARBLE",
          "transactionId": "TR-20180622064139918",
          "transactionDate": "2018-07-17T12:02:56.951Z",
          "environment": "E2E",
          "operatorId": 1054193
        },
        "ProductList": {
          "href": "",
          "productArr": [
            {
              "href": "",
              "action": "NI",
              "isBundle": false,
              "prodEffectiveDate": "string",
              "activityDate": "string",
              "productDetails": {
                "href": "",
                "ban": 472246403,
                "orderNo": "1000016903",
                "productId": "4722464030001",
                "statusActivityCode": "",
                "statusReasonCode": "",
                "productType": "QW",
                "productSubType": "",
                "winBack": "DEFAULT",
                "tnType": "",
                "subMarketCode": "B2608",
                "csrId": 1054193
              },
              "ProductConfig": {
                "href": "",
                "PicConfig": {
                  "href": "",
                  "interLata": {
                    "href": "",
                    "cicType": "string",
                    "cicCode": "string",
                    "cicEffectiveDate": "2018-07-17T12:02:56.952Z",
                    "cicExpirationDate": "2018-07-17T12:02:56.952Z",
                    "cicFreezInd": "string",
                    "cicSource": "string",
                    "cicInd": "string"
                  },
                  "intraLata": {
                    "href": "",
                    "cicType": "string",
                    "cicCode": "string",
                    "cicEffectiveDate": "2018-07-17T12:02:56.952Z",
                    "cicExpirationDate": "2018-07-17T12:02:56.952Z",
                    "cicFreezInd": "string",
                    "cicSource": "string",
                    "cicInd": "string"
                  },
                  "international": {
                    "href": "",
                    "cicType": "string",
                    "cicCode": "string",
                    "cicEffectiveDate": "2018-07-17T12:02:56.952Z",
                    "cicExpirationDate": "2018-07-17T12:02:56.952Z",
                    "cicFreezInd": "string",
                    "cicSource": "string",
                    "cicInd": "string"
                  }
                },
                "LifeLineConfig": {
                  "href": "",
                  "firstName": "string",
                  "lastName": "string",
                  "linkupSvcDate": "2018-07-17T12:02:56.952Z",
                  "effectiveDate": "2018-07-17T12:02:56.952Z",
                  "effectiveIssueDate": "2018-07-17T12:02:56.952Z",
                  "expirationDate": "2018-07-17T12:02:56.952Z",
                  "iehCertDate": "2018-07-17T12:02:56.952Z",
                  "anniversaryDate": "2018-07-17T12:02:56.952Z",
                  "acpInd": "string",
                  "ruralInd": "string",
                  "stateInd": "string",
                  "tribalInd": "string",
                  "federalInd": "string",
                  "qualProd": "string",
                  "caseNo": "string"
                },
                "genericConfig": [
                  {
                    "href": "",
                    "keyCategory": "",
                    "keyName": "",
                    "keyValue": ""
                  }
                ]
              },
              "Charges": {
                "charge": [
                  {
                    "chargeCreationDate": "2018-06-22",
                    "chargeGroupLevel": "P",
                    "statusActvCode": "",
                    "statusActvReasonCode": "",
                    "effectiveDate": "2018-06-22",
                    "featureCode": "1134I",
                    "financeEffectiveDate": "2018-06-22",
                    "numberOfInstallment": 1,
                    "pricePlan": "INEJA178B",
                    "quantity": 1,
                    "chargeType": "ONE_TIME",
                    "chargeAmount": 10
                  }
                ]
              },
              "BillingComponents": {
                "href": "",
                "PPList": [
                  {
                    "href": "",
                    "pricePlanCode": "INEJA126B",
                    "ppEffectiveDate": "2018-06-22",
                    "expirationDate": "",
                    "dealerCode": 1054193,
                    "FeatureList": [
                      {
                        "href": "",
                        "featureCode": "JB126A",
                        "ftrEffectiveDate": "2018-06-22",
                        "ftrEffectiveReasonCode": "",
                        "ftrExpirationDate": "2018-06-22",
                        "ftrExpirationReasonCode": "",
                        "ftrQty": 1,
                        "dealerCode": 1054193,
                        "vpRate": 0,
                        "Bundle": {
                          "href": "",
                          "bundleCode": "87AQ",
                          "bundleSequenceId": 1
                        }
                      }
                    ]
                  }
                ]
              },
              "contracts": {
                "href": "string",
                "contractName": "string",
                "contractNo": "string",
                "contractType": "string",
                "contractLvl": "string",
                "effectiveDate": "2018-07-17T12:02:56.952Z",
                "startDate": "2018-07-17T12:02:56.952Z",
                "endDate": "2018-07-17T12:02:56.952Z",
                "term": 0,
                "cntSeqNo": "string",
                "applicationId": "string",
                "pricePlan": "string",
                "featureCode": "string",
                "nodeId": "string",
                "commitReasonCd": "string",
                "commitOrigNoMonth": "string",
                "dealerCode": "string",
                "lstComSplitDlr": "string",
                "paperWorkStatus": "string",
                "paperWorkRequired": "string",
                "paperWorkDate": "2018-07-17T12:02:56.952Z",
                "paperWorkRefNo": "string",
                "paperWorkTrnsNo": "string",
                "subActvLocation": "string",
                "ixcCode": "string",
                "ixcEffectiveDate": "2018-07-17T12:02:56.952Z",
                "ixcChgDlrCd": "string",
                "ixcChgDlrSpltCd": "string",
                "cntExpDate": "2018-07-17T12:02:56.952Z",
                "contractLocation": "string",
                "penaltyInd": "string",
                "productVersion": "string",
                "ppSeqNo": "string",
                "omOrderId": "string",
                "omcntGroupId": "string",
                "saUniqueId": "string",
                "sysCreationDate": "2018-07-17T12:02:56.952Z",
                "sysUpdateDate": "2018-07-17T12:02:56.952Z",
                "dlserviceCode": "string",
                "dlUpdateStamp": "string"
              },
              "discounts": [
                {
                  "href": "string",
                  "discountCode": "string",
                  "startDate": "2018-07-17T12:02:56.952Z",
                  "endDate": "2018-07-17T12:02:56.952Z"
                }
              ],
              "deposits": [
                {
                  "href": "string",
                  "serviceGroup": "string",
                  "subServiceGroup": "string",
                  "depositAmount": 0,
                  "noOfInstallment": 0
                }
              ],
              "directoryListing": [
                {
                  "href": "string"
                }
              ],
              "address": [
                {
                  "href": "string",
                  "addressId": 976206433,
                  "addressType": "P",
                  "houseNo": 500,
                  "streetDirection": "E",
                  "streetName": "ROGER ST",
                  "streetType": "string",
                  "trailingDirection": "",
                  "unitNo": "APT 2",
                  "unitType": "BLDG",
                  "linkType": "string",
                  "primaryLine": "P.O. BOX 981822",
                  "secondaryLine": "COMCAST MEDIA PROCESSING CENTER",
                  "city": "EL PASO",
                  "country": "USA",
                  "state": "TX",
                  "zip": 65988,
                  "zip4": 6598,
                  "addressRouteNumber": "",
                  "addressAttention": "COMCAST-PRODUCTION",
                  "boxNo": 578
                }
              ],
              "name": [
                {
                  "href": "string",
                  "nameId": 0,
                  "firstName": "string",
                  "middleName": "string",
                  "lastBusinessName": "string",
                  "title": "string",
                  "generation": "string",
                  "nameType": "string",
                  "nameFormat": "string",
                  "additionalTitle": "string",
                  "unfieldName1": "string",
                  "unfieldName2": "string",
                  "unfieldName3": "string",
                  "convrunNo": 0
                }
              ]
            }
          ]
        }
      }
    ]
  }
}
```

Error Response 
==============
```sh
{
  "errorResponse": {
    "errorObject": [
      {
        "reasonCode": "BM_SERVER_ERROR",
        "message": "SUCCESS",
        "messageDetail": "Please retry after some time",
        "timestamp": "2018-07-17T12:02:56.972Z"
      }
    ],
```


| HTTP Status Code (BM) | BM Reason Code         | Message Text                      |
|:----------------------|:-----------------------|:----------------------------------|
| 401                   | AUTHENTICATION_FAILURE | Authentication failed due to invalid authentication credential. |
| 403                   | SERVICE_UNAVAILABLE    | Forbidden                                                       |
| 404                   | RESOURCE_NOT_FOUND     | Service Not Found                                               |
| 500                   | BM_SERVER_ERROR        | Internal Server Error                                           |


[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>