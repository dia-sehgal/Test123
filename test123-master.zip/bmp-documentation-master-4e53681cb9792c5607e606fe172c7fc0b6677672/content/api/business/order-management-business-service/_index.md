---
title: "Order Management"
date: 2018-07-17T09:51:24-07:00
draft: false
---

Order management business service is a micro service that comes into act in the order journey of Blue Marble taking part in both Order Checkout and Order Management flow. It acts as a gateway between OC and OM systems of blue marble.

## Sections
* [Swagger Specification](#swagger-specification)
* [Authentication Details](#authentication-details)
* [Dependencies](#dependencies)
  - [MongoDB](#mongodb)
  - [PCF Services](#pcf-services)
  - [BM Processes Using](#bm-processes-using)
  - [Downstream Services](#downstream-services)
* [MAL/Cloud Org](#mal-cloud-org)
* [Developer Installation](#developer-installation)
* [Setup](#setup)
* [CI/CD Pipeline Details](#ci-cd-pipeline-details)
* [Cloud Environment Details](#cloud-environment-details)
* [Splunk Dashboard](#splunk-dashboard)
* [Resources/Operations](#resources-operations)
* [Links](#links)



## Swagger Specification
{{< oai-spec url="https://bmp-documentation.pcfmrnctl.dev.intranet/api/business/order-management-business-service/files/api-docs.json" >}}

## Authentication Details
Access is granted based on membership to the following LDAP groups:

## Dependencies
### MongoDB
* BMP_ORDERMGMT_* database

### PCF Services
* Name: bmp-mongodb-order-management-bs
* URL: mongodb://BMP_dba:BMP_dba_ctl123@vlmddmong03.dev.intranet:11000/BMP_ORDERMGMT_1?readPreference=secondaryPreferred&authSource=admin&minPoolSize=2

### BM Processes Using
* bmp-order-management-process

### Downstream Services
* bmp-ds-service-translation
{{<mermaid align="left">}}
graph TD;
    A[bmp-order-management-process] --> B[bmp-ds-service-translation]
    B --> C[MongoDB]
{{< /mermaid >}}
* bmp-tom-orchestrator-business-service
{{<mermaid align="left">}}
graph TD;
    A[bmp-order-management-process] --> B[bmp-tom-orchestrator-business-service]
{{< /mermaid >}}
* bmp-order-decomposition-business-service
* bmp-service-registry-business-service
* bmp-service-availability-business-service
* bmp-orderdecomposition-macdflag-rule-service
* bmp-order-status-update-business-service
* bmp-jeopardy-business-service
* bmp-order-business-service-checkout
* bmp-equipment-management-service
* bmp-numberporting-business-service

{{<mermaid align="left">}}
graph TD;
    A[BM TN Mgmt] --> B[CGS TN Mgmt]
    B --> H{TN Type}
    H -->|POTS| C{Territory}
    H -->|VOIP| J[BVOIPSVC]
    J --> K[CNUM National]
    C -->|L-C| D[CWS/ENJ]
    C -->|L-Q| E[SIA]
    E --> F[CNUM Local]
    D --> G[Martens]
{{< /mermaid >}}


## MAL/Cloud Org
BMOM

## Developer Installation
* It requires maven to be installed locally.
* Add Oracle JDBC driver in your Maven local repository
 - Visit [Oracle] website to get the Oracle JDBC driver - ojdbc6.jar or ojdbc7.jar
 - mvn install:install-file -Dfile={Path/to/your/ojdbc7.jar} -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0 -Dpackaging=jar

## SetUp
```sh
git clone git@NE1ITCPRHAS62.ne1.savvis.net:BMP_DEV/order-management-business-service.git
```
```sh
mvn clean install
```
```sh
mvn spring-boot:run
```

## CI/CD Pipeline Details :
* Name:	 bmp-order-management-business-service
* Sonarqube URL:	 http://vlodphpn001.corp.intranet:9000
* Sonarqube Project URL:	 TBD
* Pipeline Tool:	 Gitlab CI
* Pipeline URL:	 TBD

## Cloud Environment Details
* Cloud Group Name:	 BMOM-TM-MnonProd
* Cloud Environment Project URL:	 https://bmp-order-management-business-service-test3.pcfmrnctl.dev.intranet

* Cloud Environment Space:	 test3
* Cloud Environment URL:	 https://apps.pcfmrnctl.dev.intranet/

# Splunk Dashboard
* http://search.splunk-it.corp.intranet:8000/en-US/app/bmp_devops/dashboards

# Swagger URL :
```sh
https://bmp-order-management-business-service-test3.pcfmrnctl.dev.intranet
```

# Sample Request for Post(Order Decomposition):
```sh
{
    
    "orderReference" : {
        "customerOrderNumber" : "1000008087",
        "customerOrderStatus" : "COMPLETED",
        "customerOrderType" : "NEWINSTALL",
        "customerSegment" : "Regular",
        "customerType" : "INDIVIDUAL",
        "orderDate" : "2018-06-07T09:54:48.651Z",
        "orderReferenceNumber" : "ORN-12938405885697758",
        "orderVersion" : "1",
        "partyRole" : {
            "partyRoleId" : "CSR456",
            "partyRoleName" : "CSR",
            "partyCsrId" : "1054193"
        },
        "pointOfNoReturn" : true,
        "processInstanceId" : "3106254",
        "salesChannel" : "ESHOP-Customer Care",
        "sfdcAccountId" : "",
        "sourceSystem" : "BLUE MARBLE"
    },
    "orderDocument" : {
        "serviceAddress" : {
            "addressId" : "",
            "streetAddress" : "2366 PRIMO RD",
            "streetNrFirst" : "2366",
            "streetNrFirstSuffix" : "",
            "streetNrLast" : "",
            "streetNrLastSuffix" : "",
            "streetName" : "PRIMO RD",
            "streetType" : "",
            "locality" : "HIGHLANDS RANCH",
            "city" : "HIGHLANDS RANCH",
            "stateOrProvince" : "CO",
            "postCode" : "80129",
            "postCodeSuffix" : "",
            "sourceId" : "LTTNCOHL15RUK.8",
            "source" : "LFACS",
            "geoAddressId" : "238668185",
            "subAddress" : {
                "combinedDesignator" : "",
                "elements" : [],
                "geoSubAddressId" : "",
                "source" : "",
                "sourceId" : ""
            },
            "country" : "USA",
            "geoPoint" : [ 
                {
                    "accuracy" : "1",
                    "coordinateLevel" : "1",
                    "latitude" : 39.564487,
                    "longitude" : -105.017309,
                    "source" : "Trillium"
                }
            ],
            "locationAttributes" : {
                "isMdu" : true,
                "legacyProvider" : "QWEST COMMUNICATIONS",
                "rateCenter" : "DENVER",
                "wirecenter" : "LTTNCOHL",
                "npa" : "303",
                "nxx" : "791",
                "tta" : "791",
                "tarCode" : "CO1890",
                "cala" : "DNV"
            },
            "timeZone" : {
                "ianaName" : "America/Denver",
                "isDaylightSavingsTime" : true,
                "name" : "Mountain Standard Time",
                "offset" : "-6"
            },
            "npaNxxList" : [ 
                {
                    "npa" : {
                        "code" : "720"
                    },
                    "nxx" : {
                        "code" : "516"
                    }
                }, 
                {
                    "npa" : {
                        "code" : "303"
                    },
                    "nxx" : {
                        "code" : "683"
                    }
                }, 
                {
                    "npa" : {
                        "code" : "303"
                    },
                    "nxx" : {
                        "code" : "346"
                    }
                }, 
                {
                    "npa" : {
                        "code" : "303"
                    },
                    "nxx" : {
                        "code" : "471"
                    }
                }, 
                {
                    "npa" : {
                        "code" : "720"
                    },
                    "nxx" : {
                        "code" : "344"
                    }
                }, 
                {
                    "npa" : {
                        "code" : "720"
                    },
                    "nxx" : {
                        "code" : "348"
                    }
                }, 
                {
                    "npa" : {
                        "code" : "303"
                    },
                    "nxx" : {
                        "code" : "470"
                    }
                }, 
                {
                    "npa" : {
                        "code" : "303"
                   },
                    "nxx" : {
                        "code" : "791"
                    }
                }
            ]
        },
        "existingServiceAddress" : {
            "subAddress" : {
                "elements" : []
            },
            "geoPoint" : [],
            "locationAttributes" : {
                "isMdu" : false
            },
            "timeZone" : {},
            "npaNxxList" : []
        },
        "availableServices" : [ 
            {
                "accessType" : "VDSL2-PB",
                "serviceCategory" : "DATA",
                "networkInfrastructureIndicatorCode" : "FTTN-ETH-V2-PB",
                "qualificationColorName" : "GREEN",
                "offerCategory" : "INTERNET",
                "processInfo" : [ 
                    {
                        "processInfoGroupName" : "RT_DISPATCH",
                        "processInfoAttribute" : [ 
                            {
                                "name" : "REQUIRED",
                                "value" : "true"
                            }
                        ]
                    }
                ]
            }
        ],
        "dhpAdditionalInfo" : {},
        "customerOrderItems" : [ 
            {
                "action" : "ADD",
                "catalogId" : "1056857",
                "contractTerm" : "0",
                "customerOrderSubItems" : [ 
                    {
                        "quantity" : 1,
                        "productId" : "35762",
                        "productName" : "HSI Upto 60 Mbps/5 Mbps",
                        "action" : "ADD",
                        "productType" : "INTERNET",
                        "componentType" : "PRIMARY",
                        "productCategory" : "CORE",
                        "productAssociations" : [],
                        "productAttributes" : [ 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Product Sub-Type",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Ensemble Product Type",
                                        "attributeValue" : "QW",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "IsPrimary",
                                        "attributeValue" : "ADDON",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "ProductActivationDate",
                                        "attributeValue" : "2018-06-12T11:59:59.059Z",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Derived Upspeed",
                                        "attributeValue" : "0 - 5",
                                        "uom" : "Mbps"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "allowMACD",
                                        "attributeValue" : "Y",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Transport Medium",
                                        "attributeValue" : "Optical Fiber Network",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Max Quantity",
                                        "attributeValue" : "1",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Derived DownSpeed",
                                        "attributeValue" : "0 - 60",
                                        "uom" : "Mbps"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Service Group",
                                        "attributeValue" : "HSI",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Sub Service Group",
                                        "attributeValue" : "SRV",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "ProductDisconnectDate",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "prismSupported",
                                        "attributeValue" : "false"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "dhpSupported",
                                        "attributeValue" : "true"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "hpSupported",
                                        "attributeValue" : "true"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "prismSupported",
                                        "attributeValue" : "false"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "dhpSupported",
                                        "attributeValue" : "true"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "hpSupported",
                                        "attributeValue" : "true"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 38.01,
                                        "otc" : 0.0,
                                        "rc" : 38.01,
                                        "priceTypeDescription" : "MRC/OTC",
                                        "priceKey" : "1056857~1056857~12352~HSI Upto 60 Mbps/5 Mbps~Technology=NONE"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Technology",
                                        "attributeValue" : "VDSL2-PB"
                                    }, 
                                    {
                                        "attributeName" : "Downspeed",
                                        "attributeValue" : "65472"
                                    }, 
                                    {
                                        "attributeName" : "Upspeed",
                                        "attributeValue" : "5504"
                                    }, 
                                    {
                                        "attributeName" : "Downspeed",
                                        "attributeValue" : "60128"
                                    }, 
                                    {
                                        "attributeName" : "Upspeed",
                                        "attributeValue" : "30144"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "serviceIdentifier",
                                        "attributeValue" : "4722037200001"
                                    }
                                ]
                            }
                        ]
                    }, 
                    {
                        "quantity" : 1,
                        "productId" : "35803",
                        "productName" : "MODEM",
                        "action" : "ADD",
                        "productType" : "INTERNET",
                        "componentType" : "COMPONENT",
                        "productCategory" : "EQP",
                        "productAssociations" : [],
                        "productAttributes" : [ 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 10.0,
                                        "otc" : 0.0,
                                        "rc" : 10.0,
                                        "priceTypeDescription" : "MRC/OTC",
                                        "priceKey" : "1056857~1056857~12352~MODEM~Account Type=LEASE::MODEM CLASS=PREMIUM"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "MODEM CLASS",
                                        "attributeValue" : "PREMIUM"
                                    }, 
                                    {
                                        "attributeName" : "Account Type",
                                        "attributeValue" : "LEASE"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "allowMACD",
                                        "attributeValue" : "Y"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "productActivationDate",
                                        "attributeValue" : "2018-06-12T11:59:59.059Z"
                                    }
                                ]
                            }
                        ]
                    }, 
                    {
                        "quantity" : 1,
                        "productId" : "35863",
                        "productName" : "TECH INSTALL",
                        "action" : "ADD",
                        "productType" : "INTERNET",
                        "componentType" : "COMPONENT",
                        "productCategory" : "TECHINST",
                        "productAssociations" : [],
                        "productAttributes" : [ 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 60.0,
                                        "discountedRc" : 0.0,
                                        "otc" : 60.0,
                                        "rc" : 0.0,
                                        "priceTypeDescription" : "MRC/OTC",
                                        "priceKey" : "1056857~1056857~12352~TECH INSTALL~Service Level=STANDARD"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Service Level",
                                        "attributeValue" : "Standard",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "allowMACD",
                                        "attributeValue" : "N"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "productActivationDate",
                                        "attributeValue" : "2018-06-12T11:59:59.059Z"
                                    }
                                ]
                            }
                        ]
                    }, 
                    {
                        "quantity" : 1,
                        "productId" : "35844",
                        "productName" : "CENTURYLINK @ EASE",
                        "action" : "ADD",
                        "productType" : "INTERNET",
                        "componentType" : "COMPONENT",
                        "productCategory" : "VAS",
                        "productAssociations" : [],
                        "productAttributes" : [ 
                            {
                                "isDefault" : 2,
                                "displayOrder" : 2,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 9.99,
                                        "otc" : 0.0,
                                        "rc" : 9.99,
                                        "priceTypeDescription" : "MRC/OTC",
                                        "priceKey" : "1056857~1056857~12352~CENTURYLINK @ EASE~Service Level=STANDARD"
                                    }, 
                                    {
                                        "priceType" : "INCLUDED",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 3.88,
                                        "otc" : 0.0,
                                        "rc" : 3.88,
                                        "priceTypeDescription" : "PC Protection Plan",
                                        "priceKey" : "1056857~1056857~12352~CENTURYLINK @ EASE~Service Level=STANDARD"
                                    }, 
                                    {
                                        "priceType" : "INCLUDED",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 0.44,
                                        "otc" : 0.0,
                                        "rc" : 0.44,
                                        "priceTypeDescription" : "Online Backup (5GB)",
                                        "priceKey" : "1056857~1056857~12352~CENTURYLINK @ EASE~Service Level=STANDARD"
                                    }, 
                                    {
                                        "priceType" : "INCLUDED",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 4.45,
                                        "otc" : 0.0,
                                        "rc" : 4.45,
                                        "priceTypeDescription" : "PC Support Services (Level I)",
                                        "priceKey" : "1056857~1056857~12352~CENTURYLINK @ EASE~Service Level=STANDARD"
                                    }, 
                                    {
                                        "priceType" : "INCLUDED",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 1.22,
                                        "otc" : 0.0,
                                        "rc" : 1.22,
                                        "priceTypeDescription" : "Desktop Security",
                                        "priceKey" : "1056857~1056857~12352~CENTURYLINK @ EASE~Service Level=STANDARD"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Service Level",
                                        "attributeValue" : "Standard",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "allowMACD",
                                        "attributeValue" : "Y"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "productActivationDate",
                                        "attributeValue" : "2018-06-12T11:59:59.059Z"
                                    }
                                ]
                            }
                        ]
                    }, 
                    {
                        "quantity" : 1,
                        "productId" : "35705",
                        "productName" : "Jack and Wire",
                        "action" : "ADD",
                        "productType" : "VOICE-HP",
                        "componentType" : "COMPONENT",
                        "productCategory" : "OPT-EQP-CORE",
                        "productAssociations" : [],
                        "productAttributes" : [ 
                            {
                                "isDefault" : 1,
                                "displayOrder" : 1,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 0.0,
                                        "otc" : 0.0,
                                        "rc" : 0.0,
                                        "priceTypeDescription" : "MRC/NRC",
                                        "priceKey" : "1056857~1056857~12352~Jack and Wire~Installation Number=No work is needed"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Installation Number",
                                        "attributeValue" : "No work is needed"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "allowMACD",
                                        "attributeValue" : "Y"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "productActivationDate",
                                        "attributeValue" : "2018-06-12T11:59:59.059Z"
                                    }
                                ]
                            }
                        ]
                    }, 
                    {
                        "quantity" : 1,
                        "productId" : "35703",
                        "productName" : "ISP",
                        "action" : "ADD",
                        "productType" : "INTERNET",
                        "componentType" : "COMPONENT",
                        "productCategory" : "CORE",
                        "productAssociations" : [],
                        "productAttributes" : [ 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Vendor",
                                        "attributeValue" : "CenturyLink",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Number of Mailboxes",
                                        "attributeValue" : "2",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 1,
                                "displayOrder" : 1,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Number of Mailboxes",
                                        "attributeValue" : "10",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 2,
                                "displayOrder" : 2,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Number of Mailboxes",
                                        "attributeValue" : "11",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 16.99,
                                        "otc" : 0.0,
                                        "rc" : 16.99,
                                        "priceTypeDescription" : "MRC/OTC",
                                        "priceKey" : "1056857~1056857~12352~ISP~No of MailBoxes=10"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "No of MailBoxes",
                                        "attributeValue" : "10"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 0.0,
                                        "discountedRc" : 16.99,
                                        "otc" : 0.0,
                                        "rc" : 16.99,
                                        "priceTypeDescription" : "MRC/OTC",
                                        "priceKey" : "1056857~1056857~12352~ISP~No of MailBoxes=11"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "No of MailBoxes",
                                        "attributeValue" : "11"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "allowMACD",
                                        "attributeValue" : "N"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "productActivationDate",
                                        "attributeValue" : "2018-06-12T11:59:59.059Z"
                                    }
                                ]
                            }
                        ]
                    }
                ],
                "discountedOtc" : 0.0,
                "discountedRc" : 0.0,
                "offerCategory" : "INTERNET",
                "offerSubType" : "REGULAR",
                "offerType" : "P4L",
                "otc" : 0.0,
                "productOfferingId" : "12352",
                "quantity" : 1,
                "rc" : 55.0,
                "contractStartDate" : "2018-06-12T11:59:59.059Z"
            }, 
            {
                "action" : "ADD",
                "catalogId" : "1056857",
                "contractTerm" : "0",
                "customerOrderSubItems" : [ 
                    {
                        "quantity" : 1,
                        "productId" : "35728",
                        "productName" : "DSL Wall-Mount Filter",
                        "action" : "ADD",
                        "productType" : "INTERNET",
                        "componentType" : "COMPONENT",
                        "productCategory" : "OPT-EQP",
                        "productAssociations" : [],
                        "productAttributes" : [ 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : true,
                                "prices" : [ 
                                    {
                                        "priceType" : "PRICE",
                                        "frequency" : "1",
                                        "currencyCode" : "USD",
                                        "discountedOtc" : 5.0,
                                        "discountedRc" : 0.0,
                                        "otc" : 5.0,
                                        "rc" : 0.0,
                                        "priceTypeDescription" : "MRC/OTC",
                                        "priceKey" : "1056857~1056857~12349~DSL Wall-Mount Filter"
                                    }
                                ],
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Ensemble Product Type",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "ProductDisconnectDate",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Type",
                                        "attributeValue" : "Wall-Mount",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Product Sub-Type",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Max Quantity",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "ProductActivationDate",
                                        "attributeValue" : "2018-06-12T11:59:59.059Z",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Service Group",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "allowMACD",
                                        "attributeValue" : "N",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Sub Service Group",
                                        "attributeValue" : "",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Shipping Method",
                                        "attributeValue" : "ADVANCED",
                                        "uom" : "NA"
                                    }
                                ]
                            }, 
                            {
                                "isDefault" : 0,
                                "displayOrder" : 0,
                                "isPriceable" : false,
                                "compositeAttribute" : [ 
                                    {
                                        "attributeName" : "Shipping Method",
                                        "attributeValue" : "PREMIUM",
                                        "uom" : "NA"
                                    }
                                ]
                            }
                        ]
                    }
                ],
                "discountedOtc" : 0.0,
                "discountedRc" : 0.0,
                "offerCategory" : "INTERNET",
                "offerSubType" : "REGULAR",
                "offerType" : "SUBOFFER",
                "otc" : 0.0,
                "productOfferingId" : "12349",
                "quantity" : 1,
                "rc" : 0.0
            }
        ],
        "reservedTN" : [ 
            {
                "requestedTelephoneNumber" : "3034714862",
                "tnType" : "DEFAULTED",
                "workingTN" : "NO",
                "productType" : "INTERNET"
            }
        ],
        "productConfiguration" : [ 
            {
                "productType" : "INTERNET",
                "configItems" : [ 
                    {
                        "productId" : "",
                        "productName" : "TECH INSTALL",
                        "configDetails" : [ 
                            {
                                "isConfigRequired" : false,
                                "formName" : "Devices",
                                "formItems" : [ 
                                    {
                                        "attributeName" : "Quantity",
                                        "attributeType" : "LOV",
                                        "isMandatory" : false,
                                        "attributeValue" : [ 
                                            {
                                                "value" : "1 device",
                                                "isDefault" : true
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ],
        "existingProductConfiguration" : [],
        "accountInfo" : {
            "isBillAddrSameAsServiceAddress" : false,
            "accountName" : {
                "firstName" : "James",
                "lastName" : "Ahmer",
                "middleName" : "",
                "title" : ""
            },
            "accountPin" : "2538",
            "accountSubType" : "R",
            "accountType" : "I",
            "accountPreferences" : {
                "paperlessBilling" : true,
                "spanishBillPrint" : false,
                "noTeleMarketing" : false,
                "noEmail" : false,
                "noDirectMail" : false,
                "braille" : false,
                "largePrint" : false,
                "emailNotification" : {
                    "billingNotification" : true,
                    "orderingNotification" : true,
                    "repairNotification" : true
                },
                "textNotification" : {
                    "billingNotification" : true,
                    "orderingNotification" : true,
                    "repairNotification" : true
                }
            },
            "ban" : "472203720",
            "billCycle" : 17,
            "billingAddress" : {
                "isValidated" : false,
                "streetAddress" : "2366 PRIMO RD",
                "streetNrFirstSuffix" : "",
                "streetNrFirst" : "2366",
                "streetName" : "PRIMO RD",
                "streetType" : "",
                "city" : "HIGHLANDS RANCH",
                "locality" : "HIGHLANDS RANCH",
                "stateOrProvince" : "CO",
                "postCode" : "80129",
                "country" : "USA",
                "subAddress" : {
                    "combinedDesignator" : "",
                    "elements" : [],
                    "geoSubAddressId" : "",
                    "source" : "",
                    "sourceId" : ""
                }
            },
            "contact" : {
                "contactNumber" : "2507654513",
                "smsNumber" : "2508798465",
                "emailAddress" : "Jsmes@ctl.com",
                "emailAddrDeclined" : false
            },
            "creditClass" : "1",
            "personalDetails" : {
                "dateOfBirth" : "1987-12-12",
                "ssn" : "666150907",
                "creditCheck" : true,
                "underAgeAck" : false
            },
            "billingAdditionalInfo" : ""
        },
        "creditReview" : {
            "creditInfo" : {
                "finalBillInfo" : [],
                "creditClass" : "1",
                "finalBillInd" : false
            },
            "creditApplicationRefNumber" : "01000003662564",
            "depositInfo" : {
                "depositRequired" : false,
                "products" : []
            },
            "paymentInfo" : [],
            "billEstimate" : {
                "quote" : [ 
                    {
                        "quoteId" : "64587628"
                    }
                ]
            }
        },
        "schedule" : {
            "appointmentInfo" : {
                "appointmentId" : "WRL7PKMQ",
                "commitmentDateTime" : "2018-06-12T19:45:00.000Z",
                "reservationId" : "WRL7PKMQ01",
                "timeSlot" : {
                    "startDateTime" : "2018-06-12T08:00:00.000Z",
                    "endDateTime" : "2018-06-12T18:00:00.000Z"
                },
                "timeSlotSource" : "EOS",
                "timeSlotType" : "TI-RTD"
            },
            "dates" : {
                "calculatedDueDate" : "2018-06-12T00:00:00.000Z",
                "finalDueDate" : "2018-06-12T11:59:59.059Z",
                "overrideFlag" : false,
                "isCRDAvailable" : true
            },
            "shippingInfo" : {
                "shippingAddress" : {
                    "isValidated" : false,
                    "streetAddress" : "2366 PRIMO RD",
                    "streetNrFirstSuffix" : "",
                    "streetNrFirst" : "2366",
                    "streetName" : "PRIMO RD",
                    "streetType" : "",
                    "city" : "HIGHLANDS RANCH",
                    "locality" : "HIGHLANDS RANCH",
                    "stateOrProvince" : "CO",
                    "postCode" : "80129",
                    "country" : "USA",
                    "subAddress" : {
                        "combinedDesignator" : "",
                        "elements" : [],
                        "geoSubAddressId" : "",
                        "source" : "",
                        "sourceId" : ""
                    }
                },
                "isShipAddrSameAsServiceAddress" : false
            },
            "assessmentInfo" : {
                "isAppointmentRequired" : true,
                "isShippingRequired" : true,
                "isDHPEqpShipped" : false,
                "isHSIModemShipped" : false,
                "isHSIAccessoryShipped" : true,
                "shippingCombination" : 3,
                "appointmentType" : "TI-RTD"
            },
            "apptNotes" : {
                "animalsPresent" : true,
                "electricFence" : false,
                "lockedGate" : false,
                "notes" : [ 
                    {
                        "name" : "Driving Directions",
                        "value" : ""
                    }, 
                    {
                        "name" : "Additional Comments",
                        "value" : ""
                    }, 
                    {
                        "name" : "Order Remarks",
                        "value" : "",
                        "date" : "Jun 7, 2018",
                        "author" : "James  Ahmer"
                    }
                ]
            }
        },
        "additionalInfo" : {
            "chargeSummaryAck" : true,
            "disableOrderNotification" : false
        },
        "featureDescription" : {
            "subMarketCode" : "A2883",
            "ppfcs" : [ 
                {
                    "bmProductName" : "HSI Upto 60 Mbps/5 Mbps",
                    "productType" : "QW",
                    "pricePlan" : "INEJA129B",
                    "ppEffectiveDate" : "2017-12-15 00:00:00.0",
                    "featureCode" : "JB129A",
                    "isPrimary" : true,
                    "featureDescription" : "HSI 60M/5M",
                    "recurTermFee" : "0",
                    "termFee" : "0.0",
                    "action" : "NI",
                    "term" : 0,
                    "bundleCode" : "87AQ"
                }, 
                {
                    "bmProductName" : "MODEM",
                    "productType" : "QW",
                    "pricePlan" : "INEJA183B",
                    "ppEffectiveDate" : "2018-01-05 00:00:00.0",
                    "featureCode" : "JA183B",
                    "isPrimary" : false,
                    "featureDescription" : "Prem Mdm 40_Up Lease Ship Stnd",
                    "recurTermFee" : "0",
                    "termFee" : "0.0",
                    "action" : "NI",
                    "term" : 0,
                    "bundleCode" : "87AQ"
                }, 
                {
                    "bmProductName" : "TECH INSTALL",
                    "productType" : "QW",
                    "pricePlan" : "INEJA185B",
                    "ppEffectiveDate" : "2018-01-05 00:00:00.0",
                    "featureCode" : "1134I",
                    "isPrimary" : false,
                    "featureDescription" : "Tech Installation Fee",
                   "recurTermFee" : "0",
                    "termFee" : "0.0",
                    "action" : "NI",
                    "term" : 0,
                    "bundleCode" : ""
                }, 
                {
                    "bmProductName" : "CENTURYLINK @ EASE",
                    "productType" : "QW",
                    "pricePlan" : "INETJ3912",
                    "ppEffectiveDate" : "2013-06-21 00:00:00.0",
                    "featureCode" : "J3912S",
                    "isPrimary" : false,
                    "featureDescription" : "CenturyLink at Ease Standard",
                    "recurTermFee" : "0",
                    "termFee" : "0.0",
                    "action" : "NI",
                    "term" : 0,
                    "bundleCode" : ""
                }, 
                {
                    "bmProductName" : "ISP",
                    "productType" : "QW",
                    "pricePlan" : "INEJA129B",
                    "ppEffectiveDate" : "2017-12-15 00:00:00.0",
                    "featureCode" : "JQISPQ",
                    "isPrimary" : false,
                    "featureDescription" : "High-Speed Internet Access",
                    "recurTermFee" : "0",
                    "termFee" : "0.0",
                    "action" : "NI",
                    "term" : 0,
                    "bundleCode" : "87AQ"
                }, 
                {
                    "bmProductName" : "DSL Wall-Mount Filter",
                    "productSubType" : "RM",
                    "productType" : "QW",
                    "pricePlan" : "DEFINR",
                    "featureCode" : "3667",
                    "isPrimary" : false,
                    "featureDescription" : "DSL Wall-Mount Filter",
                    "recurTermFee" : "0",
                    "termFee" : "0.0",
                    "action" : "NI",
                    "term" : 0,
                    "bundleCode" : ""
                }
            ]
        },
        "isFinalBillAddressChanged" : false,
        "returnEquipments" : [],
        "existingTN" : [],
        "addlOrderAttributes" : [ 
            {
                "orderAttributeGroup" : [ 
                    {
                        "orderAttributeGroupName" : "otcInstallmentInfo",
                        "orderAttributeGroupInfo" : [ 
                            {
                                "orderAttributes" : [ 
                                    {
                                        "orderAttributeName" : "productName",
                                        "orderAttributeValue" : "DSL Wall-Mount Filter"
                                    }, 
                                    {
                                        "orderAttributeName" : "otcAmount",
                                        "orderAttributeValue" : "5.0"
                                    }, 
                                    {
                                        "orderAttributeName" : "maxNoOfInstallment",
                                        "orderAttributeValue" : "12"
                                    }, 
                                    {
                                        "orderAttributeName" : "selectedNoOfInstallment",
                                        "orderAttributeValue" : ""
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    }
}
```

## Resources/Operations
  i) **/customerOrder/createCustomerOrder** - This API creates the customerOrder object in its DB and then initiates the init process of OM camunda.
  	   
 ii) **/customerOrder/getBMPONRStatus** - This API determines the PointOfNoReturn value to permit the ability to perform sup1/sup2 on the order.
     
 iii) **/customerOrder/CvoipPortOutDisconnect** - This API takes the CVOIP order with a disconnect request and initiates a disconnect init process of camunda.

 iv) **/customerOrder/getCustomerOrder** - This API provides the CustomerOrder object by ORN.
 
 v) **/customerOrder/getCustomerOrderByBanAndCustomerOrderNumber** - This API returns the customerOredr object by ban and customerOrderNumber.
  	   
 vi) **/customerOrder/getOrderProgressStatus** - This API provides the current of Pending order.
     
 vii) **/customerOrder/getReasonCode** - This API provides the different reasonCodes to e-shop for disconnect & sup1/sup2 scenarios.

 viii) **/customerOrder/getTelephoneNumberAndAccessType** - This API provides the telePhoneNumber and accessType to service-availability.
 
 ix) **/customerOrder/retrieveProductAndServices** - This API constructs the landing page of E-shop after order-submission and prior to making change to the order.
     
 x) **/customerOrder/updateCustomerOrderAttributes** - This API populates the allowMacd flag, product activation date & product disconnect date in the attribute level of products.

 xi) **/customerOrder/updateDueDateForTOM** - This API updates the duedate in the TOM correction scenario.

## Links
* Deployment (CI/CD) Overview 
* BM Architectural Overview
* Development Practices (ENV Setup for Localhost, etc...)
* Splunk Details (dashboard, queries, etc...)


