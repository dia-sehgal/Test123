ISST Save Sales Order
=====================
    Version: 2.0.0

| API Business Service | Version |
|:------ |:------ |
| Account Management|[v2.7.2.md]|
| Address Validation|[v3.26.0.md]|
| Appointment|[v2.20.10.md]|
| Change Order Process|[v2.0.20.md]|
| Credit Check|[v2.12.4.md]|


### Table of Contents

- [Overview](#Overview)
- [Request /ISSTsaveSalesOrder](#Request)
- [Response /ISSTsaveSalesOrder](#Response)

Overview
--------

This service is used or called to have a sales order, saved in sales tracking tool, ISST to provide an ability to track all sales orders, placed by a sales person or a dealer.

### Request Syntax

For each resource, the following items are documented.

Provide Sales Information to ISST 
----------------------------------

| **Name**     | **Value**              |
|:-------------|:-----------------------|
| HTTP Method  | POST                                                                                         |
| Base URI     | /bsi/saveSalesOrderBusinessService                                                           |
| URI Syntax   | bmp-payment-business-service-ctle2e.pcfmrnctl.dev.intranet/bsi/saveSalesOrderBusinessService |
| Operation    | /v1/ISSTsaveSalesOrder                                                                       |
| Operation id | saveSalesOrder                                                                               |

Operation Details (Request/Response)
------------------------------------

    API /v1/ISSTsaveSalesOrder

Request	
=======
```sh
{
  "ban": 442241449,
  "productInfo": [
    {
      "productId": 916883296,
      "marketSegment": "C",
      "order": {
        "orderNumer": 1490758137,
        "userId": 1078355,
        "orderType": "N",
        "createDate": "2018-07-18T15:03:18.316Z",
        "orderCompleteDate": "2018-07-18T15:03:18.316Z",
        "sourceSystem": "BLUEMARBLE",
        "orderStatus": "COMMIT",
        "products": [
          {
            "salesCode": 1117916,
            "productName": "string",
            "quantity": 1,
            "productActivityType": "AD",
            "mrc": 9.99
          }
        ]
      }
    }
  ]
}
```
 
    Response Code: 200 – Sales order saved in ISST successfully

Response	
========
```sh
{
  "transactionStatus": "S"
}
 ```
    Error Code: 400 – Bad Request
    
## Error Response	

```sh
{
  "success": false,
  "message": "There was an issue with the Request"
}
```

    Error Code:	404 – Not found

## Error Response	

```sh
{
  "success": false,
  "message": "There was an issue with the Request"
}
```

    Error Code: 500 Internal server error

## Error Response	

```sh
{
  "success": false,
  "message": "There was an issue with the Request"
}
```



[//]: # (These are dummy links used in the body of this page, the link addresses need to be replaced with final API file URLs.)


   [v2.7.2.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/account-management-business-service/>
   [v3.26.0.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/address-validation-business-service/>
   [v2.20.10.md]:<http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/appointment-scheduling-business-service/>
   [v2.0.20.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/change-order-process-business-service/>
   [v2.12.4.md]: <http://bmp-documentation.pcfmrnctl.dev.intranet/api/business/credit-check-business-service/>