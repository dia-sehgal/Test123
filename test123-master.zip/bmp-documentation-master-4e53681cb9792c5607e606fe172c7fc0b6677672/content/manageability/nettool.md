---
title: "NET Paging"
date: 2018-05-24T09:49:19-07:00
draft: false
---
The Notification & Escalation Tool (NET) is a web based tool designed to initiate a page and automatically escalate when using the Callout feature or to send a message to multiple people when using the Notify feature. 

* Many CenturyLink support groups create, maintain and use their own Callout, Notify and Combined groups in NET. 
* The IT Bridge maintains AMT Notify groups to send messages about service affecting events to people that subscribe . 
* The IT Bridge also use NET as its standard callout tool. 
* To find out more about NET, please visit the [Notification & Escalation Tool](http://net.qintra.com/NET/NEThelp/docs/NOTIF_HELP.htm) help page. 


## Blue Marble Callout Groups

{{< button href="http://net.uswc.uswest.com/NET/Notification.jsp?gid=171409" >}} BMP-DEV PIN 171409{{< /button >}}

## Manage Oncall Schedule

{{< button href="http://net.qintra.com/NET/Calendar.jsp?groupid=171409" >}} BMP-DEV Oncall Schedule {{< /button >}}

## NET Setup Instructions

{{% panel theme="success" header="Create or modify NET Callout Groups" %}}
* Login to the Notification &amp; Escalation Tool Website
  - [NET](http://net.qintra.com/NET/Login.jsp) (using cuid &amp; LDAP password)
* To create New Group Click on the &quot;Group Admin&quot; button, located on the left hand side of the screen.
  - Fill in the group name (e.g. PANS1)
  - Fill in the group description (i.e. callout  PANS Development)
  - Click on the &quot;Add the Group&quot; Button
  - It will then add the PIN number (i.e. 90667)
  - Add group members, using name or cuid
* To edit a group click on the &quot;Group Admin&quot; button, located on the left hand side of the screen.
* Fill in the group name (e.g. PANS1) or enter the group description (e.g. callout  PANS Development or PIN #, e.g. 90667)
 - Select FIND GROUP
 - Highlight the group in the window and then select the Edit Group button
 - Add group members, using name or cuid
* Follow the  [NET Guidelines](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/callout.html) when creating or modifying Callout Groups.
{{% /panel %}}