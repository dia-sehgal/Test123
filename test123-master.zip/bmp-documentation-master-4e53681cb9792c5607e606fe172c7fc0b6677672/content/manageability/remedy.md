---
title: "Remedy"
date: 2018-05-24T09:49:19-07:00
draft: false
---

When problems occur within an application/service or work orders need to be isssued for low impact activities on an application/service a Remedy incident ticket is required to document and coordinate the trouble resolution and change activity.

## Remedy Incident Managment (Remedy IM)

The core functionality of Remedy IM is based upon “Case Type”. The case type of a ticket determines which fields are required in order to open, assign, resolve and close a case. By the use of case types, we can have very simple ticket for very simple issues or requests, and more complex tickets for the more significant incidents (and outages). Each case type is covered in its own topic:

* Incident-Quick Close - ITS HD resolves the issue on the initial contact (first call resolution)
* Incident-Dispatched - Simple issue that needed to be assigned to an assignment group (other than the ITS HD) to resolve
* Incident-Complex - Systemic issue, affecting multiple users - all Sev 1, Sev 2 and Outage tickets are Incident-Complex.
* IMAC - Install, Move, Add, Change – Work Request used by LSS in conjunction with Procurement associated with desktop configurations.
* Work Order - Internal work request between support teams for those types of changes that are not required to go through the Corporate Change Process.



### Remedy IM Setup Instructions


{{% panel theme="success" header="Add or modify Remedy Assignment Groups" %}}
* Go to the  [Remedy IM](http://cshare.ad.qintra.com/sites/Remedy/default.aspx) (Incident Management) web site
* The support group to which the Assignment Group is responsible for the creation and updating of the group.  For example: the request would be submitted by an AIP for an application assignment group, a DBA for DB assignment groups, and Development for Dev assignment groups.
* To add a new Remedy Assignment Group, select &#39;New Assignment Group Request&#39; from the selection on the left.
* Create a new item, filling in all required information.
* To modify an existing Remedy Assignment Group, select &#39;AG Change Request&#39; from the selection on the left.
* Create a new item, filling in all required information.est laborum.
{{% /panel %}}


