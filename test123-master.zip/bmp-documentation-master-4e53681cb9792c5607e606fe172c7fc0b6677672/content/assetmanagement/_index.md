---
title: "Asset Management"
pre: "<i class='fa fa-book'></i> &nbsp;"
weight: 30
date: 2018-05-24T09:51:24-07:00
draft: false
---



| **Tool** | **Data Element** | **Data Provider Responsibility** | **Create Responsibility** | **Update Responsibility** | **Detail / Comments** |
| --- | --- | --- | --- | --- | --- |
| MAL / Asset Manager |<ul><li>Application Name</li><li>Application Acronym</li><li>Application Description</li><li>Functionality</li></ul>| Project Team | MAL POC | MAL POC | [_MAL HOW_](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/published.html#MAL) |
| SLR | Application SLR information (Color / Score) | Per SLR process | SLR Rep | SLR Rep | [_SLR HOW_](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/published.html#SLR) |
| NetTool Pin | Contact Information<ul><li>Primary</li><li>Backup</li><li>First Escalation</li><li>Second Escalation</li></ul> | AIP | AIP PIN / AIP, Dev PIN / Dev | AIP PIN / AIP, Dev PIN / Dev | [_NetTool HOW_](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/published.html#CSC) |
| CSC | Contact Information<ul><li>AIP (NetTool Pin)</li><li>System Admin (NetTool Pin)</li><li>Customer First Point of Contact</li></ul>| AIP | AIP | AIP | [_CSC HOW_](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/published.html#CSC) |
| Remedy Inventory | System / Component / Application association | AIP | AIP | AIP | [_Inventory HOW_](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/published.html#Inv) |
| Remedy Assignment Groups | Contact Information<ul><li>Manager</li><li>Director</li></ul>| Project Team | Suffix/Creator<ul><li>AIP / AIP</li><li>DEV / Development</li><li>SUP / SyAd or SME</li></ul>| Suffix/Creator<ul><li>AIP / AIP</li><li>DEV / Development</li><li>SUP /  SyAd or SME</li></ul>| [_Assignment Group HOW_](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/published.html#RAG)|
| Business Continuity and Disaster Recovery Resources | Disaster Recovery Plan | Project Team | Development | AIP | [_BC &amp; DR Resources_](http://home.corp.intranet/portal/server.pt/community/bc___dr/2842) |

The above chart is an example specific to The Production Support Team owning the Availability and Manageability of an Application.  It does NOT cover Infrastructure, Middleware, OS, or database.

Example:

1. A CSC entry for DATABASE would be entered by the DBA team
2. Remedy Inventory Component for OS would be owned by WESO or USS respectively. 

Project Team is defined as, but not limited to the Production Availability and Manageability (example above is AIP), Development Lead, ITPM (BRM and/or ITM), and Client representative when necessary.  Any key stakeholder tied to the Business or IT success of the Application may be included. The Production Support Teams are ultimately responsible for data accuracy for the above mentioned data elements. 

See [_MAL&amp;SLR POC_](http://cshare.ad.qintra.com/sites/appstand/Lists/POC%20Contacts/AllItems.aspx) for contact names.



## Add application to the Master Application List

* Go to the  [CenturyLink Integrated Asset Management](http://cshare.ad.qintra.com/sites/iam/default.aspx) website.
* Select  [&#39;MAL Add Form&#39;](http://cshare.ad.qintra.com/sites/iam/MAL%20ADD%20Forms/Forms/AllItems.aspx) from the menu on the left-hand side.
* Click the &#39;Fill Out This Form&#39; link at the top of the list of forms.
* Complete the form using established standards for Application Name, Application Acronym and Application Description.  Those standards can be found at:  [Application Standards](http://cshare.ad.qintra.com/sites/appstand/)
* Submitted form will trigger an e-mail alert to all MAL representatives notifying them that a new MAL ADD Form is ready for review.  For a list of the current MAL representatives, go to the  [MAL POC List](http://cshare.ad.qintra.com/sites/appstand/Lists/POC%20Contacts/AllItems.aspx).  Once the appropriate MAL representative has reviewed and approved the form, the information will be entered into the MAL within 5 business days.  If the form is found to be incomplete or inaccurate, the MAL representative will reject the form and notify the client via e-mail with reasons why.  The client is then expected to make necessary additions or corrections in order that the form can be approved and the application added to the MAL.

i. See example of form below:

## Answer InfoSec questions to obtain InfoSec score

* Work with the InfoSec SME under your director to complete the IBRRC Information Questionnaire at OFI link  [http://qshare/sites/appstand/ofi.aspx](http://cshare.ad.qintra.com/sites/appstand/ofi.aspx)
* Once the OFI questions have been answered ( [http://qtomaiamw03/ofi/](http://qtomaiamw03/ofi/)), send an email to:  [GSD.Infosec@qwest.com](mailto:GSD.Infosec@qwest.com)
* Info Sec website:   [http://infosec.qintra.com/](http://infosec.qintra.com/)

## Obtain or modify an existing Service Level Rating (SLR)

* Go to the Service Level Rebasing Website -  [Service Level Rebasing](http://cshare.ad.qintra.com/sites/appstand/slr.aspx)
* Select the &#39;Service Level Rating Process&#39; link.
* Follow the respective process described for establishing or modifying an application&#39;s Service Level Rating.

## Create or modify NET Callout Groups (Required for CSC)

* Login to the Notification &amp; Escalation Tool Website
  - [NET](http://net.qintra.com/NET/Login.jsp) (using cuid &amp; LDAP password)
* To create New Group Click on the &quot;Group Admin&quot; button, located on the left hand side of the screen.
  - Fill in the group name (e.g. PANS1)
  - Fill in the group description (i.e. callout  PANS Development)
  - Click on the &quot;Add the Group&quot; Button
  - It will then add the PIN number (i.e. 90667)
  - Add group members, using name or cuid
* To edit a group click on the &quot;Group Admin&quot; button, located on the left hand side of the screen.
* Fill in the group name (e.g. PANS1) or enter the group description (e.g. callout  PANS Development or PIN #, e.g. 90667)
 - Select FIND GROUP
 - Highlight the group in the window and then select the Edit Group button
 - Add group members, using name or cuid
* Follow the  [NET Guidelines](http://cshare.ad.qintra.com/sites/appstand/Shared%20Documents/import/appstand/callout.html) when creating or modifying Callout Groups.

_See example below:_



## Update CSC with NET Pins for new or existing applications

* Access  [CSC](http://csc/csc/index.cgi) Website
* Click on   [EDIT](http://csc/csc/edit_menu.cgi) form left hand navigation menu
* Click on  [Add/Change](http://csc/csc/edit_menu.cgi) application component entries at the top of the page
* Login with LDAP userid and password (this is for tracking purposes only)
* Under Add a New Software Record, enter the Acronym or Name for the application as it exists in the  [MAL](http://directory.uswc.uswest.com/cmsviewer/index.html)
* Click on _add_ button
* Enter the required data (Fields listed at the top of the update screen are modified in Asset Manager)
* Enter the following fields:
  - Customer First Point of Contact
  - SYAD NET Pin
  - AIP Net Pin (whichever is applicable; at least one is required, AIP or SYAD)

## Update Asset Manager / Remedy

_Note - MAL entry must exist before updates to the Asset Manager are accepted.  Asset Manager updates Remedy IM &amp; Remedy CM at 12:30 am and 12:30 pm daily._

* Go to the  [Asset Manager Update Request](http://msr.corp.intranet/cgi-bin/addappmain.cgi) web site.
* Complete the online form [completion of this form will establish or update in Asset Manager the following information for the application]:
* Component name(s) for Remedy IM and Remedy CM
* Servers associated with the application
* Online hours (if applicable, application may be BATCH) of operation (necessary to calculate monthly availability results)
* Service level objective % based upon SLR Color (99.8%, 99.5%, etc.) (necessary to calculate monthly availability results)
* Associate Asset Manager/Remedy Component to the MAL entry so the associated servers show up in the  [CMS Viewer](http://directory.uswc.uswest.com/cmsviewer/index.html)
* Inclusion of application in the Monthly Service Review (if Gold or Silver)

_On-line form is shown below:_



## Add or modify Remedy Assignment Groups

* Go to the  [Remedy IM](http://cshare.ad.qintra.com/sites/Remedy/default.aspx) (Incident Management) web site
* The support group to which the Assignment Group is responsible for the creation and updating of the group.  For example: the request would be submitted by an AIP for an application assignment group, a DBA for DB assignment groups, and Development for Dev assignment groups.
* To add a new Remedy Assignment Group, select &#39;New Assignment Group Request&#39; from the selection on the left.
* Create a new item, filling in all required information.
* To modify an existing Remedy Assignment Group, select &#39;AG Change Request&#39; from the selection on the left.
* Create a new item, filling in all required information.



## Business Continuity and Disaster Recovery Resources
  
* Go to the  [IT Disaster Recovery Services ](http://home.corp.intranet/portal/server.pt/community/bc___dr/2842) web site to access information and training.
* Templates and User Guides are also accessed from this location above.