---
title: "Service Level Rating"
date: 2018-05-24T09:49:19-07:00
draft: false
---

Every application released into production is required to have a Service Level Rating. A Service Level Rating is used to ensure proper production support time frames and guidelines are met when the application is not functioning at 100% of its availability.The Service Level Rating data will reside in the MAL but will also be referenced in Asset Center and in the Business Continuity/Disaster Recovery plan. 


{{< button href="https://directory.corp.intranet/cmsviewer/MAL/index.html?key=SYSGEN787442412" >}} View Blue Marble SLR in CMS {{< /button >}}

</hr>

### Service Level Rating Setup Instructions


{{% panel theme="success" header="How to obtain or modify an existing Service Level Rating (SLR)" %}}
* Go to the Service Level Rebasing Website -  [Service Level Rebasing](http://cshare.ad.qintra.com/sites/appstand/slr.aspx)
* Select the &#39;Service Level Rating Process&#39; link.
* Follow the respective process described for establishing or modifying an application&#39;s Service Level Rating.
{{% /panel %}}

