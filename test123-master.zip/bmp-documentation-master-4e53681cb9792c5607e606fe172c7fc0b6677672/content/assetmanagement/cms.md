---
title: "CMS Viewer"
date: 2018-05-24T09:49:19-07:00
draft: false
---

The CMS Viewer is a read-only web lookup tool for Asset Manager -- the company's database for managing technology assets. In Asset Manager, nearly a quarter-million assets exist in various lifecycle stages. At a high level, these assets are in the following categories:

* Master Application List ("MAL")
* Master inventory of server-based applications
* Master Database List ("MDL")
* Master inventory of databases
* Personal Computers
* Inventory of desktops and laptops
* Datacenter Spare Parts Inventory
* Inventory of spare parts available for use
* Network Inventory
* Inventory of network cards & chassis (from OCPM)
* Midrange Servers & Related Components
* Inventory of physical and virtual servers and associated devices
* Mainframes & Mainframe Partitions
* Inventory of mainframe hardware and partitions
* Storage Assets
* Inventory of storage devices
* Datacenter Environmental Equipment
* Inventory of devices key to the Datacenters

Key relationships between assets in these categories are also captured in Asset Manager and shown in the CMS Viewer, recording for instance which servers an application or database runs on.

In addition, many other associated assets including select software license records, software installation records, and software utilization records. User information, sourced from M-Net (the database behind the Corporate Directory) is used to maintain associations between assets and people.

{{< button href="https://directory.corp.intranet/cmsviewer/MAL/index.html?key=SYSGEN787442412" >}} CMS Viewer for BMP {{< /button >}}